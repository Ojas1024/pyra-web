"""Finite sets, function parameters and Python's math builtins inside proofs (phase 5.2.2 / 5.2.3).

Every construct is built from a ``Pyra.Tpl`` template that Lean itself elaborated, so the terms are
exactly those of a Lean/Mathlib statement:

=============================================  ==============================================
Python (inside ``@prove``)                     Lean / Mathlib
=============================================  ==============================================
``s: Finset[Int]`` (parameter)                 ``(s : Finset ℤ)``
``f: Fun[Int, Int]`` (parameter)               ``(f : ℤ → ℤ)``
``range(n)`` / ``range(a, b)``                 ``Finset.range n`` / ``Finset.Ico a b``
``Icc(a, b)``, ``Ico``, ``Ioc``, ``Ioo``       ``Finset.Icc a b``, ...
``x in s`` / ``x not in s``                    ``x ∈ s`` / ``x ∉ s``
``len(s)``, ``s.card``                         ``s.card``
``sum(s)``                                     ``∑ i ∈ s, i``
``sum(f(i) for i in s if p(i))``               ``∑ i ∈ s.filter p, f i`` (ℕ/ℤ/ℚ/ℝ bodies)
``sum(1 for i in s if p(i))``, ``len([...])``  ``(s.filter p).card``
``{i for i in s if p(i)}``                     ``s.filter p``
``math.prod(f(i) for i in s)``                 ``∏ i ∈ s, f i``
``math.floor(x)`` / ``math.ceil(x)``           ``⌊x⌋`` / ``⌈x⌉`` (``Int.floor`` / ``Int.ceil``)
``math.sqrt(x)``                               ``Real.sqrt x``
``math.isqrt(n)``                              ``Nat.sqrt n``
``math.gcd`` / ``math.lcm``                    ``Nat.gcd`` / ``Nat.lcm`` (``Int.gcd`` on ℤ)
``math.factorial(n)`` / ``math.comb(n, k)``    ``n !`` / ``Nat.choose n k``
``math.log(x)`` / ``math.log(x, b)``           ``Real.log x`` / ``Real.logb b x``
``math.exp(x)``                                ``Real.exp x``
=============================================  ==============================================

Decidability instances of filters come from instance search (as Lean elaborates them).  Library
modules not in the bundle (``Real.log``, ``Nat.divisors``, ...) are imported on demand with
:func:`pyra.require`.
"""
from __future__ import annotations

import math

from . import pyra_bind as pb
from .terms import (Lit, PyraError, PyraRange, Term, TermLike, coerce, decidable_instance, effective_sort, to_term, tpl,
                    SORTS, Sort, _ORDER)

_ELEMS = ("nat", "int")


# --------------------------------------------------------------------------- types
class FinsetSort:
    """``Finset[Nat]`` / ``Finset[Int]``: the type of a finset parameter."""

    def __init__(self, elem: Sort):
        if not isinstance(elem, Sort) or elem.key not in _ELEMS:
            raise PyraError("Finset[...] supports Nat and Int elements")
        self.elem = elem

    @property
    def handle(self) -> int:
        return pb.mk_app(pb.mk_const("Finset", [pb.level_zero()]), self.elem.handle)

    def make(self, name: str) -> "FinsetTerm":
        return FinsetTerm(pb.mk_fvar(name, self.handle), self.elem.key)

    def __repr__(self):
        return f"Finset[{self.elem!r}]"


class _FinsetFactory:
    def __getitem__(self, elem):
        return FinsetSort(elem)

    def __repr__(self):
        return "Finset"


Finset = _FinsetFactory()


class FunSort:
    """``Fun[Int, Int]`` (``ℤ → ℤ``), ``Fun[Nat, Nat, Real]`` (``ℕ → ℕ → ℝ``)."""

    def __init__(self, *sorts):
        if len(sorts) < 2 or not all(isinstance(s, Sort) for s in sorts):
            raise PyraError("Fun[A, ..., B] needs Pyra number types (Nat, Int, Rat, Real)")
        self.doms, self.cod = list(sorts[:-1]), sorts[-1]

    @property
    def handle(self) -> int:
        t = self.cod.handle
        for d in reversed(self.doms):
            x = pb.mk_fvar("x", d.handle)
            t = pb.mk_pi_fvars([x], t)
        return t

    def make(self, name: str) -> "FunTerm":
        return FunTerm(pb.mk_fvar(name, self.handle), self)

    def __repr__(self):
        return f"Fun[{', '.join(map(repr, self.doms + [self.cod]))}]"


class _FunFactory:
    def __getitem__(self, sorts):
        return FunSort(*(sorts if isinstance(sorts, tuple) else (sorts,)))


Fun = _FunFactory()


class FunTerm(Term):
    """A function-valued parameter: ``f(x)`` applies it (arguments are cast to its domain)."""

    __slots__ = ("fsort",)

    def __init__(self, h, fsort: FunSort):
        super().__init__(h, "fun")
        self.fsort = fsort

    def __call__(self, *args):
        if len(args) != len(self.fsort.doms):
            raise PyraError(f"{self} takes {len(self.fsort.doms)} argument(s)")
        h = self.h
        for a, d in zip(args, self.fsort.doms):
            h = pb.mk_app(h, coerce(to_term(a), d.key).h)
        return Term(h, self.fsort.cod.key)


class FinsetTerm(Term):
    """A ``Finset ℕ`` / ``Finset ℤ`` term: ``len(s)`` / ``s.card``, ``x in s``, ``sum(s)``."""

    __slots__ = ("elem",)

    def __init__(self, h, elem: str):
        super().__init__(h, "finset")
        self.elem = elem

    @property
    def card(self) -> Term:
        return Term(tpl(f"{self.elem}_finset_card", self.h), "nat")

    def filter(self, pred) -> "FinsetTerm":
        return filter_(pred, self)

    def __len__(self):
        raise TypeError("len() of a symbolic finset: inside @prove, len(s) is rewritten to s.card")

    def __iter__(self):
        raise TypeError("cannot iterate over a symbolic finset (use it in sum(...) / len(...) / `in`)")


class SetSort:
    """``Set[Nat]`` / ``Set[Int]`` / ``Set[Real]``: the type of a set parameter (``Set ℕ``)."""

    def __init__(self, elem: Sort):
        if not isinstance(elem, Sort) or elem.key not in ("nat", "int", "real"):
            raise PyraError("Set[...] supports Nat, Int and Real elements")
        self.elem = elem

    @property
    def handle(self) -> int:
        return pb.mk_app(pb.mk_const("Set", [pb.level_zero()]), self.elem.handle)

    def make(self, name: str) -> "SetTerm":
        return SetTerm(pb.mk_fvar(name, self.handle), self.elem.key)

    def __repr__(self):
        return f"Set[{self.elem!r}]"


class _SetFactory:
    def __getitem__(self, elem):
        return SetSort(elem)


Set = _SetFactory()


class SetTerm(Term):
    """A ``Set α`` term: ``x in S``, ``S - {u}`` (``S \\ {u}``), ``S | T``, ``S & T``."""

    __slots__ = ("elem",)

    def __init__(self, h, elem: str):
        super().__init__(h, "set")
        self.elem = elem

    def _as_set(self, o) -> "SetTerm":
        if isinstance(o, SetTerm):
            return o
        if isinstance(o, (set, frozenset, list, tuple)):
            items = list(o)
            if not items:
                raise PyraError("empty set literals are not supported")
            r = None
            for e in items:
                s1 = SetTerm(tpl(f"{self.elem}_set_singleton", coerce(to_term(e), self.elem).h), self.elem)
                r = s1 if r is None else r | s1
            return r
        raise PyraError(f"{o!r} is not a set")

    def __sub__(self, o):
        return SetTerm(tpl(f"{self.elem}_set_sdiff", self.h, self._as_set(o).h), self.elem)

    def __or__(self, o):
        return SetTerm(tpl(f"{self.elem}_set_union", self.h, self._as_set(o).h), self.elem)

    def __and__(self, o):
        return SetTerm(tpl(f"{self.elem}_set_inter", self.h, self._as_set(o).h), self.elem)


def is_least(s, a) -> Term:
    """``IsLeast s a``: a ∈ s and a is a lower bound of s."""
    if not isinstance(s, SetTerm):
        raise PyraError("is_least needs a Set")
    return Term(tpl(f"{s.elem}_is_least", s.h, coerce(to_term(a), s.elem).h), "prop")


def is_greatest(s, a) -> Term:
    """``IsGreatest s a``: a ∈ s and a is an upper bound of s."""
    if not isinstance(s, SetTerm):
        raise PyraError("is_greatest needs a Set")
    return Term(tpl(f"{s.elem}_is_greatest", s.h, coerce(to_term(a), s.elem).h), "prop")


def wrap_finset(t: Term) -> Term:
    """A term of type ``Finset ℕ`` / ``Finset ℤ`` (e.g. ``Nat.divisors 36``) as a :class:`FinsetTerm`."""
    if t.sort != "other":
        return t
    try:
        from .kernel import elab
        ty = elab().infer(t.h)
    except Exception:
        return t
    for key in _ELEMS:
        if ty == FinsetSort(SORTS[key]).handle:
            return FinsetTerm(t.h, key)
    return t


# --------------------------------------------------------------------------- intervals
def _elem_sort(*xs) -> str:
    s = "nat"
    for x in xs:
        e = effective_sort(to_term(x))
        if e not in ("nat", "int"):
            raise PyraError(f"finset bounds must be natural numbers or integers, got {x} ({e})")
        if e == "int":
            s = "int"
    return s


def _interval(kind, a, b, sort=None) -> FinsetTerm:
    s = sort.key if isinstance(sort, Sort) else (sort or _elem_sort(a, b))
    A, B = coerce(to_term(a), s), coerce(to_term(b), s)
    return FinsetTerm(tpl(f"{s}_finset_{kind}", A.h, B.h), s)


def Icc(a, b, sort=None) -> FinsetTerm:
    """``Finset.Icc a b`` = {a, ..., b} (ℕ, or ℤ when a bound is an integer or ``sort=Int``)."""
    return _interval("Icc", a, b, sort)


def Ico(a, b, sort=None) -> FinsetTerm:
    """``Finset.Ico a b`` = {a, ..., b - 1}."""
    return _interval("Ico", a, b, sort)


def Ioc(a, b, sort=None) -> FinsetTerm:
    """``Finset.Ioc a b`` = {a + 1, ..., b}."""
    return _interval("Ioc", a, b, sort)


def Ioo(a, b, sort=None) -> FinsetTerm:
    """``Finset.Ioo a b`` = {a + 1, ..., b - 1}."""
    return _interval("Ioo", a, b, sort)


def is_finset_like(x) -> bool:
    return isinstance(x, (FinsetTerm, PyraRange))


def as_finset(x) -> FinsetTerm:
    """``range(n)`` -> ``Finset.range n``; ``range(a, b)`` -> ``Finset.Ico a b``."""
    if isinstance(x, FinsetTerm):
        return x
    if isinstance(x, PyraRange):
        if x.start is None:
            return FinsetTerm(tpl("nat_finset_range", coerce(x.n, "nat").h), "nat")
        return _interval("Ico", x.start, x.n)
    if isinstance(x, range) and x.step == 1:
        return as_finset(PyraRange(Lit(x.start), Lit(x.stop)) if x.start else PyraRange(Lit(x.stop)))
    raise PyraError(f"{x!r} is not a finset")


# --------------------------------------------------------------------------- membership, card, filters
def mem(x, s) -> Term:
    """``x ∈ s``."""
    S = as_finset(s)
    X = to_term(x)
    if effective_sort(X) not in ("nat", "int", "lit") or (S.elem == "nat" and effective_sort(X) == "int"):
        raise PyraError(f"{x} cannot be an element of a Finset of sort {S.elem}")
    return Term(tpl(f"{S.elem}_finset_mem", coerce(X, S.elem).h, S.h), "prop")


def _binder(fn, sort: str, default="i"):
    code = getattr(fn, "__code__", None)
    name = code.co_varnames[0] if code is not None and code.co_varnames else default
    x = pb.mk_fvar(name, SORTS[sort].handle)
    return x, fn(Term(x, sort))


def filter_(pred, s) -> FinsetTerm:
    """``s.filter p`` with Lean's ``DecidablePred p`` instance (found by instance search)."""
    S = as_finset(s)
    x, body = _binder(pred, S.elem, "x")
    P = to_term(body)
    if P.sort != "prop":
        raise PyraError(f"a filter needs a proposition, got {P}")
    inst = decidable_instance(P.h)
    p = pb.mk_lam_fvars([x], P.h)
    dp = pb.mk_lam_fvars([x], inst)
    return FinsetTerm(tpl(f"{S.elem}_finset_filter", p, dp, S.h), S.elem)


def card(s) -> Term:
    return as_finset(s).card


def aggregate(kind, fn, it, cond=None, var=None) -> Term:
    """``sum``/``prod`` of ``fn(i)`` over a finset (optionally filtered by ``cond``)."""
    S = as_finset(it)
    if cond is not None:
        S = filter_(cond, S)
    if fn is None:                                  # sum(s): the elements themselves
        fn = lambda i: i                            # noqa: E731
    x, body = _binder(fn, S.elem, var or "i")
    B = to_term(body)
    if kind == "sum" and cond is not None and isinstance(B, Lit) and B.value == 1:
        return S.card                               # sum(1 for i in s if p(i)) = (s.filter p).card
    bs = effective_sort(B)
    if bs == "lit" or bs not in _ORDER:
        raise PyraError(f"cannot {kind} terms of sort {bs}")
    B = coerce(B, bs)
    lam = pb.mk_lam_fvars([x], B.h)
    return Term(tpl(f"{bs}_finset_{kind}_{S.elem}", S.h, lam), bs)


def mem_or_contains(x, s):
    """``x in s`` inside a proof: Finset / Set membership, a disjunction of equations for a list of terms,
    or Python's ``in``."""
    if is_finset_like(s):
        return mem(x, s)
    if isinstance(s, SetTerm):
        return Term(tpl(f"{s.elem}_set_mem", coerce(to_term(x), s.elem).h, s.h), "prop")
    if isinstance(x, TermLike) or (isinstance(s, (list, tuple, set)) and any(isinstance(e, TermLike) for e in s)):
        from .terms import or_, relation
        items = list(s)
        if not items:
            return to_term(False)
        return or_(*[relation("eq", x, e) for e in items])
    return x in s


def filter_or_builtin(pred, it):
    if is_finset_like(it):
        return filter_(pred, it)
    return filter(pred, it)


def len_(x):
    if isinstance(x, (FinsetTerm, PyraRange)):
        return card(x)
    return len(x)


def comprehension(kind, elt_fn, it, cond_fn, fallback):
    """Comprehensions over a Pyra finset (``sum(... for i in s if p)``, ``len([...])``, ``{i for i in s if p}``);
    anything else is ordinary Python (``fallback``)."""
    if not is_finset_like(it):
        return fallback()
    var = elt_fn.__code__.co_varnames[0] if elt_fn.__code__.co_varnames else "i"
    if kind in ("sum", "prod"):
        return aggregate(kind, elt_fn, it, cond_fn, var)
    S = as_finset(it)
    if kind == "len":
        S = filter_(cond_fn, S) if cond_fn is not None else S
        x, body = _binder(elt_fn, S.elem, var)
        if not (isinstance(body, Term) and body.h == x):
            # len([f(i) for i in s]) counts the elements of s (a list keeps duplicates)
            pass
        return S.card
    if kind == "set":
        x, body = _binder(elt_fn, S.elem, var)
        if not (isinstance(body, Term) and body.h == x):
            raise PyraError("only {i for i in s if p(i)} (a filter) is supported as a set comprehension")
        return filter_(cond_fn, S) if cond_fn is not None else S
    return fallback()


# --------------------------------------------------------------------------- math builtins
_REQUIRED = {
    "Real.log": ["Mathlib.Analysis.SpecialFunctions.Log.Basic"],
    "Real.logb": ["Mathlib.Analysis.SpecialFunctions.Log.Base"],
    "Real.exp": ["Mathlib.Analysis.SpecialFunctions.Exp"],
    "Real.sqrt": ["Mathlib.Analysis.Real.Sqrt"],
}


def require_for(const: str):
    """Import `const` and its Mathlib module (lemmas included) on first use."""
    from .library import require, _loaded_modules
    mods = [m for m in _REQUIRED.get(const, []) if m not in _loaded_modules]
    if mods:
        require(const, modules=mods)


def _real(x) -> Term:
    t = to_term(x)
    return coerce(t, "real")


def _app(const, *hs) -> int:
    return pb.mk_apps(pb.mk_const(const), list(hs))


def _sym(*args) -> bool:
    return any(isinstance(a, TermLike) for a in args)


def m_floor(x):
    if not _sym(x):
        return math.floor(x)
    t = to_term(x)
    s = effective_sort(t)
    if s in ("nat", "int", "lit") and not (isinstance(t, Lit) and not isinstance(t.value, int)):
        return t
    if s not in ("rat", "real"):
        s = "real"
    return Term(tpl(f"{s}_floor", coerce(t, s).h), "int")


def m_ceil(x):
    if not _sym(x):
        return math.ceil(x)
    t = to_term(x)
    s = effective_sort(t)
    if s in ("nat", "int", "lit") and not (isinstance(t, Lit) and not isinstance(t.value, int)):
        return t
    if s not in ("rat", "real"):
        s = "real"
    return Term(tpl(f"{s}_ceil", coerce(t, s).h), "int")


def m_sqrt(x):
    if not _sym(x):
        return math.sqrt(x)
    require_for("Real.sqrt")
    return Term(_app("Real.sqrt", _real(x).h), "real")


def m_isqrt(n):
    if not _sym(n):
        return math.isqrt(n)
    return Term(tpl("nat_sqrt", coerce(to_term(n), "nat").h), "nat")


def _gcd_like(name, pyfn, a, b, *rest):
    if not _sym(a, b, *rest):
        return pyfn(a, b, *rest)
    if rest:
        return _gcd_like(name, pyfn, _gcd_like(name, pyfn, a, b), *rest)
    A, B = to_term(a), to_term(b)
    s = "int" if "int" in (effective_sort(A), effective_sort(B)) else "nat"
    return Term(tpl(f"{s}_{name}", coerce(A, s).h, coerce(B, s).h), "nat")


def m_gcd(*args):
    return _gcd_like("gcd", math.gcd, *args)


def m_lcm(*args):
    return _gcd_like("lcm", math.lcm, *args)


def m_factorial(n):
    if not _sym(n):
        return math.factorial(n)
    return Term(tpl("nat_factorial", coerce(to_term(n), "nat").h), "nat")


def m_comb(n, k):
    if not _sym(n, k):
        return math.comb(n, k)
    return Term(tpl("nat_choose", coerce(to_term(n), "nat").h, coerce(to_term(k), "nat").h), "nat")


def m_log(x, base=None):
    if not _sym(x, base):
        return math.log(x) if base is None else math.log(x, base)
    if base is None:
        require_for("Real.log")
        return Term(_app("Real.log", _real(x).h), "real")
    require_for("Real.logb")
    return Term(_app("Real.logb", _real(base).h, _real(x).h), "real")


def m_log2(x):
    return m_log(x, 2) if _sym(x) else math.log2(x)


def m_log10(x):
    return m_log(x, 10) if _sym(x) else math.log10(x)


def m_exp(x):
    if not _sym(x):
        return math.exp(x)
    require_for("Real.exp")
    return Term(_app("Real.exp", _real(x).h), "real")


def m_prod(it, *, start=1):
    if is_finset_like(it):
        return aggregate("prod", None, it)
    return math.prod(it, start=start)


MATH = {"floor": m_floor, "ceil": m_ceil, "sqrt": m_sqrt, "isqrt": m_isqrt, "gcd": m_gcd, "lcm": m_lcm,
        "factorial": m_factorial, "comb": m_comb, "log": m_log, "log2": m_log2, "log10": m_log10, "exp": m_exp,
        "prod": m_prod}


def builtin(name, orig, *args):
    """``math.<name>(*args)`` or a bare ``sqrt(...)`` imported from math: the Mathlib function on terms."""
    if orig is not None and getattr(orig, "__module__", None) != "math" and orig is not getattr(math, name, None):
        return orig(*args)                          # a user function that happens to share the name
    return MATH[name](*args)
