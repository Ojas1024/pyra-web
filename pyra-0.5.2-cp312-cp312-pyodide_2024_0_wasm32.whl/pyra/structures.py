"""Types beyond the number sorts: function types, sets, Mathlib type constructors, and type
variables carrying type-class structure (groups, rings, metric spaces, ...).

    from pyra import prove, Nat, Real, Fun, Set, structure, const

    Group = structure("Group")                      # {G : Type u_1} [Group G]

    @prove
    def comm(G: Group, a: "G", b: "G", h: "a * b == b * a"):
        ...

    @prove
    def clopen(A: Set[Nat]):
        return const("IsClopen")(A)

Terms whose type is not ℕ/ℤ/ℚ/ℝ get Lean's generic operators (``HAdd.hAdd``, ``HMul.hMul``,
``HPow.hPow``, ``Neg.neg``, ``OfNat.ofNat`` numerals, ...) with their instances found by instance
search -- including the *local* instances of a ``structure`` parameter -- so the terms are the ones
Lean elaborates (up to the choice of instance path, which is definitional).
"""
from __future__ import annotations

from . import pyra_bind as pb
from .kernel import elab, kernel
from .terms import LeanConst, Lit, PyraError, Sort, Term, TermLike, to_term, numeral, effective_sort, coerce, SORTS


# --------------------------------------------------------------------------- types
def type_handle(t) -> int:
    """Kernel handle of a type given as a Pyra sort, a LeanType or a raw handle."""
    if isinstance(t, (Sort, LeanType)):
        return t.handle
    if isinstance(t, int):
        return t
    raise PyraError(f"{t!r} is not a type")


_SORT_OF = {"Nat": "nat", "Int": "int", "Rat": "rat", "Real": "real"}


def wrap(h: int) -> Term:
    """A Term for handle `h`: callable when its type is a function type (or coerces to one)."""
    t = Term(h)
    if t.sort == "other":
        try:
            ty = elab().whnf(elab().infer(h))
        except Exception:
            return t
        if pb.kind(ty) != "sort":           # functions, and bundled maps (coerced with DFunLike.coe)
            return Fn(h, "other")
    return t


class LeanType:
    """A Lean type used as a parameter annotation (``C: Fun[Nat, Real]``, ``A: Set[Nat]``)."""

    def __init__(self, thunk, label: str):
        self._thunk = thunk
        self._h = None
        self.label = label

    @property
    def handle(self) -> int:
        if self._h is None:
            self._h = self._thunk()
        return self._h

    def make(self, name: str, binfo: int = 0) -> Term:
        return wrap(pb.mk_fvar(name, self.handle, binfo))

    def __call__(self, value) -> Term:
        """``ZMod7(2)``: the numeral exactly as Lean elaborates ``(2 : ZMod 7)`` (``OfNat.ofNat``, instance
        by search); negative numbers are ``-(k : T)``."""
        if isinstance(value, Lit) and isinstance(value.value, int):
            value = value.value
        if isinstance(value, bool) or not isinstance(value, int):
            raise PyraError(f"{self.label}(...) takes an integer literal, got {value!r}")
        k = abs(value)
        h = wrap(elab().apply_typed("OfNat.ofNat", [pb.mk_nat(k)], self.handle))
        return negate(h) if value < 0 else h

    def __repr__(self):
        return self.label

    @staticmethod
    def of(h: int, label: str = "") -> "LeanType":
        t = LeanType(lambda: h, label or pb.to_string(h))
        t._h = h
        return t


class _FunFamily:
    def __getitem__(self, args):
        args = args if isinstance(args, tuple) else (args,)
        if len(args) < 2:
            raise PyraError("Fun[A, B] needs a domain and a codomain")

        def build():
            r = type_handle(args[-1])
            for a in reversed(args[:-1]):
                r = pb.mk_pi("x", type_handle(a), r, 0)
            return r
        return LeanType(build, f"Fun[{', '.join(map(repr, args))}]")


Fun = _FunFamily()


class TypeFamily:
    """A Mathlib type constructor: ``Set[Nat]``, ``lean_type("Polynomial")[Int]``, ``lean_type("GaussianInt")``."""

    def __init__(self, lean_name: str):
        self.lean_name = lean_name

    def __getitem__(self, args):
        args = args if isinstance(args, tuple) else (args,)
        from .terms import _ensure_loaded
        return LeanType(lambda: (_ensure_loaded(self.lean_name), elab().apply(self.lean_name, [_arg(a) for a in args]))[1],
                        f"{self.lean_name}[{', '.join(map(repr, args))}]")

    @property
    def handle(self) -> int:          # a constant type (no parameters)
        from .terms import _ensure_loaded
        _ensure_loaded(self.lean_name)
        return pb.mk_const(self.lean_name)

    def make(self, name: str, binfo: int = 0) -> Term:
        return wrap(pb.mk_fvar(name, self.handle, binfo))

    def __repr__(self):
        return self.lean_name


def lean_type(name: str) -> TypeFamily:
    return TypeFamily(name)


Set = TypeFamily("Set")


# --------------------------------------------------------------------------- type variables with structure
class TypeVar(LeanType):
    """The value of a ``structure(...)`` parameter inside a proof: the type itself (usable as an
    annotation ``a: "G"`` and as ``sort=G``)."""

    def __init__(self, fvar: int, name: str):
        super().__init__(lambda: fvar, name)
        self._h = fvar
        self.h = fvar
        self.sort = "type"


class structure:
    """A type parameter with type-class structure: ``G: structure("Group")`` stands for Lean's
    ``{G : Type u} [Group G]`` (``structure("Group", "Fintype")`` for ``[Group G] [Fintype G]``).
    Universe parameters are named ``u_1, u_2, ...`` in order, as Lean names ``Type*``."""

    def __init__(self, *classes: str, explicit: bool = False):
        self.classes = classes
        self.explicit = explicit

    def binders(self, name: str, ctx: dict):
        ctx["universes"] = ctx.get("universes", 0) + 1
        u = pb.level_param(f"u_{ctx['universes']}")
        T = pb.mk_fvar(name, pb.mk_sort(pb.level_succ(u)), 0 if self.explicit else 1)
        fvars = [T]
        for c in self.classes:
            inst = pb.mk_fvar(f"inst{c}", elab().apply(c, [T]), 3)
            elab().add_local_instance(inst)
            fvars.append(inst)
        return TypeVar(T, name), fvars

    def __repr__(self):
        return f"structure({', '.join(map(repr, self.classes))})"


# --------------------------------------------------------------------------- generic operators
def _arg(a) -> int:
    if isinstance(a, (Sort, LeanType, TypeFamily)):
        return a.handle
    from .terms import _arg_handle
    return _arg_handle(a)


def const(name: str) -> LeanConst:
    """A Lean/Mathlib constant by its Lean name (``const("IsClopen")(A)``); see also ``typed``."""
    return LeanConst(name, (kernel().find(name) or {}).get("kind", ""))


def typed(name: str, type_, *args) -> Term:
    """``name args`` at the expected type `type_`: fixes implicit arguments only the result type
    determines, e.g. ``typed("Polynomial.X", Polynomial[Int])``."""
    return wrap(elab().apply_typed(name, [_arg(a) for a in args], type_handle(type_)))


def _type_of(t: Term) -> int:
    return elab().infer(t.h)


def lit_in(value, T: int) -> Term:
    """The numeral `value` in type T (``@OfNat.ofNat T n _``, negative: ``-n``)."""
    s = _SORT_OF.get(pb.const_name(T)) if pb.kind(T) == "const" else None
    if s:
        return Term(numeral(value, s), s)
    if not isinstance(value, int):
        raise PyraError(f"only integer literals are supported in {pb.to_string(T)}")
    n = abs(value)
    t = None
    if n >= 2:
        # as Lean elaborates it in a semiring: @OfNat.ofNat T n (@instOfNatAtLeastTwo T n _ (Nat.instAtLeastTwoHAddOfNat ...))
        try:
            nat_cast = elab().apply("NatCast", [T])
            inst = elab().synth(nat_cast)
        except Exception:
            inst = None
        if inst is not None:
            from .terms import tpl
            lv = pb.const_levels(pb.head(nat_cast))
            two = pb.mk_apps(pb.mk_const("Nat.instAtLeastTwoHAddOfNat"),
                             [tpl("nat_num", pb.mk_nat(n - 1)), pb.mk_app(pb.mk_const("Nat.instNeZeroSucc"), tpl("nat_num", pb.mk_nat(n - 2)))])
            of_nat = pb.mk_apps(pb.mk_const("instOfNatAtLeastTwo", lv), [T, pb.mk_nat(n), inst, two])
            t = wrap(pb.mk_apps(pb.mk_const("OfNat.ofNat", lv), [T, pb.mk_nat(n), of_nat]))
    if t is None:
        t = wrap(elab().apply_typed("OfNat.ofNat", [pb.mk_nat(n)], T))
    return negate(t) if value < 0 else t


def as_type(x, T: int) -> Term:
    """Coerce a Pyra value to type T: literals become numerals of T; numeric terms are cast."""
    t = to_term(x)
    if isinstance(t, Lit) and t.sort == "lit":
        return lit_in(t.value, T)
    if pb.kind(T) == "const" and pb.const_name(T) in _SORT_OF and t.sort in SORTS:
        return coerce(t, _SORT_OF[pb.const_name(T)])
    return t


_BINOP = {"add": "HAdd.hAdd", "sub": "HSub.hSub", "mul": "HMul.hMul", "truediv": "HDiv.hDiv", "div": "HDiv.hDiv",
          "mod": "HMod.hMod"}


def is_generic(*xs) -> bool:
    return any(isinstance(x, TermLike) and x.sort in ("other",) for x in xs)


def generic_arith(op: str, a, b) -> Term:
    A, B = to_term(a), to_term(b)
    T = _type_of(A if A.sort == "other" else B)
    A, B = as_type(A, T), as_type(B, T)
    return wrap(elab().apply_typed(_BINOP[op], [A.h, B.h], T))


def generic_power(a, b) -> Term:
    A = to_term(a)
    T = _type_of(A)
    B = to_term(b)
    if isinstance(B, Lit) and B.sort == "lit":
        if B.value < 0:      # zpow (a group's integer powers)
            return wrap(elab().apply_typed("HPow.hPow", [A.h, numeral(B.value, "int")], T))
        B = Term(numeral(B.value, "nat"), "nat")
    return wrap(elab().apply_typed("HPow.hPow", [A.h, B.h], T))


def negate(a) -> Term:
    return wrap(elab().apply("Neg.neg", [to_term(a).h]))


def inv(a) -> Term:
    """``a⁻¹`` (``Inv.inv``)."""
    return wrap(elab().apply("Inv.inv", [to_term(a).h]))


_REL = {"eq": "Eq", "ne": "Ne", "lt": "LT.lt", "le": "LE.le", "gt": "GT.gt", "ge": "GE.ge"}


def generic_relation(op: str, a, b) -> Term:
    A, B = to_term(a), to_term(b)
    T = _type_of(A if A.sort == "other" else B)
    A, B = as_type(A, T), as_type(B, T)
    return Term(elab().apply(_REL[op], [A.h, B.h]), "prop")


def mem(x, s) -> Term:
    """``x ∈ s`` (``Membership.mem s x``)."""
    S = to_term(s)
    X = to_term(x)
    if isinstance(X, Lit) and X.sort == "lit":
        X = lit_in(X.value, _elem_type(S))
    return Term(elab().apply("Membership.mem", [S.h, X.h]), "prop")


class Fn(Term):
    """A term of function type (or one that coerces to a function, e.g. a ``MulAut``): calling it applies it."""

    __slots__ = ()

    def __call__(self, *args):
        h = self.h
        for a in args:
            ty = elab().whnf(elab().infer(h))
            if pb.kind(ty) == "pi":
                h = pb.mk_app(h, as_type(a, pb.binder_type(ty)).h)
            else:
                h = coe_fn_apply(h, a)
        return wrap(h)


def coe_fn_apply(f: int, a) -> int:
    """``⇑f a`` for `f` in a type with a ``DFunLike`` instance (bundled homs, equivs, ...)."""
    x = to_term(a)
    if isinstance(x, Lit):
        raise PyraError("cannot apply a bundled map to a bare literal")
    F = elab().infer(f)
    A = elab().infer(x.h)
    # DFunLike.coe {F} {α} {β} [DFunLike F α β] (f : F) (a : α) : β a.  The outParam β is fixed by the
    # instance, so search `DFunLike F α ?β` for each candidate codomain shape `fun _ => B`.
    for want_cod in _codomain_candidates(F, A):
        lam = pb.mk_lam("x", A, want_cod, 0)
        try:
            cls = pb.mk_apps(pb.mk_const("DFunLike", _levels3(F, A, want_cod)), [F, A, lam])
            inst = elab().synth(cls)
        except Exception:
            inst = None
        if inst is not None:
            return pb.mk_apps(pb.mk_const("DFunLike.coe", _levels3(F, A, want_cod)), [F, A, lam, inst, f, x.h])
    raise PyraError(f"{pb.to_string(F)} cannot be applied as a function")


def _sort_level(T: int) -> int:
    """The universe `u` with ``T : Sort u``."""
    return pb.sort_level(elab().whnf(elab().infer(T)))


def _levels3(F, A, B):
    return [_sort_level(F), _sort_level(A), _sort_level(B)]


def _codomain_candidates(F: int, A: int):
    """Codomains to try for a bundled map of type F applied to an argument of type A: the type
    arguments of F (``MulAut G = G ≃* G``, ``M →+ N``, ...) that live in the same universe as A, last first."""
    seen, out = set(), []
    t = F
    for _ in range(4):
        if pb.kind(t) == "app":
            for x in reversed(pb.args(t)):
                if x in seen:
                    continue
                try:
                    if pb.kind(elab().whnf(elab().infer(x))) == "sort":
                        seen.add(x)
                        out.append(x)
                except Exception:
                    pass
        try:
            t2 = elab().whnf(t)
        except Exception:
            break
        if t2 == t:
            break
        t = t2
    return out


def exists_over(T, fn) -> Term:
    names = fn.__code__.co_varnames[:fn.__code__.co_argcount] or ("x",)
    xs = [pb.mk_fvar(n, type_handle(T)) for n in names]
    body = fn(*[_bound(x, T) for x in xs])
    from .terms import _prop
    h = _prop(body).h
    for x in reversed(xs):
        h = elab().apply("Exists", [pb.mk_lam_fvars([x], h)])
    return Term(h, "prop")


def forall_over(T, fn) -> Term:
    names = fn.__code__.co_varnames[:fn.__code__.co_argcount] or ("x",)
    xs = [pb.mk_fvar(n, type_handle(T)) for n in names]
    body = fn(*[_bound(x, T) for x in xs])
    from .terms import _prop
    return Term(pb.mk_pi_fvars(xs, _prop(body).h), "prop")


def _bound(x: int, T) -> Term:
    if isinstance(T, Sort):
        return Term(x, T.key)
    return wrap(x)


def set_of(fn, *, sort) -> Term:
    """``{x : T | P x}`` (``Set.ofPred``): ``set_of(lambda x: x * a == 0, sort=R)``."""
    var = fn.__code__.co_varnames[0] if fn.__code__.co_varnames else "x"
    x = pb.mk_fvar(var, type_handle(sort))
    from .terms import _prop
    body = _prop(fn(_bound(x, sort)))
    return wrap(elab().apply("Set.ofPred", [pb.mk_lam_fvars([x], body.h)]))


def subtype(s) -> LeanType:
    """``↥s`` for a set / subobject `s` (``Subtype (fun x => x ∈ s)``), usable as a type."""
    S = to_term(s)
    A = _elem_type(S)
    x = pb.mk_fvar("x", A)
    lam = pb.mk_lam_fvars([x], mem(Term(x, "other"), S).h)
    return LeanType.of(elab().apply("Subtype", [lam]), f"subtype({S})")


def _elem_type(S: Term) -> int:
    """The element type of a set-like term: `α` for `Set α`, else the carrier found via SetLike / Membership."""
    T = elab().infer(S.h)
    if pb.kind(T) == "app" and pb.kind(pb.head(T)) == "const" and pb.const_name(pb.head(T)) == "Set":
        return pb.args(T)[0]
    # SetLike A B: search the carrier among the type arguments
    for cand in reversed(pb.args(T)) if pb.kind(T) == "app" else []:
        try:
            if pb.kind(elab().whnf(elab().infer(cand))) != "sort":
                continue
            x = pb.mk_fvar("x", cand)
            elab().apply("Membership.mem", [S.h, x])
            return cand
        except Exception:
            continue
    raise PyraError(f"cannot find the element type of {S}")
