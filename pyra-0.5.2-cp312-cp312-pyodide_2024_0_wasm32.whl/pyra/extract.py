"""Feature 10 — verified code extraction to C++20, Rust and Numba-accelerated Python.

The computational content of verified code is compiled to another language
with the proof-only lines stripped (``assert``, recursive calls used as
induction hypotheses, ``pyra.inspect``/``print``/``breakpoint``):

* a ``@pyra.define`` definition becomes a function;
* a ``@prove`` theorem ending in ``return exists(w, P)`` becomes a function
  computing the witness ``w`` (e.g. ``infinite_primes`` -> a prime above n);
* proofs by cases and by induction keep their structure: a case split becomes
  an ``if``, and an induction hypothesis whose witness is unpacked
  (``k, hk = f(n - 1)``) becomes a recursive call ``k = f(n - 1)`` (it
  terminates: the proof showed the argument decreases).  Every branch must end
  in ``return exists(w, P)`` (or ``assert exists(w, P)``); the witness of a
  hypothesis has no computational content and is refused.

ℕ semantics are preserved exactly: truncated subtraction, ``x // 0 = 0``,
``x % 0 = x``.  Targets: C++20 uses GMP (arbitrary precision, exact); Rust
uses ``u128`` and Numba ``int64``, both with checked arithmetic that raises on
overflow instead of returning a wrong answer.
"""
from __future__ import annotations

import ast
import inspect
import textwrap
from dataclasses import dataclass, field

from .terms import PyraError

TARGETS = ("cpp", "rust", "numba")
PROOF_ONLY_CALLS = {"inspect", "print", "breakpoint", "has_deriv_at"}
LIBRARY = {"factorial", "min_fac", "is_prime", "gcd"}


class ExtractionError(PyraError):
    pass


@dataclass
class Extracted:
    target: str
    code: str
    entry: str                                # name of the entry-point function
    params: list
    stripped: list = field(default_factory=list)   # (line, source) of proof-only lines removed

    def __str__(self):
        return self.code


# --------------------------------------------------------------------------- front end
@dataclass
class _Fn:
    name: str
    params: list
    body: list                                 # simplified statements
    returns_bool: bool = False


def _source_tree(fn):
    src_lines, start = inspect.getsourcelines(fn)
    src = textwrap.dedent("".join(src_lines))
    tree = ast.parse(src)
    ast.increment_lineno(tree, start - 1)
    fdef = next(n for n in tree.body if isinstance(n, ast.FunctionDef))
    return fdef, src_lines, start


def _call_name(call):
    f = call.func
    return f.attr if isinstance(f, ast.Attribute) else getattr(f, "id", "")


def _is_exists(e):
    return isinstance(e, ast.Call) and _call_name(e) == "exists" and len(e.args) == 2


class _Ctx:
    """What the stripper needs to know about the function being extracted."""

    def __init__(self, fname, src_lines, start, stripped, theorem=False, globals_=None, hyp_params=(), n_params=0):
        self.fname, self.src_lines, self.start, self.stripped = fname, src_lines, start, stripped
        self.theorem = theorem                    # a @prove theorem (vs a @define definition)
        self.globals = globals_ or {}
        self.hyp_params = list(hyp_params)        # positions of hypothesis parameters (dropped)
        self.n_params = n_params                  # all parameters, hypotheses included
        self.facts = set()                        # local names bound to proofs (no computational content)
        self.theorems = []                        # other @prove theorems whose witnesses are used

    def line(self, st):
        i = st.lineno - self.start
        return self.src_lines[i].strip() if 0 <= i < len(self.src_lines) else ""

    def strip_line(self, st, what=None):
        self.stripped.append((st.lineno, what or self.line(st)))

    def proof_valued(self, call) -> bool:
        """Calls whose value is a proof: assume(...), the theorem itself (an induction hypothesis), another
        @prove theorem or a Lean lemma instance, or an established fact applied to arguments."""
        from .ast import ProvedTheorem
        from .terms import LeanConst
        name = _call_name(call)
        if name == "assume" or name in self.facts:
            return True
        if self.theorem and isinstance(call.func, ast.Name) and name == self.fname:
            return True
        obj = self.globals.get(name) if isinstance(call.func, ast.Name) else None
        if isinstance(obj, ProvedTheorem):
            return True
        if isinstance(obj, LeanConst) and obj.kind == "thm":
            return True
        if isinstance(call.func, ast.Call):                # LeanConst("...")(args)
            return True
        return False

    def drop_hyp_args(self, call):
        if self.hyp_params and len(call.args) == self.n_params:
            call.args = [a for i, a in enumerate(call.args) if i not in self.hyp_params]
        return call


def _is_proof_only(stmt, ctx):
    if isinstance(stmt, (ast.Assert, ast.Pass)):
        return True
    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
        return True                              # a call whose result is unused has no computational content
    if isinstance(stmt, ast.Expr):
        return True                              # a bare expression (docstring, ...)
    if (isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name)
            and isinstance(stmt.value, ast.Call) and ctx.proof_valued(stmt.value)):
        ctx.facts.add(stmt.targets[0].id)        # `h = assume(...)`, `ih = f(n - 1)`, `h2 = lemma(n)`: a proof
        return True
    return False


def _obtain(st, ctx):
    """`k, hk = E` with E : ∃ x, P x  ->  `k = <witness of E>` (or an error if E has no computational content)."""
    from .ast import ProvedTheorem
    k, hk = st.targets[0].elts
    v = st.value
    ctx.facts.add(hk.id)
    if isinstance(v, ast.Call) and isinstance(v.func, ast.Name):
        if ctx.theorem and v.func.id == ctx.fname:
            ctx.strip_line(st, f"{ctx.line(st)}  → {k.id} = {ast.unparse(v)} (witness of the induction hypothesis)")
            return ast.copy_location(ast.Assign(targets=[ast.Name(id=k.id, ctx=ast.Store())], value=ctx.drop_hyp_args(v)), st)
        obj = ctx.globals.get(v.func.id)
        if isinstance(obj, ProvedTheorem):
            ctx.theorems.append(obj)
            n_all = len(inspect.signature(obj.__wrapped__).parameters)
            hyp = _hyp_positions(obj)
            if hyp and len(v.args) == n_all:
                v.args = [a for i, a in enumerate(v.args) if i not in hyp]
            ctx.strip_line(st, f"{ctx.line(st)}  → {k.id} = {ast.unparse(v)} (witness of a verified lemma)")
            return ast.copy_location(ast.Assign(targets=[ast.Name(id=k.id, ctx=ast.Store())], value=v), st)
    raise ExtractionError(f"line {st.lineno}: the witness `{k.id}` is unpacked from `{ast.unparse(v)}`, which has no "
                          "computational content (a hypothesis or a fact); only witnesses of the induction hypothesis "
                          "or of other verified @prove theorems can be extracted")


def _strip(stmts, ctx):
    out = []
    stmts = list(stmts)
    if ctx.theorem and stmts and isinstance(stmts[-1], ast.Assert) and _is_exists(stmts[-1].test):
        # a block ending in `assert exists(w, P)` establishes the theorem with witness w
        last = stmts[-1]
        stmts[-1] = ast.copy_location(ast.Return(value=last.test), last)
    for st in stmts:
        if _is_proof_only(st, ctx):
            ctx.strip_line(st)
            continue
        if (isinstance(st, ast.Assign) and len(st.targets) == 1 and isinstance(st.targets[0], ast.Tuple)
                and len(st.targets[0].elts) == 2 and all(isinstance(e, ast.Name) for e in st.targets[0].elts)
                and not isinstance(st.value, (ast.Tuple, ast.List))):
            out.append(_obtain(st, ctx))
            continue
        if isinstance(st, ast.If):
            st.body = _strip(st.body, ctx) or [ast.Pass()]
            st.orelse = _strip(st.orelse, ctx)
        elif ctx.theorem and isinstance(st, ast.Return):
            if not _is_exists(st.value):
                raise ExtractionError(f"line {st.lineno}: `return {ast.unparse(st.value) if st.value else ''}` has no witness; "
                                      "every branch of an extracted proof must end in `return exists(witness, ...)`")
            ctx.strip_line(st, f"{ctx.line(st)}  → return {ast.unparse(st.value.args[0])}")
            st.value = st.value.args[0]
        out.append(st)
    return out


def _ends(stmts) -> bool:
    if not stmts:
        return False
    last = stmts[-1]
    if isinstance(last, ast.Return):
        return True
    if isinstance(last, ast.If):
        return _ends(last.body) and _ends(last.orelse)
    return False


def _check_paths(stmts, fname, line, tail=True):
    """Every path of an extracted proof must return a witness.  An `if` without `else` followed by more
    statements is a case split whose else-branch is the rest of the block (as in the proof), so its
    then-branch must return."""
    for i, st in enumerate(stmts):
        if isinstance(st, ast.If):
            last = i == len(stmts) - 1
            if not st.orelse and not last:
                if not _ends(st.body):
                    raise ExtractionError(f"line {st.lineno}: this branch of {fname} does not end in `return exists(witness, ...)`, "
                                          "so it has no witness to extract")
                _check_paths(st.body, fname, st.lineno, True)
            else:
                _check_paths(st.body, fname, st.lineno, tail and last)
                if st.orelse:
                    _check_paths(st.orelse, fname, st.lineno, tail and last)
    if tail and not _ends(stmts):
        bad = stmts[-1].lineno if stmts else line
        raise ExtractionError(f"line {bad}: a branch of {fname} does not end in `return exists(witness, ...)`, "
                              "so it has no witness to extract")


def _deps(stmts, known):
    names = set()
    for st in stmts:
        for n in ast.walk(st):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
                names.add(n.func.id)
    return [known[n] for n in sorted(names) if n in known]


def _hyp_positions(thm) -> list:
    sig = inspect.signature(thm.__wrapped__)
    return [i for i, p in enumerate(sig.parameters) if p not in thm.params]


def _check_nat_params(fn, params, what):
    from .terms import Sort
    sig = inspect.signature(fn)
    for p in params:
        ann = sig.parameters[p].annotation
        if isinstance(ann, str):
            try:
                ann = eval(ann, fn.__globals__)
            except Exception:
                pass
        if not (isinstance(ann, Sort) and ann.key == "nat"):
            raise ExtractionError(f"{what}: parameter `{p}` has type {ann!r}; extraction supports ℕ (Nat) parameters only")


def _exists_sort(statement):
    from . import pyra_bind as pb
    h = statement
    while pb.kind(h) == "pi":
        h = pb.binder_body(h)
    if pb.kind(h) == "app" and pb.kind(pb.head(h)) == "const" and pb.const_name(pb.head(h)) == "Exists":
        lam = pb.args(h)[1]
        t = pb.binder_type(lam) if pb.kind(lam) == "lam" else None
        return pb.const_name(t) if t is not None and pb.kind(t) == "const" else "?"
    return None


def _collect(obj):
    """(functions in dependency order, entry name, stripped lines)."""
    from .ast import ProvedTheorem
    from .definitions import Definition
    stripped = []
    fns = []
    seen = {}

    def add_definition(d):
        if d.__name__ in seen:
            return
        seen[d.__name__] = d
        if any(s.key != "nat" for _, s in d.params):
            raise ExtractionError(f"{d.__name__}: extraction supports ℕ (Nat) parameters only")
        fdef, lines, start = _source_tree(d.fn)
        ctx = _Ctx(fdef.name, lines, start, stripped)
        body = _strip(fdef.body, ctx)
        known = {k: v for k, v in d.fn.__globals__.items() if isinstance(v, Definition)}
        for dep in _deps(body, known):
            if dep is not d:
                add_definition(dep)
        fns.append(_Fn(fdef.name, [p for p, _ in d.params], body))

    def add_theorem(t):
        if t.__name__ in seen:
            return
        seen[t.__name__] = t
        if not t.verified:
            raise ExtractionError(f"{t.__name__} is not fully kernel-verified; refusing to extract it")
        sort = _exists_sort(t.statement)
        if sort is None:
            raise ExtractionError(f"{t.__name__} has no computational content: it does not end in `return exists(witness, ...)`")
        if sort != "Nat":
            raise ExtractionError(f"{t.__name__}: its witness has type {sort}; extraction supports ℕ (Nat) witnesses only")
        fn = t.__wrapped__
        _check_nat_params(fn, t.params, t.__name__)
        fdef, lines, start = _source_tree(fn)
        hyp = _hyp_positions(t)
        ctx = _Ctx(fdef.name, lines, start, stripped, theorem=True, globals_=fn.__globals__, hyp_params=hyp,
                   n_params=len(fdef.args.args))
        ctx.facts.update(a.arg for i, a in enumerate(fdef.args.args) if i in hyp)
        body = _strip(fdef.body, ctx)
        _check_paths(body, fdef.name, fdef.lineno)
        known = {k: v for k, v in fn.__globals__.items() if isinstance(v, Definition)}
        for dep in _deps(body, known):
            add_definition(dep)
        for dep in ctx.theorems:
            add_theorem(dep)
        fns.append(_Fn(fdef.name, list(t.params), body))

    if isinstance(obj, Definition):
        add_definition(obj)
        return fns, obj.__name__, stripped
    if isinstance(obj, ProvedTheorem):
        add_theorem(obj)
        return fns, obj.__name__, stripped
    raise ExtractionError("extract() expects a @pyra.define definition or a @prove theorem")


# --------------------------------------------------------------------------- expression printer
class _Printer:
    target = ""

    def expr(self, e) -> str:
        if isinstance(e, ast.Constant):
            if isinstance(e.value, bool):
                return self.boolean(e.value)
            if isinstance(e.value, int) and e.value >= 0:
                return self.lit(e.value)
            raise ExtractionError(f"unsupported constant {e.value!r} (only natural numbers)")
        if isinstance(e, ast.Name):
            return e.id
        if isinstance(e, ast.BinOp):
            ops = {ast.Add: "add", ast.Sub: "sub", ast.Mult: "mul", ast.FloorDiv: "div", ast.Mod: "mod", ast.Pow: "pow"}
            op = ops.get(type(e.op))
            if op is None:
                raise ExtractionError(f"operator {type(e.op).__name__} is not available on ℕ")
            return f"{self.rt(op)}({self.expr(e.left)}, {self.expr(e.right)})"
        if isinstance(e, ast.Compare) and len(e.ops) == 1:
            ops = {ast.Lt: "<", ast.LtE: "<=", ast.Gt: ">", ast.GtE: ">=", ast.Eq: "==", ast.NotEq: "!="}
            return f"({self.expr(e.left)} {ops[type(e.ops[0])]} {self.expr(e.comparators[0])})"
        if isinstance(e, ast.BoolOp):
            sep = self.and_ if isinstance(e.op, ast.And) else self.or_
            return "(" + f" {sep} ".join(self.expr(v) for v in e.values) + ")"
        if isinstance(e, ast.UnaryOp) and isinstance(e.op, ast.Not):
            return f"{self.not_}({self.expr(e.operand)})"
        if isinstance(e, ast.IfExp):
            return self.ifexp(self.expr(e.test), self.expr(e.body), self.expr(e.orelse))
        if isinstance(e, ast.Call):
            f = e.func
            if isinstance(f, ast.Attribute) and f.attr == "factorial" and not e.args:
                return f"{self.rt('factorial')}({self.expr(f.value)})"
            if isinstance(f, ast.Attribute) and f.attr == "min_fac" and not e.args:
                return f"{self.rt('min_fac')}({self.expr(f.value)})"
            name = getattr(f, "id", None)
            if name in LIBRARY:
                return f"{self.rt(name)}({', '.join(self.expr(a) for a in e.args)})"
            if name == "sum" and len(e.args) == 1 and isinstance(e.args[0], ast.Call) and getattr(e.args[0].func, "id", "") == "range":
                return f"{self.rt('sum_range')}({self.expr(e.args[0].args[0])})"
            if name:
                return f"{name}({', '.join(self.expr(a) for a in e.args)})"
        raise ExtractionError(f"cannot extract `{ast.unparse(e)}`")

    def stmts(self, body, indent, ret_ty):
        out = []
        for st in body:
            pad = "    " * indent
            if isinstance(st, ast.Assign) and len(st.targets) == 1 and isinstance(st.targets[0], ast.Name):
                out.append(pad + self.let(st.targets[0].id, self.expr(st.value)))
            elif isinstance(st, ast.Return):
                out.append(pad + self.ret(self.expr(st.value)))
            elif isinstance(st, ast.If):
                out.append(pad + self.if_head(self.expr(st.test)))
                out += self.stmts(st.body, indent + 1, ret_ty)
                if st.orelse:
                    out.append(pad + self.else_head())
                    out += self.stmts(st.orelse, indent + 1, ret_ty)
                out.append(pad + self.block_end())
            elif isinstance(st, ast.Pass):
                pass
            else:
                raise ExtractionError(f"cannot extract statement `{ast.unparse(st)}`")
        return out


class _Cpp(_Printer):
    target, and_, or_, not_ = "cpp", "&&", "||", "!"
    RUNTIME = r"""// ---- Pyra runtime: exact ℕ semantics (as in Lean) on GMP integers
#include <gmpxx.h>
#include <iostream>
#include <string>
using Nat = mpz_class;
inline Nat pyra_add(const Nat& a, const Nat& b) { return a + b; }
inline Nat pyra_sub(const Nat& a, const Nat& b) { return a >= b ? Nat(a - b) : Nat(0); }   // truncated
inline Nat pyra_mul(const Nat& a, const Nat& b) { return a * b; }
inline Nat pyra_div(const Nat& a, const Nat& b) { return b == 0 ? Nat(0) : Nat(a / b); }
inline Nat pyra_mod(const Nat& a, const Nat& b) { return b == 0 ? a : Nat(a % b); }
inline Nat pyra_pow(const Nat& a, const Nat& b) { Nat r; mpz_pow_ui(r.get_mpz_t(), a.get_mpz_t(), b.get_ui()); return r; }
inline Nat pyra_factorial(const Nat& n) { Nat r = 1; for (Nat i = 2; i <= n; ++i) r *= i; return r; }
inline Nat pyra_min_fac(const Nat& n) {
    if (n == 0) return 2; if (n == 1) return 1; if (n % 2 == 0) return 2;
    for (Nat k = 3; k * k <= n; k += 2) if (n % k == 0) return k;
    return n;
}
inline bool pyra_is_prime(const Nat& n) { return n >= 2 && pyra_min_fac(n) == n; }
inline Nat pyra_gcd(const Nat& a, const Nat& b) { Nat r; mpz_gcd(r.get_mpz_t(), a.get_mpz_t(), b.get_mpz_t()); return r; }
inline Nat pyra_sum_range(const Nat& n) { return n == 0 ? Nat(0) : Nat(n * (n - 1) / 2); }
"""

    def rt(self, op): return f"pyra_{op}"
    def lit(self, v): return f"Nat(\"{v}\")"
    def boolean(self, v): return "true" if v else "false"
    def ifexp(self, c, a, b): return f"({c} ? Nat({a}) : Nat({b}))"
    def let(self, n, v): return f"const Nat {n} = {v};"
    def ret(self, v): return f"return {v};"
    def if_head(self, c): return f"if ({c}) {{"
    def else_head(self): return "} else {"
    def block_end(self): return "}"

    def function(self, fn):
        params = ", ".join(f"const Nat& {p}" for p in fn.params)
        lines = [f"Nat {fn.name}({params}) {{"] + self.stmts(fn.body, 1, "Nat") + ["}"]
        return "\n".join(lines)

    def module(self, fns, entry, with_main):
        decls = "\n".join(f"Nat {f.name}({', '.join('const Nat&' for _ in f.params)});" for f in fns)
        code = self.RUNTIME + "\n// ---- extracted from verified Pyra code (proof-only lines stripped)\n" + decls + "\n\n" + \
            "\n\n".join(self.function(f) for f in fns) + "\n"
        if with_main:
            e = next(f for f in fns if f.name == entry)
            args = ", ".join(f"Nat(argv[{i + 1}])" for i in range(len(e.params)))
            code += f"\nint main(int argc, char** argv) {{\n    if (argc != {len(e.params) + 1}) return 2;\n" \
                    f"    std::cout << {entry}({args}).get_str() << std::endl;\n    return 0;\n}}\n"
        return code


class _Rust(_Printer):
    target, and_, or_, not_ = "rust", "&&", "||", "!"
    RUNTIME = r"""// ---- Pyra runtime: ℕ semantics (as in Lean) on u128; overflow panics instead of wrapping
#![allow(dead_code, non_snake_case, unused_parens)]
use std::convert::TryFrom;
type Nat = u128;
fn pyra_add(a: Nat, b: Nat) -> Nat { a.checked_add(b).expect("pyra: overflow") }
fn pyra_sub(a: Nat, b: Nat) -> Nat { if a >= b { a - b } else { 0 } }   // truncated
fn pyra_mul(a: Nat, b: Nat) -> Nat { a.checked_mul(b).expect("pyra: overflow") }
fn pyra_div(a: Nat, b: Nat) -> Nat { if b == 0 { 0 } else { a / b } }
fn pyra_mod(a: Nat, b: Nat) -> Nat { if b == 0 { a } else { a % b } }
fn pyra_pow(a: Nat, b: Nat) -> Nat { a.checked_pow(u32::try_from(b).expect("pyra: overflow")).expect("pyra: overflow") }
fn pyra_factorial(n: Nat) -> Nat { let mut r: Nat = 1; let mut i: Nat = 2; while i <= n { r = pyra_mul(r, i); i += 1; } r }
fn pyra_min_fac(n: Nat) -> Nat {
    if n == 0 { return 2; } if n == 1 { return 1; } if n % 2 == 0 { return 2; }
    let mut k: Nat = 3; while k * k <= n { if n % k == 0 { return k; } k += 2; } n
}
fn pyra_is_prime(n: Nat) -> bool { n >= 2 && pyra_min_fac(n) == n }
fn pyra_gcd(a: Nat, b: Nat) -> Nat { if b == 0 { a } else { pyra_gcd(b, a % b) } }
fn pyra_sum_range(n: Nat) -> Nat { if n == 0 { 0 } else { pyra_mul(n, n - 1) / 2 } }
"""

    def rt(self, op): return f"pyra_{op}"
    def lit(self, v): return f"{v}u128"
    def boolean(self, v): return "true" if v else "false"
    def ifexp(self, c, a, b): return f"(if {c} {{ {a} }} else {{ {b} }})"
    def let(self, n, v): return f"let {n}: Nat = {v};"
    def ret(self, v): return f"return {v};"
    def if_head(self, c): return f"if {c} {{"
    def else_head(self): return "} else {"
    def block_end(self): return "}"

    def function(self, fn):
        params = ", ".join(f"{p}: Nat" for p in fn.params)
        return "\n".join([f"pub fn {fn.name}({params}) -> Nat {{"] + self.stmts(fn.body, 1, "Nat") + ["}"])

    def module(self, fns, entry, with_main):
        code = self.RUNTIME + "\n// ---- extracted from verified Pyra code (proof-only lines stripped)\n" + \
            "\n\n".join(self.function(f) for f in fns) + "\n"
        if with_main:
            e = next(f for f in fns if f.name == entry)
            args = ", ".join(f"a[{i + 1}].parse::<Nat>().unwrap()" for i in range(len(e.params)))
            code += f"\nfn main() {{\n    let a: Vec<String> = std::env::args().collect();\n    println!(\"{{}}\", {entry}({args}));\n}}\n"
        return code


class _Numba(_Printer):
    target, and_, or_, not_ = "numba", "and", "or", "not "
    RUNTIME = '''"""Extracted by Pyra from verified code (proof-only lines stripped). Numba-compiled, int64,
with overflow checks (raises OverflowError instead of returning a wrong answer)."""
import numba

_MAX = 2 ** 63 - 1


@numba.njit(cache=False)
def pyra_add(a, b):
    r = a + b
    if r < a:
        raise OverflowError("pyra: overflow")
    return r


@numba.njit(cache=False)
def pyra_sub(a, b):
    return a - b if a >= b else 0            # truncated, as on Lean's Nat


@numba.njit(cache=False)
def pyra_mul(a, b):
    if a != 0 and b > _MAX // a:
        raise OverflowError("pyra: overflow")
    return a * b


@numba.njit(cache=False)
def pyra_div(a, b):
    return 0 if b == 0 else a // b


@numba.njit(cache=False)
def pyra_mod(a, b):
    return a if b == 0 else a % b


@numba.njit(cache=False)
def pyra_pow(a, b):
    r = 1
    for _ in range(b):
        r = pyra_mul(r, a)
    return r


@numba.njit(cache=False)
def pyra_factorial(n):
    r = 1
    for i in range(2, n + 1):
        r = pyra_mul(r, i)
    return r


@numba.njit(cache=False)
def pyra_min_fac(n):
    if n == 0:
        return 2
    if n == 1:
        return 1
    if n % 2 == 0:
        return 2
    k = 3
    while k * k <= n:
        if n % k == 0:
            return k
        k += 2
    return n


@numba.njit(cache=False)
def pyra_is_prime(n):
    return n >= 2 and pyra_min_fac(n) == n


@numba.njit(cache=False)
def pyra_gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a


@numba.njit(cache=False)
def pyra_sum_range(n):
    return 0 if n == 0 else pyra_mul(n, n - 1) // 2
'''

    def rt(self, op): return f"pyra_{op}"
    def lit(self, v):
        if v > 2 ** 63 - 1:
            raise ExtractionError("literal does not fit the int64 Numba target")
        return str(v)
    def boolean(self, v): return "True" if v else "False"
    def ifexp(self, c, a, b): return f"({a} if {c} else {b})"
    def let(self, n, v): return f"{n} = {v}"
    def ret(self, v): return f"return {v}"
    def if_head(self, c): return f"if {c}:"
    def else_head(self): return "else:"
    def block_end(self): return ""

    def function(self, fn):
        return "\n".join(["@numba.njit(cache=False)", f"def {fn.name}({', '.join(fn.params)}):"] +
                         [l for l in self.stmts(fn.body, 1, "") if l.strip()])

    def module(self, fns, entry, with_main):
        return self.RUNTIME + "\n\n" + "\n\n\n".join(self.function(f) for f in fns) + "\n"


_PRINTERS = {"cpp": _Cpp, "rust": _Rust, "numba": _Numba}


def extract(obj, target: str = "cpp", *, main: bool = False) -> Extracted:
    """Extract verified code to `target` ('cpp', 'rust' or 'numba')."""
    if target not in _PRINTERS:
        raise ExtractionError(f"unknown target {target!r}; choose one of {TARGETS}")
    from .ast import ProvedTheorem
    if isinstance(obj, ProvedTheorem) and not obj.verified:
        raise ExtractionError(f"{obj.__name__} is not fully kernel-verified; refusing to extract it")
    fns, entry, stripped = _collect(obj)
    printer = _PRINTERS[target]()
    code = printer.module(fns, entry, main)
    params = next(f.params for f in fns if f.name == entry)
    return Extracted(target, code, entry, params, sorted(set(stripped)))


def load_numba(ex: Extracted):
    """Compile an extracted Numba module and return its entry point."""
    if ex.target != "numba":
        raise ExtractionError("not a Numba extraction")
    ns = {}
    exec(compile(ex.code, f"<pyra-extracted {ex.entry}>", "exec"), ns)
    return ns[ex.entry]
