"""Layer 1 — the Python AST frontend (``@prove``).

``@prove`` intercepts a function before Python runs it and rewrites its AST:

* ``assert e``                    -> a subgoal discharged by the pyra_elab waterfall
* ``if n == 0: … else: …`` + a recursive call -> ``Nat`` induction (an eliminator)
* ``f(n - 1)`` (recursive call)   -> the induction hypothesis
* ``if c: … else: …`` (otherwise) -> a case split on ``c``
* ``return exists(w, P)``         -> the conclusion, proved with witness ``w``
* ``and`` / ``or`` / ``not`` / chained comparisons -> logical connectives
* ``sum(range(n))``, ``sum(f(i) for i in range(n))`` -> ``Finset.sum``

The rewritten function then runs as normal Python with symbolic arguments, so
``print``, ``breakpoint()``/``pdb`` and editor breakpoints work on the
original file and line numbers.
"""
from __future__ import annotations

import ast
import builtins
import dataclasses
import functools
import inspect
import re
import sys
import textwrap
import types

from . import pyra_bind as pb
from . import runtime
from .kernel import elab, kernel
from .terms import SORTS, ElaborationError, Fact, PyraError, Sort, Term, pretty


def to_prop(value, what):
    from .terms import to_term
    t = to_term(value)
    if t.sort != "prop":
        raise ProofSyntaxError(f"hypothesis {what}: expected a proposition, got {t}")
    return t

_BUILTIN_MAP = {"sum": "sum_", "range": "range_", "min": "min_", "max": "max_", "abs": "abs_", "len": "len_", "filter": "filter_"}
# math functions with a Mathlib counterpart (pyra/finset.py): `math.floor(x)` or a bare `floor(x)` imported from math
_MATH_FNS = ("floor", "ceil", "sqrt", "isqrt", "gcd", "lcm", "factorial", "comb", "log", "log2", "log10", "exp", "prod")


class ProofSyntaxError(PyraError, SyntaxError):
    pass


def _syntax_error(node, message, hint):
    return ProofSyntaxError(f"line {getattr(node, 'lineno', '?')}: {message}\n  hint: {hint}")


_STATEMENT_HINT = ("case splits (`if`) must be statements of the proof body itself (or of its branches), not inside "
                   "loops, `with` or `try` blocks; move the split out of the loop, or use `x if c else y` inside an expression")


def _call(name, args):
    return ast.Call(func=ast.Attribute(value=ast.Name(id="__pyra__", ctx=ast.Load()), attr=name, ctx=ast.Load()), args=args, keywords=[])


def _lam(body, args=()):
    return ast.Lambda(args=ast.arguments(posonlyargs=[], args=[ast.arg(arg=a) for a in args], kwonlyargs=[], kw_defaults=[], defaults=[]), body=body)


class _Analyzer(ast.NodeVisitor):
    def __init__(self, fname):
        self.fname = fname
        self.assigned = set()

    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Store):
            self.assigned.add(node.id)


def _calls_self(node, fname) -> bool:
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name) and sub.func.id == fname:
            return True
    return False


def _induction_param(test, params):
    """`n == 0` / `0 == n` on a parameter -> 'n'."""
    if isinstance(test, ast.Compare) and len(test.ops) == 1 and isinstance(test.ops[0], ast.Eq):
        l, r = test.left, test.comparators[0]
        for a, b in ((l, r), (r, l)):
            if isinstance(a, ast.Name) and a.id in params and isinstance(b, ast.Constant) and b.value == 0:
                return a.id
    return None


def _final_claim(stmts):
    """The expression a block establishes: its `return` or its last `assert`."""
    if not stmts:
        return None
    last = stmts[-1]
    if isinstance(last, ast.Return) and last.value is not None:
        return last.value
    if isinstance(last, ast.Assert):
        return last.test
    if isinstance(last, ast.If) and last.orelse:
        return _final_claim(last.orelse)
    return None


class ProofTransformer(ast.NodeTransformer):
    def __init__(self, fname, params, shadowed):
        self.fname = fname
        self.params = params
        self.shadowed = shadowed

    # -- expressions ------------------------------------------------------
    def visit_Constant(self, node):
        if isinstance(node.value, complex):
            raise _syntax_error(node, f"the complex literal {node.value!r} is not supported in proofs",
                                "Pyra's number types are Nat, Int, Rat and Real")
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            return ast.copy_location(_call("num", [node]), node)
        return node

    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Load) and node.id in _BUILTIN_MAP and node.id not in self.shadowed:
            return ast.copy_location(ast.Attribute(value=ast.Name(id="__pyra__", ctx=ast.Load()), attr=_BUILTIN_MAP[node.id], ctx=ast.Load()), node)
        return node

    def visit_BoolOp(self, node):
        values = [self.visit(v) for v in node.values]
        return ast.copy_location(_call("and_" if isinstance(node.op, ast.And) else "or_", values), node)

    def visit_UnaryOp(self, node):
        if isinstance(node.op, ast.Not):
            return ast.copy_location(_call("not_", [self.visit(node.operand)]), node)
        return self.generic_visit(node)

    def visit_IfExp(self, node):
        return ast.copy_location(_call("ite", [self.visit(node.test), self.visit(node.body), self.visit(node.orelse)]), node)

    def visit_Compare(self, node):
        left = self.visit(node.left)
        comps = [self.visit(c) for c in node.comparators]
        parts = []
        cur = left
        for op, c in zip(node.ops, comps):
            if isinstance(op, (ast.Is, ast.IsNot)):
                raise _syntax_error(node, f"'{type(op).__name__}' is not supported in proofs",
                                    "`is` compares Python objects, not mathematical values; write == for equality")
            if isinstance(op, (ast.In, ast.NotIn)) and isinstance(c, (ast.List, ast.Tuple)):
                raise _syntax_error(node, f"'{type(op).__name__}' on a Python {type(c).__name__.lower()} is not supported in proofs",
                                    "a list or tuple is a Python object, not a mathematical set; write `x == a or x == b`, "
                                    "or use a Finset / Set (e.g. x in Icc(1, 2))")
            if isinstance(op, (ast.In, ast.NotIn)):        # x in S  ->  x ∈ S (Membership.mem)
                m = _call("mem", [cur, c])
                parts.append(m if isinstance(op, ast.In) else _call("not_", [m]))
                cur = c
                continue
            parts.append(ast.Compare(left=cur, ops=[op], comparators=[c]))
            cur = c
        if len(parts) == 1:
            return ast.copy_location(parts[0], node)
        return ast.copy_location(_call("and_", parts), node)

    def _comprehension(self, kind, comp, fallback):
        """sum/prod/len of a comprehension, or a set comprehension: Finset sums, products, cards and filters
        when it ranges over a Pyra finset (decided at run time), ordinary Python otherwise."""
        gens = comp.generators
        if len(gens) != 1 or not isinstance(gens[0].target, ast.Name) or gens[0].is_async:
            return None
        g = gens[0]
        var = g.target.id
        elt = self.visit(_clone(comp.elt))
        it = self.visit(_clone(g.iter))
        cond = ast.Constant(None)
        if g.ifs:
            cs = [self.visit(_clone(c)) for c in g.ifs]
            cond = _lam(cs[0] if len(cs) == 1 else _call("and_", cs), [var])
        return _call("comprehension", [ast.Constant(kind), _lam(elt, [var]), it, cond, _lam(fallback)])

    def visit_SetComp(self, node):
        r = self._comprehension("set", node, self.generic_visit(_clone(node)))
        return ast.copy_location(r, node) if r is not None else self.generic_visit(node)

    def visit_Call(self, node):
        f = node.func
        # sum(E for i in s if p) / prod(...) / len([...]) / math.prod(...): Finset sums, products and cards
        # sum(E for i in range(K)) / prod(...): Finset.sum over range K (any number type for E)
        if (isinstance(f, ast.Name) and f.id in ("sum", "prod") and f.id not in self.shadowed and len(node.args) == 1
                and isinstance(node.args[0], ast.GeneratorExp)):
            g = node.args[0]
            if (len(g.generators) == 1 and not g.generators[0].ifs and isinstance(g.generators[0].target, ast.Name)
                    and isinstance(g.generators[0].iter, ast.Call) and isinstance(g.generators[0].iter.func, ast.Name)
                    and g.generators[0].iter.func.id == "range" and len(g.generators[0].iter.args) == 1):
                var = g.generators[0].target.id
                body = self.visit(g.elt)
                bound = self.visit(g.generators[0].iter.args[0])
                return ast.copy_location(_call("sum_over" if f.id == "sum" else "prod_over", [_lam(body, [var]), bound]), node)
        agg = None
        if isinstance(f, ast.Name) and f.id in ("sum", "prod", "len") and f.id not in self.shadowed:
            agg = f.id
        elif isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id == "math" and f.attr == "prod":
            agg = "prod"
        if (agg and len(node.args) == 1 and not node.keywords
                and isinstance(node.args[0], (ast.GeneratorExp, ast.ListComp, ast.SetComp))):
            orig = ast.Call(func=self.visit(_clone(f)), args=[self.generic_visit(_clone(node.args[0]))], keywords=[])
            r = self._comprehension(agg, node.args[0], orig)
            if r is not None:
                return ast.copy_location(r, node)
        # math.floor(x), math.sqrt(x), ... and the same functions imported from math
        if (isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id == "math" and "math" not in self.shadowed
                and f.attr in _MATH_FNS and not node.keywords):
            args = [self.visit(a) for a in node.args]
            return ast.copy_location(_call("builtin", [ast.Constant(f.attr), ast.Constant(None)] + args), node)
        if isinstance(f, ast.Name) and f.id in _MATH_FNS and f.id not in self.shadowed and f.id != self.fname and not node.keywords:
            args = [self.visit(a) for a in node.args]
            return ast.copy_location(_call("builtin", [ast.Constant(f.id), ast.Name(id=f.id, ctx=ast.Load())] + args), node)
        if (isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id == "math" and f.attr in ("prod", "fsum")
                and len(node.args) == 1 and isinstance(node.args[0], ast.GeneratorExp)):
            # math.prod(E for i in range(K)) / math.fsum(...): the same as prod(...) / sum(...)
            alias = ast.Call(func=ast.Name(id="prod" if f.attr == "prod" else "sum", ctx=ast.Load()), args=node.args, keywords=[])
            if alias.func.id not in self.shadowed:
                return self.visit_Call(ast.copy_location(alias, node))
        if isinstance(f, ast.Name) and f.id == self.fname:
            if node.keywords or any(isinstance(a, ast.Starred) for a in node.args):
                raise _syntax_error(node, f"the recursive call {ast.unparse(node)} uses keyword or *starred arguments",
                                    "pass the arguments positionally, in the order of the parameters (e.g. f(n - 1))")
            args = [self.visit(a) for a in node.args]
            return ast.copy_location(_call("recurse", [_lam(ast.Tuple(elts=args, ctx=ast.Load())), ast.Constant(node.lineno)]), node)
        return self.generic_visit(node)

    # -- statements -------------------------------------------------------
    def visit_Assert(self, node):
        test = self.visit(node.test)
        return ast.copy_location(ast.Expr(_call("assert_", [_lam(test), ast.Constant(node.lineno)])), node)

    def visit_Expr(self, node):
        # `assume(P)` / `h = assume(P)` -> a hypothesis binder of the theorem
        v = node.value
        if isinstance(v, ast.Call) and isinstance(v.func, ast.Name) and v.func.id == "assume" and "assume" not in self.shadowed:
            return ast.copy_location(ast.Expr(self._assume_call(v)), node)
        return self.generic_visit(node)

    def _assume_call(self, v, name=None):
        if len(v.args) != 1:
            raise ProofSyntaxError(f"line {v.lineno}: assume(...) takes one proposition")
        args = [_lam(self.visit(v.args[0])), ast.Constant(v.lineno)]
        if name:
            args.append(ast.Constant(name))
        return _call("assume", args)

    def visit_Return(self, node):
        if node.value is None:
            return None
        return ast.copy_location(ast.Expr(_call("conclude", [_lam(self.visit(node.value)), ast.Constant(node.lineno)])), node)

    def visit_Assign(self, node):
        v = node.value
        if (len(node.targets) == 1 and isinstance(node.targets[0], ast.Tuple) and not isinstance(v, (ast.Tuple, ast.List))
                and all(isinstance(e, ast.Name) for e in node.targets[0].elts)):
            # `k, hk = h` with h : ∃ x, P x -> ∃-elimination (ordinary unpacking for anything else)
            names = ast.Tuple(elts=[ast.Constant(e.id) for e in node.targets[0].elts], ctx=ast.Load())
            node.value = _call("unpack", [_lam(self.visit(v)), names, ast.Constant(node.lineno)])
            return node
        if (isinstance(v, ast.Call) and isinstance(v.func, ast.Name) and v.func.id == "assume" and "assume" not in self.shadowed
                and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)):
            node.value = self._assume_call(v, node.targets[0].id)
            return node
        node.value = self.visit(node.value)
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            node.value = _call("name", [ast.Constant(node.targets[0].id), node.value])
        return node

    def visit_FunctionDef(self, node):
        return node            # nested functions are left alone

    def statement_call(self, claim, at):
        """``set_statement(lambda: <claim>, line[, alt])``.  When the claim is ``exists(w, P)`` and the witness
        is computed inside the proof (e.g. from an unpacked induction hypothesis), the statement is
        ``exists(lambda w: P)`` instead (`alt`): the witness is abstracted away."""
        args = [_lam(self.visit(_clone(claim))), ast.Constant(at.lineno)]
        if (isinstance(claim, ast.Call) and len(claim.args) == 2 and isinstance(claim.func, (ast.Name, ast.Attribute))
                and (claim.func.id if isinstance(claim.func, ast.Name) else claim.func.attr) == "exists"):
            w, body = claim.args
            used = {n.id for n in ast.walk(claim) if isinstance(n, ast.Name)}
            var = w.id if isinstance(w, ast.Name) else next(c for c in ("w", "w1", "w2", "w3", "__pyra_w") if c not in used)
            target = ast.dump(w)

            class _Abstract(ast.NodeTransformer):
                def visit(self, node):
                    if isinstance(node, ast.expr) and ast.dump(node) == target:
                        return ast.Name(id=var, ctx=ast.Load())
                    return super().visit(node)

            body2 = _Abstract().visit(_clone(body))
            alt = ast.Call(func=_clone(claim.func), args=[_lam(self.visit(body2), [var])],
                           keywords=[ast.keyword(arg=k.arg, value=_clone(k.value)) for k in claim.keywords])
            args.append(_lam(alt))
        return ast.copy_location(ast.Expr(_call("set_statement", args)), at)

    def visit_If(self, node):
        # statement-level `if`s are handled by transform_block; this one is nested in a loop / with / try
        raise _syntax_error(node, "an `if` statement inside a loop or a with-block is not supported in proofs", _STATEMENT_HINT)

    def visit_Try(self, node):
        raise _syntax_error(node, "try/except is not supported in proofs",
                            "an unproved assert does not raise (it is reported in the proof's trust report), and catching "
                            "elaboration errors would silently drop parts of the proof; remove the try block")

    visit_TryStar = visit_Try

    def visit_While(self, node):
        if _contains_if(node):
            raise _syntax_error(node, "an `if` statement inside a while loop is not supported in proofs", _STATEMENT_HINT)
        return self.generic_visit(node)

    def visit_For(self, node):
        if _contains_if(node):
            raise _syntax_error(node, "an `if` statement inside a for loop is not supported in proofs", _STATEMENT_HINT)
        return self.generic_visit(node)

    def _obtain_targets(self, st):
        """['x', 'hx'] for `x, hx = obtain(h)`, else None."""
        if not (isinstance(st, ast.Assign) and len(st.targets) == 1 and isinstance(st.targets[0], ast.Tuple)
                and isinstance(st.value, ast.Call) and isinstance(st.value.func, ast.Name) and st.value.func.id == "obtain"
                and "obtain" not in self.shadowed):
            return None
        elts = st.targets[0].elts
        if len(elts) < 2 or not all(isinstance(e, ast.Name) for e in elts):
            raise ProofSyntaxError(f"line {st.lineno}: write `x, hx = obtain(h)` (names for the witnesses, then for the fact)")
        return [e.id for e in elts]

    def transform_block(self, stmts, top=False):
        out = []
        i = 0
        while i < len(stmts):
            st = stmts[i]
            names = self._obtain_targets(st)
            if names is not None:
                # `x, hx = obtain(h)`: the rest of the block is the body of the ∃-elimination
                v = st.value
                if len(v.args) != 1:
                    raise ProofSyntaxError(f"line {st.lineno}: obtain(...) takes one existential fact")
                call = _call("obtain", [_lam(self.visit(v.args[0])), ast.Constant(st.lineno),
                                        ast.List(elts=[ast.Constant(n) for n in names], ctx=ast.Load())])
                target = ast.Tuple(elts=[ast.Name(id=n, ctx=ast.Store()) for n in names], ctx=ast.Store())
                body = self.transform_block(stmts[i + 1:], top=top) or [ast.Pass()]
                out.append(ast.copy_location(ast.With(items=[ast.withitem(context_expr=call, optional_vars=target)], body=body), st))
                break
            if isinstance(st, ast.If):
                rest = stmts[i + 1:]
                then_b = st.body
                else_b = st.orelse if st.orelse else rest
                param = _induction_param(st.test, self.params)
                is_ind = param is not None and (_calls_self(st, self.fname) or (not st.orelse and any(_calls_self(r, self.fname) for r in rest)))
                claim = _final_claim(else_b)
                if is_ind:
                    if claim is None:
                        raise ProofSyntaxError(f"line {st.lineno}: the inductive branch must end with an assert (or return) stating the theorem")
                    out.append(self.statement_call(claim, st))
                    def items(which, _p=param, _l=st.lineno):
                        return [ast.withitem(context_expr=_call("induction", [ast.Constant(_p), ast.Constant(which), ast.Constant(_l)]))]
                    w_then, w_else = 0, 1
                else:
                    test = self.visit(_clone(st.test))
                    def items(which, _t=test, _l=st.lineno):
                        return [ast.withitem(context_expr=_call("case", [_lam(_clone(_t)), ast.Constant(which), ast.Constant(_l)]))]
                    w_then, w_else = True, False
                    locals_ = self.shadowed - set(self.params)
                    last = not st.orelse or i == len(stmts) - 1      # only a final if/else states the theorem
                    if top and last and claim is not None and not ({n.id for n in ast.walk(claim) if isinstance(n, ast.Name)} & locals_):
                        out.append(self.statement_call(claim, st))
                out.append(ast.copy_location(ast.With(items=items(w_then), body=self.transform_block(then_b) or [ast.Pass()]), st))
                out.append(ast.copy_location(ast.With(items=items(w_else), body=self.transform_block(else_b) or [ast.Pass()]), st))
                if not st.orelse:
                    break          # the rest of the block became the else branch
                i += 1
                continue
            new = self.visit(st)
            if new is None:
                pass
            elif isinstance(new, list):
                out.extend(new)
            else:
                out.append(new)
            i += 1
        return out


def _contains_if(node) -> bool:
    todo = list(node.body) + list(getattr(node, "orelse", []))
    while todo:
        st = todo.pop()
        if isinstance(st, ast.If):
            return True
        if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        for field in ("body", "orelse", "finalbody"):
            todo.extend(x for x in getattr(st, field, []) if isinstance(x, ast.stmt))
    return False


def _check_function(fdef):
    """Reject function shapes whose body would never run as a proof."""
    if isinstance(fdef, ast.AsyncFunctionDef):
        raise _syntax_error(fdef, "an async function cannot be a proof (its body would never run)", "use a plain `def`")
    todo = list(fdef.body)
    while todo:
        n = todo.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            continue
        if isinstance(n, (ast.Yield, ast.YieldFrom, ast.Await)):
            raise _syntax_error(n, "a generator (yield) cannot be a proof: its body would never run",
                                "remove `yield`; a proof states its result with `assert` or `return`")
        todo.extend(ast.iter_child_nodes(n))


def _clone(node):
    return ast.parse(ast.unparse(node), mode="eval").body if not isinstance(node, ast.stmt) else node


def _decreasing_param(fdef, params):
    """For a recursive proof: the single parameter that recursive calls change."""
    positions = set()
    for sub in ast.walk(fdef):
        if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name) and sub.func.id == fdef.name:
            for i, a in enumerate(sub.args):
                if not (isinstance(a, ast.Name) and i < len(params) and a.id == params[i]):
                    positions.add(i)
    if len(positions) != 1:
        raise ProofSyntaxError(f"line {fdef.lineno}: recursive calls must change exactly one parameter (the induction variable)")
    i = positions.pop()
    if i >= len(params):
        raise ProofSyntaxError(f"line {fdef.lineno}: recursive call has too many arguments")
    return params[i]


def _transform_body(fdef, params, shadowed):
    tr = ProofTransformer(fdef.name, params, shadowed)
    recursive = any(_calls_self(st, fdef.name) for st in fdef.body)
    pattern_a = any(isinstance(st, ast.If) and _induction_param(st.test, params) is not None and
                    (_calls_self(st, fdef.name) or any(_calls_self(r, fdef.name) for r in fdef.body[i + 1:]))
                    for i, st in enumerate(fdef.body))
    if recursive and not pattern_a:
        # Strong induction over the whole body: recursive calls need a smaller argument.
        param = _decreasing_param(fdef, params)
        claim = _final_claim(fdef.body)
        if claim is None:
            raise ProofSyntaxError(f"line {fdef.lineno}: a recursive proof must end with an assert (or return) stating the theorem")
        first = fdef.body[0]
        stmt = tr.statement_call(claim, first)
        body = tr.transform_block(fdef.body, top=False) or [ast.Pass()]
        with_ = ast.copy_location(ast.With(items=[ast.withitem(context_expr=_call("strong_induction", [ast.Constant(param), ast.Constant(fdef.lineno)]))],
                                           body=body), first)
        return [stmt, with_]
    return tr.transform_block(fdef.body, top=True) or [ast.Pass()]


def compile_proof(fn):
    """Return (transformed function, parameter names) for `fn`."""
    src_lines, start = inspect.getsourcelines(fn)
    src = textwrap.dedent("".join(src_lines))
    tree = ast.parse(src)
    fdef = next(n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
    ast.increment_lineno(tree, start - 1)
    _check_function(fdef)
    fdef.decorator_list = []
    params = [a.arg for a in fdef.args.args]
    an = _Analyzer(fdef.name)
    an.visit(fdef)
    shadowed = an.assigned | set(params)
    fdef.body = _transform_body(fdef, params, shadowed)
    for a in fdef.args.args:
        a.annotation = None
    fdef.returns = None
    freevars = fn.__code__.co_freevars
    if freevars:
        # Re-create the closure: def __pyra_factory__(<freevars>): <fdef>; return <name>
        factory = ast.FunctionDef(name="__pyra_factory__", args=ast.arguments(posonlyargs=[], args=[ast.arg(arg=v) for v in freevars],
                                  kwonlyargs=[], kw_defaults=[], defaults=[]),
                                  body=[fdef, ast.Return(value=ast.Name(id=fdef.name, ctx=ast.Load()))], decorator_list=[], returns=None)
        ast.copy_location(factory, fdef)
        module = ast.Module(body=[factory], type_ignores=[])
    else:
        module = ast.Module(body=[fdef], type_ignores=[])
    ast.fix_missing_locations(module)
    filename = inspect.getsourcefile(fn) or fn.__code__.co_filename
    code = compile(module, filename, "exec")
    ns = dict(fn.__globals__)
    exec(code, ns)
    if freevars:
        def content(c):
            try:
                return c.cell_contents
            except ValueError:          # e.g. the proof's own (not yet bound) name
                return None
        cells = [content(c) for c in fn.__closure__]
        new_fn = ns["__pyra_factory__"](*cells)
    else:
        new_fn = ns[fdef.name]
    return new_fn, params, filename, ns


def transformed_source(fn) -> str:
    """The rewritten Python that ``@prove`` runs for `fn` (for inspection and tests)."""
    src_lines, start = inspect.getsourcelines(getattr(fn, "__wrapped__", fn))
    tree = ast.parse(textwrap.dedent("".join(src_lines)))
    fdef = next(n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
    fdef.decorator_list = []
    params = [a.arg for a in fdef.args.args]
    an = _Analyzer(fdef.name)
    an.visit(fdef)
    fdef.body = _transform_body(fdef, params, an.assigned | set(params))
    return ast.unparse(ast.fix_missing_locations(tree))


class _RuntimeAPI:
    """The object the rewritten code calls as ``__pyra__``."""

    def __init__(self, session):
        from . import terms
        self.s = session
        self.num = terms.Lit
        self.and_ = terms.and_
        self.or_ = terms.or_
        self.not_ = terms.not_
        self.ite = terms.ite
        self.sum_ = terms.sum_
        self.range_ = terms.range_
        self.min_ = terms.min_
        self.max_ = terms.max_
        self.abs_ = terms.abs_
        self.sum_over = terms.sum_over
        self.prod_over = terms.prod_over
        from . import finset
        self.mem = finset.mem_or_contains
        self.len_ = finset.len_
        self.filter_ = finset.filter_or_builtin
        self.comprehension = finset.comprehension
        self.builtin = finset.builtin
        self.assert_ = session.assert_
        self.conclude = session.conclude
        self.recurse = session.recurse
        self.set_statement = session.set_statement
        self.name = session.name
        self.induction = session.induction
        self.case = session.case
        self.strong_induction = session.strong_induction
        self.assume = session.assume
        self.obtain = session.obtain
        self.unpack = session.unpack
        from .structures import mem as _type_mem

        def mem(x, s):       # finsets / sets of numbers / Python containers: pyra.finset; other types: structures
            if finset.is_finset_like(s) or isinstance(s, (finset.SetTerm, list, tuple, set)):
                return finset.mem_or_contains(x, s)
            return _type_mem(x, s)
        self.mem = mem


_theorem_names = set()


def _theorem_name(fn, name=None):
    base = name or f"Pyra.User.{fn.__module__}.{fn.__qualname__}".replace("<locals>", "local").replace("<", "").replace(">", "")
    base = re.sub(r"[^A-Za-z0-9_.']", "_", base)
    cand, i = base, 1
    k = kernel()
    while cand in _theorem_names or k.has(cand):
        i += 1
        cand = f"{base}_{i}"
    _theorem_names.add(cand)
    return cand


def _annotation_names():
    """Names usable in string annotations without importing them (`h1: "forall(lambda n: ...)"`)."""
    from . import terms
    return {"forall": terms.forall, "exists": terms.exists, "implies": terms.implies, "iff": terms.iff,
            "divides": terms.divides, "Nat": terms.Nat, "Int": terms.Int, "Rat": terms.Rat, "Real": terms.Real,
            "Fun": terms.Fun}


def _closure_vars(f) -> dict:
    """Variables a nested proof function closes over (usable in its string annotations too)."""
    out = {}
    for name, cell in zip(f.__code__.co_freevars, f.__closure__ or ()):
        try:
            out[name] = cell.cell_contents
        except ValueError:
            pass
    return out


def _run(f, kwargs, reuse=None, renames=None):
    new_fn, params, filename, ns = compile_proof(f)
    sig = inspect.signature(f)
    terms, hyp_params, order = [], [], []
    tscope, universes = {**_annotation_names(), **f.__globals__, **_closure_vars(f)}, {}
    for p in params:
        ann = sig.parameters[p].annotation
        if isinstance(ann, str):
            try:
                v = eval(ann, tscope)               # may name earlier parameters: a: "G"
            except Exception:
                v = None
            if isinstance(v, Sort) or callable(getattr(v, "make", None)) or callable(getattr(v, "binders", None)):
                ann = v
            else:
                hyp_params.append(p)            # a hypothesis: the annotation is a proposition
                order.append(("hyp", p, ann))
                continue
        if callable(getattr(ann, "binders", None)):  # a type with structure: {G : Type u} [Group G]
            value, fvars = ann.binders(p, universes)
            terms.append((p, value))
            terms.extend((pb.fvar_name(x), Term(x, "other")) for x in fvars[1:])
            order.append(("var", p, None))
            order.extend(("inst", pb.fvar_name(x), x) for x in fvars[1:])
            hyp_params.append(None)             # binders in signature order
            tscope[p] = value
            continue
        if callable(getattr(ann, "make", None)):    # function types: Fun[Real, Real], ...
            terms.append((p, ann.make(p)))
            tscope[p] = terms[-1][1]
            order.append(("var", p, None))
            continue
        if not isinstance(ann, Sort):
            raise ProofSyntaxError(f"parameter '{p}' of {f.__name__} needs a Pyra type annotation (Nat, Int, Rat, Real, Fun[...]) "
                                   "or a proposition as a string (e.g. h0: \"0 < x\")")
        terms.append((p, Term(pb.mk_fvar(p, ann.handle), ann.key)))
        tscope[p] = terms[-1][1]
        order.append(("var", p, None))
    k = {x: v for x, v in kwargs.items() if x != "name"}
    session = runtime.Session(f.__name__, _theorem_name(f, kwargs.get("name")), filename, terms, **k)
    session.globals = ns
    session.reuse = dict(reuse or {})
    session.renames = list(renames or [])
    api = _RuntimeAPI(session)
    ns["__pyra__"] = api
    token = runtime._current.set(session)
    lines, first = inspect.getsourcelines(f)
    span = (first, first + len(lines) - 1)

    def execute():
        if hyp_params:
            # binders in signature order: hypotheses may mention the parameters before them
            session.binders = []
            scope, values = {**_annotation_names(), **ns, **_closure_vars(f)}, {}
            line = f.__code__.co_firstlineno
            for kind, p, ann in order:
                if kind == "inst":
                    session.binders.append(ann)
                elif kind == "var":
                    t = dict(terms)[p]
                    session.binders.append(t.h)
                    scope[p] = values[p] = t
                else:
                    expr = ast.parse(ann.strip(), mode="eval").body
                    expr = ProofTransformer(f.__name__, params, set()).visit(expr)
                    code = compile(ast.fix_missing_locations(ast.Expression(expr)), filename, "eval")
                    prop = eval(code, scope)
                    t = to_prop(prop, p)
                    values[p] = scope[p] = session.hypothesis(p, t.h, line, f"{p}: {ann}")
            new_fn(*[values[p] for p in params])
        else:
            new_fn(*[t for _, t in terms])

    try:
        try:
            execute()
        except (runtime.ProofError, ProofSyntaxError):
            raise
        except Exception as e:      # no silent fallbacks: report the proof's line and a hint
            raise _located(e, filename, span, f.__name__) from (None if isinstance(e, ElaborationError) else e)
        theorem, statement = session.finish()
    finally:
        runtime._current.reset(token)
    return session, theorem, statement


_ERROR_CLASSES = {}


def _hint_for(e) -> str:
    """A hint for an exception that Python (not Pyra) raised while the proof body ran."""
    msg = str(e)
    if isinstance(e, NameError):
        return (f"`{getattr(e, 'name', None) or 'this name'}` is not defined where the proof runs: import it (e.g. from "
                "pyra.mathlib...), define it before the @prove function, or bind it earlier in the proof")
    if isinstance(e, TypeError) and "unsupported operand" in msg:
        return ("this operator is not translated for Pyra terms; supported: + - * / // % ** and comparisons on "
                "Nat/Int/Rat/Real terms, and / or / not on propositions")
    if isinstance(e, TypeError) and "not callable" in msg:
        return "a Pyra term is not a function; to apply a Lean function use LeanConst(name)(args) or pyra.mathlib imports"
    if isinstance(e, AttributeError):
        return "methods such as n.factorial() map to Lean declarations Nat.factorial, ...; check the name"
    return ("only Python arithmetic and comparisons on Pyra terms, if/else, assert, return, recursive calls and calls of "
            "Pyra / Mathlib functions are elaborated inside @prove")


def _located(e, filename, span, fname):
    """Attach the proof's line (the innermost frame of the user's function) and a hint to `e`."""
    import traceback
    line = None
    for fr, lineno in traceback.walk_tb(e.__traceback__):
        if fr.f_code.co_filename == filename and span[0] <= lineno <= span[1]:
            line = lineno
    if line is None:                                    # e.g. a hypothesis annotation: report the definition
        line = span[0]
    import linecache
    source = linecache.getline(filename, line).strip() if line else ""
    if isinstance(e, ElaborationError):
        return e.located(line, source, fname) if line else e
    msg = str(e)
    if msg.startswith("line ") and ":" in msg:
        msg = msg.split(":", 1)[1].strip()               # the line is reported separately
    base = type(e)
    cls = _ERROR_CLASSES.get(base)
    if cls is None:
        try:
            cls = type("ElaborationError", (ElaborationError, base), {"__module__": "pyra.terms"})
        except TypeError:
            cls = ElaborationError
        _ERROR_CLASSES[base] = cls
    hint = getattr(e, "hint", "") or _hint_for(e)
    err = cls.__new__(cls)
    ElaborationError.__init__(err, f"{fname}: {msg} ({base.__name__})", hint, line, source)
    return err


@dataclasses.dataclass
class HealReport:
    """What happened to each checkpoint when a definition changed (Feature 8)."""
    healed: bool
    steps: list                          # (line, source, status)
    definitions: list

    @property
    def reused(self):
        return [l for l, _, s in self.steps if s == "reused"]

    @property
    def resynthesized(self):
        return [l for l, _, s in self.steps if s == "re-synthesized"]

    @property
    def broken(self):
        return [l for l, _, s in self.steps if s == "broken"]

    def __repr__(self):
        return (f"<HealReport {'healed' if self.healed else 'BROKEN'}: {len(self.reused)} reused, "
                f"{len(self.resynthesized)} re-synthesized, {len(self.broken)} broken>")


class ProvedTheorem:
    """The result of ``@prove``: a kernel-minted theorem plus its line-by-line trust report."""

    def __init__(self, fn, theorem, statement, session):
        self._adopt(fn, theorem, statement, session)
        self.stale = False
        self.last_heal = None
        self.history = []

    def _adopt(self, fn, theorem, statement, session):
        self.__wrapped__ = fn
        self.__name__ = fn.__name__
        self.__doc__ = fn.__doc__
        self.theorem = theorem
        self.statement = statement
        self.steps = session.steps
        self.mode = session.mode
        self.params = [n for n, _ in session.params]
        self._names = dict(session.names)
        self._cache = dict(session.cache)
        self._definitions = list(session.definitions)
        self._def_names = {d: d.lean_name for d in session.definitions}

    def _register(self):
        for d in self._definitions:
            d.dependents.add(self)

    def heal(self) -> HealReport:
        """Re-prove after a definition changed: reuse checkpoints that still check, re-synthesize the rest."""
        renames = [(old, d.lean_name) for d, old in self._def_names.items() if old != d.lean_name]
        try:
            session, theorem, statement = _run(self.__wrapped__, self._kwargs, reuse=self._cache, renames=renames)
        except runtime.ProofError as e:
            steps = [(s.line, s.source, s.healing or "broken") for s in e.steps if s.kind in ("assert", "return", "branch", "ih")]
            self.stale = True
            self.last_heal = HealReport(False, steps, [d.__name__ for d in self._def_names])
            return self.last_heal
        self.history.append(self.theorem)
        steps = [(s.line, s.source, s.healing or "reused") for s in session.steps if s.kind in ("assert", "return", "branch", "ih")]
        self._adopt(self.__wrapped__, theorem, statement, session)
        self._register()
        self.stale = False
        self.last_heal = HealReport(True, steps, [d.__name__ for d in self._definitions])
        return self.last_heal

    @property
    def name(self) -> str:
        return self.theorem.name

    @property
    def text(self) -> str:
        return pretty(self.statement, self._names)

    @property
    def verified(self) -> bool:
        """True when every step is kernel-verified (no oracle axioms)."""
        return self.theorem.verified

    @property
    def badges(self) -> dict:
        return {s.line: s.badge for s in self.steps if s.kind in ("assert", "return", "branch")}

    def graph(self):
        """Interactive proof DAG (Feature 11): steps, the steps they use, Mathlib lemmas and axioms."""
        from .graph import build
        return build(self)

    def _repr_html_(self):
        return self.graph()._repr_html_()

    def report(self, color=False) -> str:
        head = f"theorem {self.name} : {self.text}"
        return head + "\n" + "\n".join(s.format(color) for s in self.steps)

    def __call__(self, *args):
        """Use the theorem as a lemma: instantiate it at `args` (inside a proof it becomes a hypothesis)."""
        from .terms import apply_args
        # arguments are coerced to the binder types: numbers cast, facts passed as proofs, propositions that
        # stand for proofs resolved to the established fact (or proved as a step), applications type-checked
        proof = apply_args(pb.mk_const(self.name), args, what=self.name)
        stmt = elab().infer(proof)
        runtime.use_fact(stmt, proof, self.name)
        return Term(stmt, "prop")

    def __repr__(self):
        trust = "verified" if self.verified else f"{len(self.theorem.oracles)} trusted step(s)"
        return f"<ProvedTheorem {self.name} : {self.text} ({trust})>"


def prove(fn=None, *, mode: str = "strict", solvers=(), hints=(), timeout: float | None = None, name: str | None = None,
          stall_ms: float | None = None, parallel: bool = False, threads: int = 0):
    """Prove the function body.

    ``parallel=True`` collects every proof obligation first and proves them all on a C++ thread pool
    (Feature 9); ``threads`` caps the pool size.

    ``mode``:  ``"strict"`` (kernel only), ``"sketch"`` (Z3/cvc5/SymPy may
    discharge steps, recorded as SMT-Trusted oracles) or ``"draft"`` (unproved
    steps are admitted and reported as Unproved).
    """
    kwargs = dict(mode=mode, solvers=solvers, hints=hints, timeout=timeout, name=name, stall_ms=stall_ms,
                  parallel=parallel, threads=threads)

    def deco(f):
        session, theorem, statement = _run(f, kwargs)
        result = ProvedTheorem(f, theorem, statement, session)
        result._kwargs = kwargs
        functools.update_wrapper(result, f, updated=())
        result._register()
        if runtime.config.verbose:
            print(result.report(session._color()), file=sys.stderr)
        return result

    if fn is not None and callable(fn):
        return deco(fn)
    return deco
