"""Running a ``@prove`` function: proof frames, branches, badges and proof assembly.

The transformed function body runs as ordinary Python (so ``print``, ``pdb``
and IDE breakpoints work) with its parameters bound to symbolic terms.  Each
``assert`` becomes a subgoal discharged by the pyra_elab waterfall, ``if/else``
on ``n == 0`` with a recursive call becomes ``Nat`` induction, and the pieces
are assembled into one proof term that the kernel checks before minting a
:class:`pyra_bind.Theorem`.
"""
from __future__ import annotations

import contextvars
import linecache
import os
import sys
import threading
import time
from dataclasses import dataclass, field

from . import pyra_bind as pb
from . import counterexample as cex
from . import solvers as solvers_mod
from .kernel import elab, kernel
from .terms import Fact, PyraError, Term, pretty, to_term

KERNEL_VERIFIED = "Kernel-Verified"
SMT_TRUSTED = "SMT-Trusted"
UNPROVED = "Unproved"
BADGE_COLOR = {KERNEL_VERIFIED: "green", SMT_TRUSTED: "yellow", UNPROVED: "red"}
_ANSI = {"green": "\033[32m", "yellow": "\033[33m", "red": "\033[31m", "reset": "\033[0m"}
_ICON = {KERNEL_VERIFIED: "✔", SMT_TRUSTED: "◐", UNPROVED: "✘"}
MODES = ("strict", "sketch", "draft")


@dataclass
class Config:
    stall_ms: float = 50.0          # Feature 2: fire the counterexample query after this long
    timeout: float = 10.0           # per step, all stages (a confirmed counterexample stops it at once)
    cex_timeout_ms: int = 3000
    verbose: bool = False
    color: bool | None = None       # None: only on a terminal
    depth: int = 2
    parallel: bool = False          # Feature 9: prove all obligations of a proof in parallel


config = Config()


class ProofError(PyraError):
    """Raised when a ``@prove`` function contains steps that are not accepted in its mode."""

    def __init__(self, message, report=None, steps=None):
        super().__init__(message)
        self.report = report
        self.steps = steps or []


@dataclass
class Step:
    line: int
    source: str
    kind: str                      # assert | return | ih | lemma | branch
    text: str = ""
    badge: str | None = None
    stage: str = ""
    lemmas: list = field(default_factory=list)
    ms: float = 0.0
    counterexample: str = ""
    cex_confirmed: bool = False
    cex_fired_ms: float | None = None   # when the background query fired (ms after the step began)
    stalled: bool = False
    oracle: str = ""
    detail: str = ""
    trace: list = field(default_factory=list)
    thread: int | None = None           # worker thread that proved it (parallel mode)
    healing: str = ""                   # after a definition change: reused | re-synthesized | broken
    proof: int | None = None            # proof term of this step (for proof graphs)
    fvar: int | None = None             # the hypothesis it introduces
    goal: int | None = None             # the proposition this step establishes

    @property
    def color(self) -> str:
        return BADGE_COLOR.get(self.badge, "")

    def format(self, color: bool = False) -> str:
        badge = self.badge or "?"
        tag = f"{badge:<15}"
        if color and self.badge:
            tag = _ANSI[self.color] + tag + _ANSI["reset"]
        info = self.stage
        if self.lemmas:
            info += (": " if info else "") + ", ".join(self.lemmas)
        if self.oracle:
            info += (" " if info else "") + f"[oracle {self.oracle}]"
        line = f"{_ICON.get(self.badge, '?')} line {self.line:>4}  {tag} {self.source or self.text}"
        if info:
            line += f"   ({info}; {self.ms:.0f} ms)"
        if self.counterexample:
            line += f"\n                 {self.counterexample}"
        if self.badge == UNPROVED and self.detail:
            line += f"\n                 {self.detail}"
        return line


@dataclass
class Hyp:
    fvar: int
    prop: int
    name: str
    step: Step | None = None


class Frame:
    def __init__(self, session, parent, kind, subst=(), goal=None, drop=(), locals_=()):
        self.session = session
        self.parent = parent
        self.kind = kind
        self.subst = list(subst)        # [(fvar, term)] applied to everything entering this frame
        self.goal = goal
        self.drop = list(drop)          # hypotheses of ancestors mentioning these are hidden
        self.locals = list(locals_)
        self.hyps: list[Hyp] = []
        self.haves = []                 # (fvar, prop, proof)
        self.closing = None
        self.gen = []                   # hypotheses generalized by an induction on this frame
        self.gen_local = []             # their restatements inside this case
        self.ih = None
        self.sih = None
        self.ind = None
        self.concluded = None           # (prop, fvar) of a `return`

    def chain(self):
        f, out = self, []
        while f is not None:
            out.append(f)
            f = f.parent
        return list(reversed(out))

    def apply(self, h: int) -> int:
        for f in self.chain():
            if f.subst:
                h = pb.replace_fvars(h, [a for a, _ in f.subst], [b for _, b in f.subst])
        return h

    def visible_hyps(self):
        out = []
        chain = self.chain()
        for i, f in enumerate(chain):
            dropped = [d for g in chain[i + 1:] for d in g.drop]
            for h in f.hyps:
                if any(pb.contains_term(h.prop, d) for d in dropped):
                    continue
                out.append(h)
        return out

    def all_locals(self):
        out = []
        for f in self.chain():
            out.extend(f.locals)
        return out

    def add_have(self, prop: int, proof: int, name: str, step: Step | None) -> Hyp:
        fv = pb.mk_fvar(name, prop)
        if step is not None:
            step.fvar = fv
            if step.proof is None:
                step.proof = proof
        self.haves.append((fv, prop, proof))
        h = Hyp(fv, prop, name, step)
        self.hyps.append(h)
        return h

    @property
    def last(self):
        return self.hyps[-1] if self.hyps else None

    def proof(self) -> int:
        if self.closing is None:
            raise PyraError("internal: frame has no closing proof")
        r = self.closing
        for entry in reversed(self.haves):
            if entry[0] == "obtain":
                # `k, hk = h` with h : ∃ x, P x  ->  exists_elim P goal h (fun k hk => r)
                _, k, hk, ex_proof, lam, sort = entry
                if pb.contains_term(self.goal, k):
                    raise PyraError(f"the goal {pretty(self.goal)} mentions the witness {pb.fvar_name(k)} obtained from an "
                                    "existential; a witness cannot escape the proof that unpacks it")
                lemma = {"nat": "Pyra.Cert.exists_elim", "int": "Pyra.Cert.exists_elim_int", "rat": "Pyra.Cert.exists_elim_rat",
                         "real": "Pyra.Cert.exists_elim_real"}[sort]
                r = pb.mk_apps(pb.mk_const(lemma), [lam, self.goal, ex_proof, pb.mk_lam_fvars([k, hk], r)])
                continue
            fv, prop, pf = entry
            r = pb.mk_app(pb.mk_lam_fvars([fv], r), pf)
        return r


_current: contextvars.ContextVar = contextvars.ContextVar("pyra_session", default=None)


def current_session():
    return _current.get()


def use_fact(stmt: int, proof: int, name: str) -> None:
    s = current_session()
    if s is None or threading.current_thread() is not s.thread:
        return
    s.lemma_fact(stmt, proof, name)


def assume(prop, name=None):
    """A hypothesis of the theorem being proved (``h0 = assume(0 < x)``): it becomes a binder of the
    statement, after the parameters.  Inside ``@prove`` the call is rewritten by the AST frontend;
    this function serves direct calls such as ``pyra.assume(...)``."""
    s = current_session()
    if s is None:
        raise PyraError("assume(...) is only meaningful inside a @prove function")
    import sys as _sys
    line = s._user_line() if hasattr(s, "_user_line") else 0
    return s.assume(lambda: prop, line, name)


def obtain(fact):
    """``x, hx = obtain(h)`` destructures ``h : ∃ x, P x`` into a witness ``x`` and ``hx : P x``
    (``x, y, hxy = obtain(h)`` for ``∃ x y, ...``; ``x, hp, hq = obtain(h)`` for ``∃ x, P x ∧ Q x``).
    The rest of the block is proved inside the ∃-elimination, so its conclusion must not mention
    the witness.  Inside ``@prove`` the statement is rewritten by the AST frontend."""
    raise PyraError("obtain(...) is only meaningful inside a @prove function, as `x, hx = obtain(h)`")


class Session:
    """State of one ``@prove`` run."""

    def __init__(self, fn_name, theorem_name, filename, params, mode="strict", solvers=(), hints=(), timeout=None, stall_ms=None,
                 parallel=False, threads=0):
        if mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}")
        self.fn_name = fn_name
        self.theorem_name = theorem_name
        self.filename = filename
        self.params = params                    # [(name, Term)]
        self.mode = mode
        self.solvers = list(solvers)
        self.hints = list(hints)
        self.timeout = timeout or config.timeout
        self.stall_ms = config.stall_ms if stall_ms is None else stall_ms
        self.names = {t.h: n for n, t in params}
        self.root = Frame(self, None, "root", locals_=[t.h for _, t in params])
        self.frame = self.root
        self.steps: list[Step] = []
        self.statement = None
        self.statement_exists = None
        self.branches = {}
        self.counter = 0
        self.oracles = []
        self.thread = threading.current_thread()
        self.token = None
        self.globals = {}
        self.parallel = parallel or config.parallel
        self.definitions = []           # Pyra definitions this proof depends on
        self.cache = {}                 # step key -> closed proof (checkpoints, Feature 8)
        self.reuse = {}                 # checkpoints from a previous run
        self.renames = []               # (old definition constant, new one)
        self._keys = {}
        self.threads = threads
        self.obligations = []
        self.batch_ms = 0.0
        self.binders = [t.h for _, t in params]   # statement binders in order: parameters and hypotheses
        self.assumptions = []                     # hypothesis fvars (in binder order)

    # ------------------------------------------------------------------ helpers
    def fresh(self, base):
        self.counter += 1
        return f"{base}_{self.counter}"

    def source(self, line):
        return linecache.getline(self.filename, line).strip() if self.filename else ""

    def _prop_term(self, value) -> Term:
        from .terms import ElaborationError, TermLike
        if isinstance(value, bool):
            raise ElaborationError(f"this statement evaluated to the Python value {value} before Pyra could see it, so it "
                                   "states nothing about your terms",
                                   hint="the condition was computed by Python (a plain function or Python numbers); "
                                        "write it with Pyra terms (parameters, Lean functions, @pyra.define definitions)")
        t = to_term(value)
        if t.sort != "prop":
            raise ElaborationError(f"expected a proposition, got {t} of sort {t.sort}",
                                   hint="an assert / return / hypothesis needs a proposition such as a comparison "
                                        "(assert n > 0), not a number")
        return t

    # ------------------------------------------------------------------ the proving pipeline
    def _definition_facts(self, goal, hyps):
        """Unfolding equations of Pyra definitions occurring in the goal or hypotheses."""
        from . import definitions as define
        out, seen = [], set()
        for h in [goal] + [x.prop for x in hyps]:
            for d, app in define.definitions_in(h):
                if app in seen:
                    continue
                seen.add(app)
                for stmt, proof in d.equations(app):
                    out.append((proof, stmt, f"def:{d.__name__}"))
                if d not in self.definitions:
                    self.definitions.append(d)
        return out

    def _checkpoint(self, goal, frame, step):
        """Feature 8: reuse this step's proof from before a definition changed, if it still checks."""
        key = self._step_key(step)
        cached = self.reuse.get(key)
        if cached is None:
            return None
        hyps = frame.visible_hyps()
        binders = self._binders(frame, hyps)
        cand = pb.mk_apps(pb.replace_consts(cached, self.renames), binders)
        try:
            k = kernel()
            if k.is_def_eq(k.check(cand), goal):
                return cand
        except Exception:
            pass
        return None

    def _step_key(self, step):
        n = self._keys.get(step.line, 0)
        return (step.line, step.kind, n)

    def _remember(self, goal, frame, step, proof):
        key = self._step_key(step)
        self._keys[step.line] = key[2] + 1
        if step.badge == KERNEL_VERIFIED:
            binders = self._binders(frame, frame.visible_hyps())
            self.cache[key] = pb.mk_lam_fvars(binders, proof)

    def prove(self, goal: int, frame: Frame, step: Step):
        """Discharge `goal`; returns a proof (possibly via an oracle axiom)."""
        step.goal = goal
        if self.reuse:
            cand = self._checkpoint(goal, frame, step)
            if cand is not None:
                step.badge, step.stage, step.healing = KERNEL_VERIFIED, "checkpoint reused", "reused"
                step.text = pretty(goal, self.names)
                self._remember(goal, frame, step, cand)
                return cand
        proof = self._prove(goal, frame, step)
        step.proof = proof
        if self.reuse:
            step.healing = "re-synthesized" if step.badge == KERNEL_VERIFIED else "broken"
        if not self.parallel:
            self._remember(goal, frame, step, proof)
        return proof

    def _prove(self, goal: int, frame: Frame, step: Step):
        if self.parallel:
            return self._defer(goal, frame, step)
        hyps = frame.visible_hyps()
        hyp_tuples = [(h.fvar, h.prop, h.name) for h in hyps] + self._definition_facts(goal, hyps)
        step.text = pretty(goal, self.names)
        variables = [t.h for _, t in self.params] + [l for l in frame.all_locals() if l not in [t.h for _, t in self.params]]
        out = {}
        token = pb.CancelToken()
        t0 = time.perf_counter()

        def pipeline():
            try:
                out["result"] = self._pipeline(goal, frame, hyps, hyp_tuples, step, token)
            except BaseException as e:      # surfaced in the main thread
                out["error"] = e

        worker = threading.Thread(target=pipeline, name="pyra-waterfall", daemon=True)
        worker.start()
        worker.join(self.stall_ms / 1000.0)
        engine = None
        if worker.is_alive():
            # Feature 2: the step stalled -> fire a background counterexample query.
            step.stalled = True
            engine = cex.Engine(goal, [h.prop for h in hyps], variables, config.cex_timeout_ms).start()
            step.cex_fired_ms = (engine.fired_at - t0) * 1000.0
            while worker.is_alive():
                worker.join(0.01)
                if engine.done.is_set() and engine.result and engine.result.found and engine.result.confirmed:
                    # No point proving a false statement: stop the search and move on.
                    token.cancel()
                    worker.join(0.1)
                    if worker.is_alive():
                        out["abandoned"] = True
                    break
        step.ms = (time.perf_counter() - t0) * 1000.0
        if "error" in out and not out.get("abandoned"):
            raise out["error"]
        if out.get("abandoned") or "result" not in out:
            step.detail = "stopped early: a confirmed counterexample refutes this step"
            proof, badge = self._oracle(goal, frame, hyps, "unproved", step), UNPROVED
        else:
            proof, badge = out["result"]
        if badge != KERNEL_VERIFIED:
            if engine is None:
                engine = cex.Engine(goal, [h.prop for h in hyps], variables, config.cex_timeout_ms).start()
                step.cex_fired_ms = (engine.fired_at - t0) * 1000.0
            engine.done.wait(config.cex_timeout_ms / 1000.0 + 2)
        if engine is not None and engine.result is not None and engine.result.found:
            if engine.result.confirmed or badge != KERNEL_VERIFIED:
                step.counterexample = engine.result.message
                step.cex_confirmed = engine.result.confirmed
        if proof is None:
            step.detail = step.detail or "stopped early: a confirmed counterexample refutes this step"
            proof = self._oracle(goal, frame, hyps, "unproved", step)
        step.badge = badge
        return proof

    def _options(self):
        return {"timeout": self.timeout, "depth": config.depth, "hints": list(self.hints)}

    def _pipeline(self, goal, frame, hyps, hyp_tuples, step, token):
        r = elab().prove(goal, hyp_tuples, self._options(), token)
        return self._after(r, goal, frame, hyps, hyp_tuples, step, token)

    def _after(self, r, goal, frame, hyps, hyp_tuples, step, token):
        step.trace = r["trace"]
        if r["proved"]:
            step.stage, step.lemmas = r["stage"], r["lemmas"]
            return r["proof"], KERNEL_VERIFIED
        if token.cancelled:
            return None, UNPROVED
        # Python solvers (Feature 5 / Feature 7), per-proof first, then the global registry.
        if token.cancelled:
            return None, UNPROVED
        specs = [solvers_mod.SolverSpec(f, getattr(f, "__name__", "solver")) for f in self.solvers]
        specs += solvers_mod.registered()
        if specs:
            res = self._run_solvers(specs, goal, frame, hyps, hyp_tuples, step, token)
            if res is not None:
                return res, KERNEL_VERIFIED
        if token.cancelled:
            return None, UNPROVED
        # Gradual rigor (Feature 3).
        if self.mode in ("sketch", "draft"):
            hyp_props = [h.prop for h in hyps]
            if r["smt"] == 1 or cex.smt_valid(goal, hyp_props, 3000, "z3") or cex.smt_valid(goal, hyp_props, 3000, "cvc5"):
                step.stage = "SMT (Z3/cvc5)"
                return self._oracle(goal, frame, hyps, "smt", step), SMT_TRUSTED
            refuted = r["smt"] == -1 and cex.search(goal, hyp_props, [t.h for _, t in self.params] + frame.all_locals(), 2000).confirmed
            if not refuted and solvers_mod.sympy_check(goal):
                step.stage = "SymPy"
                return self._oracle(goal, frame, hyps, "sympy", step), SMT_TRUSTED
        msgs = [step.detail] if step.detail else []
        if self.mode != "draft" and r["smt"] == 1:
            msgs.append("Z3 confirms it, but strict mode needs a kernel proof (use mode='sketch')")
        msgs.append(r["detail"] or "no stage of the waterfall could discharge this step")
        step.detail = "; ".join(msgs)
        return self._oracle(goal, frame, hyps, "unproved", step), UNPROVED

    def _run_solvers(self, specs, goal, frame, hyps, hyp_tuples, step, token):
        el = elab()
        names = dict(self.names)
        g = solvers_mod.Goal(Term(goal, "prop"), [solvers_mod.Hypothesis(h.name, Term(h.prop, "prop"), h.step.line if h.step else None) for h in hyps],
                             {n: t for n, t in self.params}, step.line, self.fn_name, names)
        extra = list(hyp_tuples)
        hints = list(self.hints)
        used = []
        for spec in specs:
            if token.cancelled:
                return None
            try:
                suggestions = solvers_mod.run(spec.fn, g)
            except Exception as e:
                step.detail = f"solver {spec.name} raised {e!r}"
                continue
            hints += [sug.lemma for sug in suggestions if isinstance(sug, solvers_mod.Use)]
            for sug in suggestions:
                if isinstance(sug, solvers_mod.Use):
                    continue
                if isinstance(sug, str):
                    scope = dict(self.globals)
                    scope.update({n: t for n, t in self.params})
                    scope.update({n: Term(h, None) for h, n in self.names.items() if n not in scope})
                    try:
                        sug = eval(sug, scope)
                    except Exception as e:
                        step.detail = f"solver {spec.name}: cannot read {sug!r}: {e}"
                        continue
                try:
                    t = to_term(sug)
                except TypeError:
                    continue
                if t.sort != "prop":
                    continue
                p = frame.apply(t.h)
                r = el.prove(p, extra, {"timeout": self.timeout / 2, "depth": config.depth, "hints": hints}, token)
                if r["proved"]:
                    fv = pb.mk_fvar(f"aux{len(used)}", p)
                    extra.append((fv, p, f"aux{len(used)}"))
                    used.append((fv, r["proof"], spec.name))
            r = el.prove(goal, extra, {"timeout": self.timeout, "depth": config.depth, "hints": hints}, token)
            if r["proved"]:
                proof = r["proof"]
                for fv, pf, _ in reversed(used):
                    proof = pb.mk_app(pb.mk_lam_fvars([fv], proof), pf)
                step.stage = f"python solver {spec.name}"
                step.lemmas = r["lemmas"]
                return proof
        return None

    # ------------------------------------------------------------------ Feature 9: parallel obligations
    def _binders(self, frame, hyps):
        variables = list(dict.fromkeys([t.h for _, t in self.params] + frame.all_locals()))
        return variables + [h.fvar for h in hyps]

    def _defer(self, goal, frame, step):
        """Record an obligation; its proof is a placeholder closed over its context."""
        hyps = frame.visible_hyps()
        binders = self._binders(frame, hyps)
        placeholder = pb.mk_fvar(f"?obligation{len(self.obligations)}", pb.mk_pi_fvars(binders, goal))
        self.obligations.append((placeholder, goal, frame, hyps, binders, step))
        step.text = pretty(goal, self.names)
        return pb.mk_apps(placeholder, binders)

    def _resolve_obligations(self, proof):
        """Prove all recorded obligations on the C++ thread pool and substitute the proofs."""
        if not self.obligations:
            return proof
        jobs = [(goal, [(h.fvar, h.prop, h.name) for h in hyps] + self._definition_facts(goal, hyps))
                for _, goal, _, hyps, _, _ in self.obligations]
        t0 = time.perf_counter()
        results = elab().prove_batch(jobs, self._options(), self.threads)
        self.batch_ms = (time.perf_counter() - t0) * 1000.0
        placeholders, closed = [], []
        for (ph, goal, frame, hyps, binders, step), r in zip(self.obligations, results):
            step.thread, step.ms = r["thread"], r["ms"]
            token = pb.CancelToken()
            pf, badge = self._after(r, goal, frame, hyps, [(h.fvar, h.prop, h.name) for h in hyps], step, token)
            if pf is None:
                pf = self._oracle(goal, frame, hyps, "unproved", step)
            if badge != KERNEL_VERIFIED:
                c = cex.search(goal, [h.prop for h in hyps], [t.h for _, t in self.params] + frame.all_locals(), config.cex_timeout_ms)
                if c.found:
                    step.counterexample, step.cex_confirmed = c.message, c.confirmed
            step.badge = badge
            step.proof = pf
            placeholders.append(ph)
            closed.append(pb.mk_lam_fvars(binders, pf))
        return pb.replace_fvars(proof, placeholders, closed)

    def _oracle(self, goal, frame, hyps, kind, step):
        """Admit `goal` through a named axiom recorded on the theorem (kept honest by the kernel)."""
        variables = list(dict.fromkeys([t.h for _, t in self.params] + frame.all_locals()))
        binders = variables + [h.fvar for h in hyps]
        stmt = pb.mk_pi_fvars(binders, goal)
        name = f"Pyra.Oracle.{self.theorem_name}.L{step.line}_{self.fresh(kind)}"
        lps = pb.level_params(stmt)
        kernel().add_axiom(name, lps, stmt, oracle=kind)
        step.oracle = kind
        self.oracles.append((name, kind, step))
        return pb.mk_apps(pb.mk_const(name, [pb.level_param(l) for l in lps]), binders)

    # ------------------------------------------------------------------ statements of the proof
    def assert_(self, thunk, line):
        step = Step(line, self.source(line), "assert")
        self.steps.append(step)
        t = self._prop_term(thunk())
        goal = self.frame.apply(t.h)
        proof = self.prove(goal, self.frame, step)
        h = self.frame.add_have(goal, proof, f"h{line}", step)
        if config.verbose and not self.parallel:
            print(step.format(self._color()), file=sys.stderr)
        return Fact(goal, h.fvar, f"line {line}")

    def hypothesis(self, name, prop: int, line, source=""):
        """A hypothesis binder of the theorem (`assume(...)` or a parameter annotated with a proposition)."""
        if self.frame is not self.root:
            raise PyraError(f"line {line}: assume(...) is only allowed at the top level of the proof (not inside a branch)")
        fv = pb.mk_fvar(name, prop)
        step = Step(line, source or self.source(line), "assume", badge=KERNEL_VERIFIED, stage="hypothesis")
        step.text = pretty(prop, self.names)
        step.goal, step.fvar, step.proof = prop, fv, fv
        self.steps.append(step)
        self.root.hyps.append(Hyp(fv, prop, name, step))
        self.binders.append(fv)
        self.assumptions.append(fv)
        self.names.setdefault(fv, name)
        return Fact(prop, fv, name)

    def establish(self, prop) -> Fact:
        """A proof of the proposition `prop`: an established fact in scope, else proved now as a step."""
        p = self.frame.apply(to_term(prop).h)
        for h in reversed(self.frame.visible_hyps()):
            if h.prop == p or pb.alpha_eq(h.prop, p):
                return Fact(p, h.fvar, h.name)
        line = self._user_line()
        step = Step(line, self.source(line), "assert")
        self.steps.append(step)
        proof = self.prove(p, self.frame, step)
        step.stage = "argument of a lemma call" + (": " + step.stage if step.stage else "")
        h = self.frame.add_have(p, proof, f"h{line}", step)
        return Fact(p, h.fvar, f"line {line}")

    def assume(self, thunk, line, name=None):
        t = self._prop_term(thunk())
        return self.hypothesis(name or f"h{len(self.assumptions)}", self.frame.apply(t.h), line)

    def conclude(self, thunk, line):
        step = Step(line, self.source(line), "return")
        self.steps.append(step)
        t = self._prop_term(thunk())
        prop = self.frame.apply(t.h)
        if t.witness is not None:
            w = self.frame.apply(t.witness.h)
            lam = pb.args(prop)[1]
            body = pb.beta(pb.mk_app(lam, w))
            pf = self.prove(body, self.frame, step)
            step.text = pretty(prop, self.names)
            sort = t.witness.sort if t.witness.sort != "lit" else "nat"
            if sort == "other":                 # Exists.intro at the witness's type
                T = elab().infer(w)
                lvl = pb.sort_level(elab().whnf(elab().infer(T)))
                proof = pb.mk_apps(pb.mk_const("Exists.intro", [lvl]), [T, lam, w, pf])
            else:
                intro = {"nat": "Pyra.Cert.exists_intro", "int": "Pyra.Cert.exists_intro_int", "rat": "Pyra.Cert.exists_intro_rat",
                         "complex": "Pyra.Cert.exists_intro_complex"}.get(sort, "Pyra.Cert.exists_intro_real")
                proof = pb.mk_apps(pb.mk_const(intro), [lam, w, pf])
        else:
            proof = self.prove(prop, self.frame, step)
        h = self.frame.add_have(prop, proof, f"result{line}", step)
        self.frame.concluded = (prop, h.fvar)
        if config.verbose:
            print(step.format(self._color()), file=sys.stderr)
        return t

    def unpack(self, thunk, names, line):
        """``k, hk = h`` where ``h`` proves ``∃ x, P x``: a fresh witness ``k`` and the fact ``hk : P k``
        (∃-elimination, like Lean's ``obtain ⟨k, hk⟩ := h``).  Anything else is unpacked as in Python."""
        from .terms import ElaborationError, TermLike
        value = thunk()
        if not isinstance(value, TermLike):
            return value                                       # an ordinary Python tuple / iterable
        if value.sort != "prop":
            raise ElaborationError(f"cannot unpack the {value.sort} term `{value}` into {', '.join(names)}",
                                   hint="only an existential fact `exists(x, P(x))` can be unpacked (`k, hk = h`)")
        prop = self.frame.apply(value.h)
        lam = None
        if pb.kind(prop) == "app" and pb.kind(pb.head(prop)) == "const" and pb.const_name(pb.head(prop)) == "Exists":
            a = pb.args(prop)
            if len(a) == 2 and pb.kind(a[1]) == "lam":
                lam = a[1]
        if lam is None:
            raise ElaborationError(f"`{pretty(prop, self.names)}` is not an existential statement, so it has no witness to unpack",
                                   hint="`k, hk = h` needs h : exists(k, P(k)); use `h = ...` to name a fact")
        if len(names) != 2:
            raise ElaborationError(f"an existential unpacks into exactly two names (witness, fact), not {len(names)}",
                                   hint="write `k, hk = h`")
        sort = {"Nat": "nat", "Int": "int", "Rat": "rat", "Real": "real"}.get(
            pb.const_name(pb.binder_type(lam)) if pb.kind(pb.binder_type(lam)) == "const" else "", None)
        if sort is None:
            raise ElaborationError(f"cannot unpack an existential over {pretty(pb.binder_type(lam))}",
                                   hint="witnesses of type Nat, Int, Rat or Real can be unpacked")
        # the proof of the existential: a Fact carries it; otherwise it must be an established fact
        ex_proof = value.proof if isinstance(value, Fact) else None
        if ex_proof is None:
            for h in reversed(self.frame.visible_hyps()):
                if h.prop == prop or pb.alpha_eq(h.prop, prop):
                    ex_proof = h.fvar
                    break
        if ex_proof is None:
            raise ElaborationError(f"`{pretty(prop, self.names)}` has not been established, so its witness cannot be unpacked",
                                   hint="assert it first (`h = ...` / `assert ...`), or unpack a hypothesis, an induction "
                                        "hypothesis or a lemma instance")
        from .terms import SORTS
        wname, hname = names
        k = pb.mk_fvar(wname, SORTS[sort].handle)
        pk = pb.beta(pb.mk_app(lam, k))
        hk = pb.mk_fvar(hname, pk)
        step = Step(line, self.source(line), "obtain", badge=KERNEL_VERIFIED, stage="∃-elimination (witness obtained)")
        step.text = pretty(pk, self.names | {k: wname})
        step.goal, step.fvar, step.proof = pk, hk, hk
        self.steps.append(step)
        self.names[k] = wname
        self.names.setdefault(hk, hname)
        self.frame.locals.append(k)
        self.frame.haves.append(("obtain", k, hk, ex_proof, lam, sort))
        self.frame.hyps.append(Hyp(hk, pk, hname, step))
        return Term(k, sort), Fact(pk, hk, hname)

    def set_statement(self, thunk, line, alt=None):
        try:
            t = self._prop_term(thunk())
        except NameError as e:
            if alt is None:
                from .terms import ElaborationError
                raise ElaborationError(f"the statement of this proof uses a name defined only inside it ({e})",
                                       hint="the final assert/return of an inductive proof must state the theorem in "
                                            "terms of its parameters; an existential witness may be a local "
                                            "(`return exists(k, P(k))`)", line=line, source=self.source(line)) from None
            t = self._prop_term(alt())
        self.statement = t.h
        self.statement_exists = t.witness

    def name(self, n, value):
        if isinstance(value, Term) and value.sort != "lit":
            self.names.setdefault(value.h, n)
        return value

    def certified_fact(self, cert):
        """A SymPy result with its kernel certificate (Feature 4) becomes a hypothesis."""
        step = Step(self._user_line(), "", "lemma", badge=KERNEL_VERIFIED, stage=f"SymPy {cert.op} certificate",
                    lemmas=[r for _, r in cert.steps if _ == "rule"])
        step.source = self.source(step.line)
        step.text = pretty(cert.statement, self.names)
        step.goal = cert.statement
        self.steps.append(step)
        self.frame.add_have(self.frame.apply(cert.statement), self.frame.apply(cert.proof), self.fresh("sympy"), step)

    def lemma_fact(self, stmt, proof, lemma):
        step = Step(self._user_line(), "", "lemma", badge=KERNEL_VERIFIED, stage="library lemma", lemmas=[lemma])
        step.source = self.source(step.line)
        step.text = pretty(stmt, self.names)
        step.source = step.source or f"{lemma}(...)"
        self.steps.append(step)
        self.frame.add_have(self.frame.apply(stmt), self.frame.apply(proof), self.fresh("lemma"), step)

    def _user_line(self):
        f = sys._getframe(1)
        while f is not None:
            if f.f_code.co_filename == self.filename:
                return f.f_lineno
            f = f.f_back
        return 0

    def recurse(self, args_thunk, line):
        f = self.frame
        while f is not None and f.kind not in ("succ", "strong", "zero"):
            f = f.parent
        if f is None or f.kind == "zero":
            from .terms import ElaborationError
            raise ElaborationError("a recursive call is only allowed in the inductive (else) branch of `if n == 0`"
                                   " or inside a strongly inductive proof",
                                   hint="the base case cannot use the induction hypothesis; prove it directly", line=line,
                                   source=self.source(line))
        n_term, m, stmt = f.ind
        args = args_thunk()
        if not isinstance(args, tuple):
            args = (args,)
        args = tuple(a for a in args if not isinstance(a, Fact))       # hypothesis arguments are re-proved
        if len(args) != len(self.params):
            from .terms import ElaborationError
            raise ElaborationError(f"the recursive call needs {len(self.params)} argument(s), got {len(args)}",
                                   hint="pass every parameter (the induction variable changed, the others unchanged)",
                                   line=line, source=self.source(line))
        idx = [t.h for _, t in self.params].index(n_term.h)
        arg = None
        for j, (pname, pterm) in enumerate(self.params):
            a = to_term(args[j])
            from .terms import coerce
            if j == idx:
                arg = self.frame.apply(coerce(a, "nat").h)
            elif a.h != pterm.h:
                from .terms import ElaborationError
                raise ElaborationError(f"parameter {pname} must be passed through unchanged in the recursive call",
                                       hint="induction changes exactly one parameter; generalize the statement or "
                                            "prove a helper theorem for the varying parameter", line=line,
                                       source=self.source(line))
        bound = m if f.kind == "strong" else elab().tpl("nat_add", [m, elab().tpl("nat_num", [pb.mk_nat(1)])])
        gen = f.gen
        if f.kind == "succ" and elab().def_eq(arg, m):
            # structural induction: the hypothesis is P(m)
            ih_full = pb.replace_fvars(pb.mk_pi_fvars(gen, stmt), [n_term.h], [m])
            ih_prop = pb.replace_fvars(stmt, [n_term.h], [m])
            if f.ih is None:
                f.ih = pb.mk_fvar("ih", ih_full)
            if not gen:
                step = Step(line, self.source(line), "ih", badge=KERNEL_VERIFIED, stage="induction hypothesis")
                step.text = pretty(ih_prop, self.names)
                step.goal = ih_prop
                self.steps.append(step)
                if not any(h.fvar == f.ih for h in f.hyps):
                    f.hyps.append(Hyp(f.ih, ih_prop, "ih", step))
                step.fvar = f.ih
                return Fact(ih_prop, f.ih, "ih")
            return self._instantiate_ih(f.ih, gen, n_term, m, stmt, line, "induction hypothesis")
        # strong induction: prove the argument is smaller, then instantiate ∀ k < bound, P k
        if f.sih is None:
            k = pb.mk_fvar("k", pb.mk_const("Nat"))
            hk = pb.mk_fvar("hk", elab().tpl("nat_lt", [k, bound]))
            f.sih = pb.mk_fvar("ih", pb.mk_pi_fvars([k, hk], pb.replace_fvars(pb.mk_pi_fvars(gen, stmt), [n_term.h], [k])))
        dec = Step(line, self.source(line), "ih")
        self.steps.append(dec)
        lt = elab().tpl("nat_lt", [arg, bound])
        lt_pf = self.prove(lt, self.frame, dec)
        dec.stage = "induction hypothesis (strong; decreasing argument" + (": " + dec.stage if dec.stage else "") + ")"
        if gen:
            dec.goal = pb.replace_fvars(pb.mk_pi_fvars(gen, stmt), [n_term.h], [arg])
            dec.text = pretty(dec.goal, self.names)
            hfull = self.frame.add_have(dec.goal, pb.mk_apps(f.sih, [arg, lt_pf]), self.fresh("ih"), dec)
            return self._instantiate_ih(hfull.fvar, gen, n_term, arg, stmt, line, "induction hypothesis (strong)")
        ih_prop = pb.replace_fvars(stmt, [n_term.h], [arg])
        dec.text = pretty(ih_prop, self.names)
        dec.goal = ih_prop
        h = self.frame.add_have(ih_prop, pb.mk_apps(f.sih, [arg, lt_pf]), self.fresh("ih"), dec)
        return Fact(ih_prop, h.fvar, "ih")

    def _instantiate_ih(self, ih, gen, n_term, arg, stmt, line, stage):
        """The induction hypothesis is `∀ (hyps about n), P n` at `arg`: prove the hypotheses, then use it."""
        proof = ih
        subst_from, subst_to = [n_term.h], [arg]
        for g in gen:
            need = pb.replace_fvars(elab().infer(g), subst_from, subst_to)
            st = Step(line, self.source(line), "ih")
            self.steps.append(st)
            pf = self.prove(need, self.frame, st)
            st.stage = "hypothesis of the induction hypothesis" + (": " + st.stage if st.stage else "")
            proof = pb.mk_app(proof, pf)
            subst_from.append(g)
            subst_to.append(pf)
        ih_prop = pb.replace_fvars(stmt, subst_from, subst_to)
        step = Step(line, self.source(line), "ih", badge=KERNEL_VERIFIED, stage=stage)
        step.text = pretty(ih_prop, self.names)
        self.steps.append(step)
        h = self.frame.add_have(ih_prop, proof, self.fresh("ih"), step)
        return Fact(ih_prop, h.fvar, "ih")

    # ------------------------------------------------------------------ branches
    def _close(self, frame: Frame, line: int):
        if frame.goal is None:
            if frame.last is None:
                raise PyraError(f"line {line}: this branch proves nothing")
            frame.goal = frame.last.prop
            frame.closing = frame.last.fvar
            return
        for h in reversed(frame.visible_hyps()):
            if h.prop == frame.goal or pb.alpha_eq(h.prop, frame.goal):
                frame.closing = h.fvar
                return
        step = Step(line, f"(goal of the {'base case' if frame.kind == 'zero' else 'inductive step' if frame.kind == 'succ' else 'branch'})", "branch")
        self.steps.append(step)
        frame.closing = self.prove(frame.goal, frame, step)

    def induction(self, param, which, line):
        return _Branch(self, ("ind", param, which, line))

    def strong_induction(self, param, line):
        return _Branch(self, ("strong", param, 0, line))

    def case(self, cond_thunk, which, line):
        return _Branch(self, ("case", cond_thunk, which, line))

    def obtain(self, thunk, line, names):
        """``x, hx = obtain(h)`` for ``h : ∃ x, P x``: the rest of the block runs with a fresh witness
        ``x`` and the fact ``hx : P x``; its conclusion is closed by ``Exists.elim``."""
        return _Obtain(self, ("obtain", thunk, list(names), line))

    def _enter_obtain(self, spec):
        _, thunk, names, line = spec
        parent = self.frame
        v = thunk()
        if isinstance(v, Fact):
            prop, proof = parent.apply(v.h), parent.apply(v.proof)
        else:
            t = self._prop_term(v)
            step = Step(line, self.source(line), "assert")
            self.steps.append(step)
            prop = parent.apply(t.h)
            proof = self.prove(prop, parent, step)
            proof = parent.add_have(prop, proof, f"h{line}", step).fvar
        fr = Frame(self, parent, "obtain")
        fr.elims = []                      # (α, p, proof of ∃ x, p x, x, hx), outermost first
        fr.spec = spec
        out = []
        cur, cur_pf = prop, proof
        k = 0
        while k < len(names) - 1:
            ex = cur
            if not (pb.kind(ex) == "app" and pb.kind(pb.head(ex)) == "const" and pb.const_name(pb.head(ex)) == "Exists"):
                ex = elab().whnf(cur)
            if pb.kind(ex) == "app" and pb.kind(pb.head(ex)) == "const" and pb.const_name(pb.head(ex)) == "Exists" and len(pb.args(ex)) == 2:
                alpha, p = pb.args(ex)
                x = pb.mk_fvar(names[k], alpha)
                body = pb.beta(pb.mk_app(p, x))
                hx = pb.mk_fvar(f"{names[-1]}_{k}" if k < len(names) - 2 else names[-1], body)
                fr.elims.append((alpha, p, cur_pf, x, hx))
                fr.locals.append(x)
                self.names[x] = names[k]
                out.append(Term(x))
                cur, cur_pf = body, hx
                k += 1
                continue
            break
        if not fr.elims:
            raise PyraError(f"line {line}: obtain(...) needs an existential statement (∃ x, P x), got {pretty(prop, self.names)}")
        # the remaining names split a conjunction P ∧ Q ∧ ...
        facts = []
        rest = len(names) - len(out)
        for i in range(rest):
            if i < rest - 1:
                a = cur
                if not (pb.kind(a) == "app" and pb.kind(pb.head(a)) == "const" and pb.const_name(pb.head(a)) == "And"):
                    raise PyraError(f"line {line}: obtain(...): {pretty(cur, self.names)} has no further ∃ or ∧ to split for '{names[len(out) + i]}'")
                p, q = pb.args(a)
                facts.append((p, pb.mk_apps(pb.mk_const("And.left"), [p, q, cur_pf]), names[len(out) + i]))
                cur, cur_pf = q, pb.mk_apps(pb.mk_const("And.right"), [p, q, cur_pf])
            else:
                facts.append((cur, cur_pf, names[-1]))
        _, _, _, x_last, hx_last = fr.elims[-1]
        st = Step(line, self.source(line), "branch", badge=KERNEL_VERIFIED, stage="∃-elimination (witness)")
        st.text = pretty(pb.fvar_type(hx_last), self.names)
        st.goal, st.fvar, st.proof = pb.fvar_type(hx_last), hx_last, hx_last
        self.steps.append(st)
        fr.hyps.append(Hyp(hx_last, pb.fvar_type(hx_last), names[-1], st))
        self.names.setdefault(hx_last, names[-1])
        for prop_i, pf_i, nm in facts:
            out.append(Fact(prop_i, pf_i, nm))
        self.frame = fr
        return fr, tuple(out)

    def _exit_obtain(self, fr):
        line = fr.spec[3]
        if fr.concluded is not None:
            fr.goal = fr.concluded[0]
        self._close(fr, line)
        self.frame = fr.parent
        goal = fr.goal
        for _, _, _, x, hx in fr.elims:
            if pb.contains_term(goal, x):
                raise PyraError(f"line {line}: the conclusion reached after obtain(...) mentions the witness "
                                f"'{pb.fvar_name(x)}': {pretty(goal, self.names)}")
        proof = fr.proof()
        for alpha, p, h, x, hx in reversed(fr.elims):
            lvl = pb.sort_level(elab().whnf(elab().infer(alpha)))
            proof = pb.mk_apps(pb.mk_const("Exists.elim", [lvl]), [alpha, p, goal, h, pb.mk_lam_fvars([x, hx], proof)])
        st = Step(line, self.source(line), "branch", badge=KERNEL_VERIFIED, stage="∃-elimination")
        st.text = pretty(goal, self.names)
        st.goal = goal
        self.steps.append(st)
        h = fr.parent.add_have(goal, proof, f"obtain{line}", st)
        if fr.concluded is not None:
            fr.parent.concluded = (goal, h.fvar)

    def _enter(self, spec):
        kind = spec[0]
        parent = self.frame
        line = spec[3]
        if kind == "strong":
            _, param, _, _ = spec
            if self.statement is None:
                raise PyraError(f"line {line}: a recursive proof needs its statement (its final assert)")
            n_term = dict(self.params)[param]
            stmt = parent.apply(self.statement)
            fr = Frame(self, parent, "strong", goal=stmt)
            fr.ind = (n_term, n_term.h, stmt)
            fr.gen = self._generalized(n_term.h)
            fr.spec = spec
            self.frame = fr
            return fr
        if kind == "ind":
            _, param, which, _ = spec
            if self.statement is None:
                raise PyraError(f"line {line}: an inductive proof needs its statement (the final assert of the else branch)")
            n_term = dict(self.params)[param]
            stmt = parent.apply(self.statement)
            gen = self._generalized(n_term.h)
            if which == 0:
                zero = elab().tpl("nat_num", [pb.mk_nat(0)])
                fr = Frame(self, parent, "zero", subst=[(n_term.h, zero)], goal=pb.replace_fvars(stmt, [n_term.h], [zero]), drop=[n_term.h])
            else:
                used = {n for n, _ in self.params} | set(self.names.values())
                mname = next(c for c in ("m", "k", "j", "m1", "m2", "m3") if c not in used)
                m = pb.mk_fvar(mname, pb.mk_const("Nat"))
                self.names[m] = mname
                succ = elab().tpl("nat_add", [m, elab().tpl("nat_num", [pb.mk_nat(1)])])
                fr = Frame(self, parent, "succ", subst=[(n_term.h, succ)], goal=pb.replace_fvars(stmt, [n_term.h], [succ]),
                           drop=[n_term.h], locals_=[m])
                fr.ind = (n_term, m, stmt)
            fr.gen = gen
            fr.gen_local = []
            if gen:
                # the hypotheses about n, restated for this case (they are binders of the motive)
                val = fr.subst[0][1]
                for g in gen:
                    ty = pb.replace_fvars(elab().infer(g), [n_term.h] + [a for a, _ in fr.subst[1:]], [val] + [b for _, b in fr.subst[1:]])
                    nm = self.names.get(g, pb.fvar_name(g))
                    g2 = pb.mk_fvar(nm, ty)
                    st = Step(line, self.source(line), "branch", badge=KERNEL_VERIFIED, stage="hypothesis (case of the induction)")
                    st.text = pretty(ty, self.names)
                    fr.hyps.append(Hyp(g2, ty, nm, st))
                    fr.subst.append((g, g2))
                    fr.gen_local.append(g2)
                    self.names.setdefault(g2, nm)
            fr.spec = spec
        else:
            _, thunk, which, _ = spec
            c = parent.apply(self._prop_term(thunk()).h)
            hyp = c if which else pb.mk_app(pb.mk_const("Not"), c)
            goal = parent.apply(self.statement) if self.statement is not None else None
            fr = Frame(self, parent, "case", goal=goal)
            fv = pb.mk_fvar(f"hc{line}", hyp)
            st = Step(line, self.source(line), "branch", badge=KERNEL_VERIFIED, stage="case assumption")
            st.text = pretty(hyp, self.names)
            fr.hyps.append(Hyp(fv, hyp, f"hc{line}", st))
            fr.case = (c, fv, which)
            fr.spec = spec
        self.frame = fr
        return fr

    def _generalized(self, n):
        """Hypotheses (theorem binders) that mention the induction variable `n`: they become part of the motive."""
        return [a for a in self.assumptions if pb.contains_term(elab().infer(a), n)]

    def _exit(self, fr: Frame):
        spec = fr.spec
        line = spec[3]
        self._close(fr, line)
        self.frame = fr.parent
        if spec[0] == "strong":
            n_term, _, stmt = fr.ind
            gen = fr.gen
            P = pb.mk_lam_fvars([n_term.h], pb.mk_pi_fvars(gen, stmt))
            sih = fr.sih if fr.sih is not None else pb.mk_fvar("ih", pb.mk_const("True"))
            body = pb.mk_lam_fvars([n_term.h, sih] + gen, fr.proof())
            proof = pb.mk_apps(pb.mk_const("Pyra.Cert.nat_strong_induction"), [P, body, n_term.h] + gen)
            st = Step(line, f"(strong induction on {n_term})", "branch", badge=KERNEL_VERIFIED, stage="strong induction")
            st.text = pretty(stmt, self.names)
            self.steps.append(st)
            fr.parent.add_have(stmt, proof, f"ind{line}", st)
            return
        key = (spec[0], line)
        pair = self.branches.setdefault(key, {})
        pair[spec[2]] = fr
        if len(pair) < 2:
            return
        parent = fr.parent
        if spec[0] == "ind":
            z, s = pair[0], pair[1]
            n_term, m, stmt = s.ind
            gen = s.gen
            P = pb.mk_lam_fvars([n_term.h], pb.mk_pi_fvars(gen, stmt))
            zp = pb.mk_lam_fvars(z.gen_local, z.proof())
            sp = pb.mk_lam_fvars(s.gen_local, s.proof())
            if s.sih is None:
                ih = s.ih if s.ih is not None else pb.mk_fvar("ih", pb.replace_fvars(pb.mk_pi_fvars(gen, stmt), [n_term.h], [m]))
                h1 = pb.mk_lam_fvars([m, ih], sp)
                proof = pb.mk_apps(pb.mk_const("Pyra.Cert.nat_induction"), [P, zp, h1, n_term.h] + gen)
                how = "induction (Nat.rec)"
            else:
                body = sp
                if s.ih is not None:      # P(m) is the instance k := m of the strong hypothesis
                    body = pb.mk_app(pb.mk_lam_fvars([s.ih], body), pb.mk_apps(s.sih, [m, pb.mk_app(pb.mk_const("Nat.lt_succ_self"), m)]))
                h1 = pb.mk_lam_fvars([m, s.sih], body)
                proof = pb.mk_apps(pb.mk_const("Pyra.Cert.strong_rec"), [P, zp, h1, n_term.h] + gen)
                how = "strong induction"
            st = Step(line, self.source(line), "branch", badge=KERNEL_VERIFIED, stage=how)
            st.text = pretty(stmt, self.names)
            st.goal = stmt
            self.steps.append(st)
            parent.add_have(stmt, proof, f"ind{line}", st)
        else:
            a, b = pair[True], pair[False]
            c, fva, _ = a.case
            _, fvb, _ = b.case
            if a.goal == b.goal or pb.alpha_eq(a.goal, b.goal):
                goal, pa, pb_ = a.goal, a.proof(), b.proof()
            else:
                # a case split in the middle of a proof establishes the disjunction of what its branches show
                goal = elab().tpl("or_", [a.goal, b.goal])
                pa = pb.mk_apps(pb.mk_const("Pyra.Cert.or_inl"), [a.goal, b.goal, a.proof()])
                pb_ = pb.mk_apps(pb.mk_const("Pyra.Cert.or_inr"), [a.goal, b.goal, b.proof()])
            proof = pb.mk_apps(pb.mk_const("Pyra.Cert.em_cases"), [c, goal, pb.mk_lam_fvars([fva], pa), pb.mk_lam_fvars([fvb], pb_)])
            st = Step(line, self.source(line), "branch", badge=KERNEL_VERIFIED, stage="case split")
            st.text = pretty(goal, self.names)
            st.goal = goal
            self.steps.append(st)
            parent.add_have(goal, proof, f"cases{line}", st)

    # ------------------------------------------------------------------ finishing
    def _color(self):
        if config.color is not None:
            return config.color
        return sys.stderr.isatty() and not os.environ.get("NO_COLOR")

    def finish(self):
        root = self.root
        if self.statement is not None and root.concluded is None:
            root.goal = root.apply(self.statement)
        elif root.concluded is not None:
            root.goal = root.concluded[0]
        self._close(root, self.steps[-1].line if self.steps else 0)
        params = list(self.binders)
        stmt = pb.mk_pi_fvars(params, root.goal)
        proof = pb.mk_lam_fvars(params, self._resolve_obligations(root.proof()))
        bad = [s for s in self.steps if s.badge == UNPROVED or (s.badge == SMT_TRUSTED and self.mode == "strict")]
        report = self.report_text(color=False)
        if bad and self.mode != "draft":
            lines = "\n".join(s.format(False) for s in bad)
            raise ProofError(f"{self.fn_name}: {len(bad)} step(s) not accepted in {self.mode} mode:\n{lines}", report, self.steps)
        thm = kernel().add_theorem(self.theorem_name, pb.level_params(stmt), stmt, proof)
        return thm, stmt

    def report_text(self, color=False):
        return "\n".join(s.format(color) for s in self.steps)


class _Branch:
    def __init__(self, session, spec):
        self.session, self.spec = session, spec

    def __enter__(self):
        self.frame = self.session._enter(self.spec)
        return self.frame

    def __exit__(self, et, ev, tb):
        if et is None:
            self.session._exit(self.frame)
        else:
            self.session.frame = self.frame.parent
        return False


class _Obtain(_Branch):
    def __enter__(self):
        self.frame, values = self.session._enter_obtain(self.spec)
        return values

    def __exit__(self, et, ev, tb):
        if et is None:
            self.session._exit_obtain(self.frame)
        else:
            self.session.frame = self.frame.parent
        return False
