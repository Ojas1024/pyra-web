"""Pyra definitions (``@pyra.define``) and Feature 8: self-healing proofs.

A definition is a Python function elaborated into a kernel definition::

    @define
    def tri(n: Nat) -> Nat:
        if n == 0:
            return 0
        else:
            return tri(n - 1) + n          # structural recursion -> Nat.rec

Re-defining a name creates a new version (`Pyra.Def.tri.v2`).  Theorems that
used the old version are re-proved automatically: each `assert` checkpoint
first tries its cached proof against the new definition and, where that no
longer type-checks, the C++ Auto-Bridge (the waterfall) re-synthesises the glue.
"""
from __future__ import annotations

import ast as pyast
import inspect
import textwrap
import weakref

from . import pyra_bind as pb
from .kernel import elab, kernel
from .terms import SORTS, PyraError, Sort, Term, coerce, pretty, to_term

_REGISTRY = {}          # (module, qualname) -> Definition


class DefinitionError(PyraError):
    pass


class Definition:
    """A versioned kernel definition usable inside proofs as an ordinary function."""

    def __init__(self, key, fn, params, result):
        self.key = key
        self.fn = fn
        self.__name__ = fn.__name__
        self.__doc__ = fn.__doc__
        self.params = params            # [(name, Sort)]
        self.result = result            # Sort
        self.version = 0
        self.lean_name = None
        self.history = []               # lean names of previous versions
        self.zero = None                # recursive definitions: value at 0 ...
        self.succ = None                # ... and λ m ih. value at m + 1
        self.rec_param = None
        self.dependents = weakref.WeakSet()
        self.source = ""

    # -- use in terms ---------------------------------------------------------
    def __call__(self, *args):
        if len(args) != len(self.params):
            raise DefinitionError(f"{self.__name__} expects {len(self.params)} arguments")
        hs = [coerce(to_term(a), s.key).h for a, (_, s) in zip(args, self.params)]
        return Term(pb.mk_apps(pb.mk_const(self.lean_name), hs), self.result.key)

    def __repr__(self):
        return f"<definition {self.__name__} v{self.version} = {self.lean_name}>"

    # -- equations used by the waterfall ---------------------------------------
    def equations(self, h: int):
        """Unfolding facts for an application `h` of this definition: [(statement, proof)]."""
        args = pb.args(h)
        info = kernel().find(self.lean_name)
        out = []
        if self.rec_param is None:
            rhs = pb.beta(pb.mk_apps(info["value"], args))
            out.append(rhs)
        else:
            i = [n for n, _ in self.params].index(self.rec_param)
            a = args[i]
            pred = _predecessor(a)
            if pred is not None or _is_zero(a):
                others = [x for j, x in enumerate(args) if j != i]
                if pred is None:
                    rhs = pb.beta(pb.mk_apps(self.zero, others))
                else:
                    call = pb.mk_apps(pb.mk_const(self.lean_name), [pred if j == i else x for j, x in enumerate(args)])
                    rhs = pb.beta(pb.mk_apps(self.succ, others + [pred, call]))
                out.append(rhs)
        eq = elab().tpl(f"{self.result.key}_eq", [h, out[0]]) if out else None
        if eq is None:
            return []
        level = pb.level_nat(1)
        proof = pb.mk_apps(pb.mk_const("Eq.refl", [level]), [self.result.handle, h])
        return [(eq, proof)]


def _is_zero(h):
    from .terms import _lit_of
    return _lit_of(h) == 0


def _predecessor(h):
    """`x + 1` -> x, literal k > 0 -> k - 1."""
    from .terms import _lit_of, numeral
    v = _lit_of(h)
    if v is not None:
        return numeral(v - 1, "nat") if v > 0 else None
    if pb.kind(h) == "app" and pb.kind(pb.head(h)) == "const" and pb.const_name(pb.head(h)) == "HAdd.hAdd":
        a = pb.args(h)
        if len(a) == 6 and _lit_of(a[5]) == 1:
            return a[4]
    return None


def lookup(lean_const: str):
    for d in _REGISTRY.values():
        if d.lean_name == lean_const:
            return d
    return None


def definitions_in(h: int):
    """Definition applications occurring in `h`: [(Definition, application handle)]."""
    out, seen = [], set()

    def walk(x):
        if x in seen:
            return
        seen.add(x)
        k = pb.kind(x)
        if k == "app":
            hd = pb.head(x)
            if pb.kind(hd) == "const":
                d = lookup(pb.const_name(hd))
                if d is not None and len(pb.args(x)) == len(d.params) and pb.loose_bvar_range(x) == 0:
                    out.append((d, x))
            walk(pb.app_fn(x)); walk(pb.app_arg(x))
        elif k in ("lam", "pi"):
            walk(pb.binder_type(x)); walk(pb.binder_body(x))
    walk(h)
    return out


# ------------------------------------------------------------------ elaborating a definition body
class _DefTransformer(pyast.NodeTransformer):
    def __init__(self, fname, params):
        self.fname, self.params = fname, params

    def visit_Constant(self, node):
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            return pyast.copy_location(_c("num", [node]), node)
        return node

    def visit_BoolOp(self, node):
        return pyast.copy_location(_c("and_" if isinstance(node.op, pyast.And) else "or_", [self.visit(v) for v in node.values]), node)

    def visit_UnaryOp(self, node):
        if isinstance(node.op, pyast.Not):
            return pyast.copy_location(_c("not_", [self.visit(node.operand)]), node)
        return self.generic_visit(node)

    def visit_IfExp(self, node):
        return pyast.copy_location(_c("ite", [self.visit(node.test), self.visit(node.body), self.visit(node.orelse)]), node)

    def visit_Call(self, node):
        if isinstance(node.func, pyast.Name) and node.func.id == self.fname:
            args = [self.visit(a) for a in node.args]
            return pyast.copy_location(_c("rec", [pyast.Lambda(args=_noargs(), body=pyast.Tuple(elts=args, ctx=pyast.Load()))]), node)
        if isinstance(node.func, pyast.Name) and node.func.id in ("sum", "range", "min", "max"):
            node.func = pyast.Attribute(value=pyast.Name(id="__pyra__", ctx=pyast.Load()), attr={"sum": "sum_", "range": "range_", "min": "min_", "max": "max_"}[node.func.id], ctx=pyast.Load())
        return self.generic_visit(node)

    def visit_Return(self, node):
        return pyast.copy_location(pyast.Return(value=_c("ret", [self.visit(node.value)])), node)


def _c(name, args):
    return pyast.Call(func=pyast.Attribute(value=pyast.Name(id="__pyra__", ctx=pyast.Load()), attr=name, ctx=pyast.Load()), args=args, keywords=[])


def _noargs():
    return pyast.arguments(posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[])


class _Ret(Exception):
    def __init__(self, value):
        self.value = value


class _DefAPI:
    def __init__(self, d, subst, ih=None):
        from . import terms
        self.d, self.subst, self.ih = d, subst, ih
        self.num = terms.Lit
        self.and_, self.or_, self.not_, self.ite = terms.and_, terms.or_, terms.not_, terms.ite
        self.sum_, self.range_, self.min_, self.max_ = terms.sum_, terms.range_, terms.min_, terms.max_

    def ret(self, v):
        t = coerce(to_term(v), self.d.result.key)
        raise _Ret(t)

    def rec(self, thunk):
        if self.ih is None:
            raise DefinitionError(f"{self.d.__name__}: recursion is only supported as `if n == 0: ... else: ... f(n - 1) ...`")
        args = thunk()
        i = [n for n, _ in self.d.params].index(self.d.rec_param)
        m, ih = self.ih
        a = coerce(to_term(args[i]), "nat").h
        a = pb.replace_fvars(a, [s for s, _ in self.subst], [t for _, t in self.subst])
        if not elab().def_eq(a, m):
            raise DefinitionError(f"{self.d.__name__}: the recursive call must be on {self.d.rec_param} - 1")
        return Term(ih, self.d.result.key)


def _evaluate(d, fdef, ns, args, api):
    """Run the (transformed) body with symbolic arguments; returns the returned Term."""
    fn = _compile(fdef, ns)
    ns["__pyra__"] = api
    try:
        fn(*args)
    except _Ret as r:
        return r.value
    raise DefinitionError(f"{d.__name__} does not return a value")


def _compile(fdef, ns):
    mod = pyast.Module(body=[fdef], type_ignores=[])
    pyast.fix_missing_locations(mod)
    code = compile(mod, ns.get("__file__", "<pyra-define>"), "exec")
    exec(code, ns)
    return ns[fdef.name]


def define(fn=None, *, heal: bool = True):
    """Elaborate a Python function into a kernel definition (see module docstring)."""
    def deco(f):
        sig = inspect.signature(f)
        params = []
        for p in sig.parameters.values():
            ann = p.annotation
            if isinstance(ann, str):
                ann = eval(ann, f.__globals__)
            if not isinstance(ann, Sort):
                raise DefinitionError(f"parameter {p.name} of {f.__name__} needs a Pyra type annotation")
            params.append((p.name, ann))
        result = sig.return_annotation
        if isinstance(result, str):
            result = eval(result, f.__globals__)
        if not isinstance(result, Sort):
            raise DefinitionError(f"{f.__name__} needs a return annotation (Nat, Int or Real)")
        key = (f.__module__, f.__qualname__)
        d = _REGISTRY.get(key)
        if d is None:
            d = Definition(key, f, params, result)
            _REGISTRY[key] = d
        else:
            d.fn, d.params, d.result = f, params, result
        _elaborate(d, f)
        if heal and d.version > 1:
            for thm in list(d.dependents):
                thm.heal()
        return d
    return deco(fn) if fn is not None else deco


def _elaborate(d, f):
    src = textwrap.dedent(inspect.getsource(f))
    d.source = src
    tree = pyast.parse(src)
    fdef = next(n for n in tree.body if isinstance(n, pyast.FunctionDef))
    fdef.decorator_list = []
    for a in fdef.args.args:
        a.annotation = None
    fdef.returns = None
    names = [n for n, _ in d.params]
    ns = dict(f.__globals__)
    fvars = [pb.mk_fvar(n, s.handle) for n, s in d.params]
    terms = [Term(v, s.key) for v, (_, s) in zip(fvars, d.params)]
    recursive = any(isinstance(x, pyast.Call) and isinstance(x.func, pyast.Name) and x.func.id == fdef.name for x in pyast.walk(fdef))
    version = d.version + 1
    lean_name = f"Pyra.Def.{d.key[0]}.{d.key[1]}.v{version}".replace("<locals>", "local").replace("<", "").replace(">", "")
    d.rec_param, d.zero, d.succ = None, None, None
    if not recursive:
        body = pyast.fix_missing_locations(_DefTransformer(fdef.name, names).visit(fdef))
        value_body = _evaluate(d, body, ns, terms, _DefAPI(d, []))
        value = pb.mk_lam_fvars(fvars, value_body.h)
    else:
        first = fdef.body[0]
        param = None
        if isinstance(first, pyast.If) and isinstance(first.test, pyast.Compare) and len(first.test.ops) == 1 \
                and isinstance(first.test.ops[0], pyast.Eq) and isinstance(first.test.left, pyast.Name) \
                and first.test.left.id in names and isinstance(first.test.comparators[0], pyast.Constant) \
                and first.test.comparators[0].value == 0:
            param = first.test.left.id
        if param is None or d.params[names.index(param)][1].key != "nat":
            raise DefinitionError(f"{f.__name__}: recursive definitions must start with `if <nat parameter> == 0:`")
        d.rec_param = param
        i = names.index(param)
        then_b = first.body
        else_b = first.orelse or fdef.body[1:]
        # value at 0
        f0 = pyast.FunctionDef(name=fdef.name, args=fdef.args, body=then_b, decorator_list=[], returns=None, type_params=[])
        f0 = pyast.fix_missing_locations(_DefTransformer(fdef.name, names).visit(f0))
        zero = elab().tpl("nat_num", [pb.mk_nat(0)])
        t0 = list(terms); t0[i] = Term(zero, "nat")
        v0 = _evaluate(d, f0, dict(ns), t0, _DefAPI(d, [(fvars[i], zero)]))
        # value at m + 1, with the recursive call as ih
        m = pb.mk_fvar("m", pb.mk_const("Nat"))
        ih = pb.mk_fvar("ih", d.result.handle)
        succ = elab().tpl("nat_add", [m, elab().tpl("nat_num", [pb.mk_nat(1)])])
        f1 = pyast.FunctionDef(name=fdef.name, args=fdef.args, body=else_b, decorator_list=[], returns=None, type_params=[])
        f1 = pyast.fix_missing_locations(_DefTransformer(fdef.name, names).visit(f1))
        t1 = list(terms); t1[i] = Term(succ, "nat")
        v1 = _evaluate(d, f1, dict(ns), t1, _DefAPI(d, [(fvars[i], succ)], ih=(m, ih)))
        others = [v for j, v in enumerate(fvars) if j != i]
        d.zero = pb.mk_lam_fvars(others, v0.h)
        d.succ = pb.mk_lam_fvars(others + [m, ih], v1.h)
        motive = pb.mk_lam("_", pb.mk_const("Nat"), d.result.handle)
        rec = pb.mk_apps(pb.mk_const("Nat.rec", [pb.level_nat(1)]),
                         [motive, v0.h, pb.mk_lam_fvars([m, ih], v1.h), fvars[i]])
        value = pb.mk_lam_fvars(fvars, rec)
    typ = pb.mk_pi_fvars(fvars, d.result.handle)
    kernel().add_definition(lean_name, [], typ, value)
    if d.lean_name:
        d.history.append(d.lean_name)
    d.lean_name, d.version = lean_name, version
    return d
