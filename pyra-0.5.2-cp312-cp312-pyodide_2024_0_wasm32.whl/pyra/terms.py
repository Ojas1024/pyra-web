"""Symbolic terms: Python syntax elaborated into Lean/Mathlib kernel terms.

A :class:`Term` wraps a 64-bit kernel handle.  Arithmetic and comparison
operators build the exact terms Lean itself would elaborate (via the
``Pyra.Tpl`` templates), so Mathlib lemmas apply to them unchanged.
"""
from __future__ import annotations

import math
from fractions import Fraction
from functools import lru_cache

from . import pyra_bind as pb
from .kernel import elab, kernel
from .naming import camel, lean_to_py


class PyraError(Exception):
    """Base class for Pyra errors."""


class ElaborationError(PyraError):
    """A construct inside ``@prove`` that Pyra cannot elaborate faithfully (an unsupported builtin,
    operator, type or statement).  Raised, with the line and a hint, instead of silently turning the
    construct into an opaque atom, a Python-level value, or a weaker statement."""

    def __init__(self, message: str, hint: str = "", line: int | None = None, source: str = ""):
        self.message, self.hint, self.line, self.source = message, hint, line, source
        super().__init__(self._format())

    def _format(self) -> str:
        s = (f"line {self.line}: " if self.line else "") + self.message
        if self.source:
            s += f"\n    {self.source}"
        if self.hint:
            s += f"\n  hint: {self.hint}"
        return s

    def located(self, line: int, source: str = "", where: str = "") -> "ElaborationError":
        if self.line is None:
            self.line, self.source = line, source
            if where:
                self.message = f"{where}: {self.message}"
            self.args = (self._format(),)
        return self


class SymbolicValueError(ElaborationError, TypeError):
    """A symbolic term used where Python needs a concrete value (int(), float(), indexing, math.*)."""


class UnsupportedValueError(ElaborationError, TypeError):
    """A Python value that has no meaning as a Pyra term (a string, None, a list, an inexact float, ...)."""


class UnsupportedAttributeError(ElaborationError, AttributeError):
    pass


_HINT_FLOAT = ("Python's float-based functions (math.sqrt, math.log, float(), ...) cannot see a symbolic term; inside a "
               "proof use pyra.sin / pyra.cos / pyra.exp, or import Mathlib's function, e.g. "
               "pyra.require('Real.sqrt', modules=['Mathlib.Analysis.SpecialFunctions.Pow.Real'])")
_HINT_INT = ("a symbolic term has no concrete integer value: use n.factorial() instead of math.factorial(n), "
             "sum(f(i) for i in range(n)) instead of a Python loop over range(n), and Pyra terms instead of list indexing")
_HINT_BITWISE = ("bitwise operators (^ << >> & | ~ on numbers), @ and divmod() are not translated on ℕ/ℤ/ℝ; use ** for powers, "
                 "// and % for division, and `and` / `or` / `not` for propositions")


def _no_concrete(what, hint):
    def method(self, *args):
        raise SymbolicValueError(f"the symbolic term `{self}` was used where Python needs a concrete {what}", hint=hint)
    return method


def _no_operator(sym):
    def method(self, *args):
        raise UnsupportedValueError(f"the operator {sym} is not supported on Pyra terms (`{self}`)", hint=_HINT_BITWISE)
    return method


class TruthValueError(ElaborationError, TypeError):
    def __init__(self, message: str = "a Pyra term has no truth value at run time", hint: str = "", line=None, source=""):
        super().__init__(message, hint or ("Python `if`/`while`/`bool()` cannot branch on a symbolic proposition here; "
                                           "use an `if` at statement level of the @prove body (a case split), "
                                           "`x if c else y` (an if-then-else term), or `assert` the proposition"), line, source)


# --------------------------------------------------------------------------- sorts
class Sort:
    """A Pyra type usable as an annotation: ``Nat``, ``Int``, ``Real``."""

    def __init__(self, key: str, lean: str):
        self.key = key
        self.lean = lean

    @property
    def handle(self) -> int:
        return pb.mk_const(self.lean)

    def __repr__(self):
        return self.lean

    def __call__(self, value):
        """``Nat(3)`` / ``Real(2.5)``: a literal of this sort."""
        return coerce(to_term(value), self.key)


Nat = Sort("nat", "Nat")
Int = Sort("int", "Int")
Rat = Sort("rat", "Rat")
Real = Sort("real", "Real")
Complex = Sort("complex", "Complex")
SORTS = {"nat": Nat, "int": Int, "rat": Rat, "real": Real, "complex": Complex}
_ORDER = {"lit": 0, "nat": 1, "int": 2, "rat": 3, "real": 4, "complex": 5}


@lru_cache(maxsize=None)
def _type_handles():
    return {pb.mk_const("Nat"): "nat", pb.mk_const("Int"): "int", pb.mk_const("Rat"): "rat", pb.mk_const("Real"): "real",
            pb.mk_const("Complex"): "complex"}


def classify(h: int) -> str:
    try:
        t = elab().infer(h)
    except Exception:
        return "other"
    s = _type_handles().get(t)
    if s:
        return s
    try:
        if elab().is_prop(h):
            return "prop"
    except Exception:
        pass
    return "other"


def tpl(name: str, *args: int) -> int:
    return elab().tpl(name, list(args))


# --------------------------------------------------------------------------- terms
class TermLike:
    """Operations shared by symbolic terms and literals.

    `Term` and `Lit` are *sibling* classes on purpose: if literals subclassed
    terms, Python would try a literal's reflected operator first and
    ``n < 2`` would turn into ``2 > n``.
    """

    __slots__ = ()

    # -- Python protocol ----------------------------------------------------
    def __hash__(self):
        return hash(("pyra.Term", self.h))

    def __bool__(self):
        raise TruthValueError(f"the symbolic term `{self}` has no Python truth value")

    def same(self, other: "Term") -> bool:
        return isinstance(other, TermLike) and other.h == self.h

    def __repr__(self):
        return pretty(self.h)

    __str__ = __repr__

    def __format__(self, spec):
        return format(str(self), spec)

    # -- structure (used by custom solvers) -----------------------------------
    @property
    def text(self) -> str:
        return pretty(self.h)

    @property
    def op(self) -> str:
        return describe(self.h)[0]

    @property
    def args(self) -> list:
        return [Term(a) for a in describe(self.h)[1]]

    @property
    def lhs(self) -> "Term":
        return self.args[0]

    @property
    def rhs(self) -> "Term":
        return self.args[1]

    # -- arithmetic ---------------------------------------------------------
    def __add__(self, o): return arith("add", self, o)
    def __radd__(self, o): return arith("add", o, self)
    def __sub__(self, o): return arith("sub", self, o)
    def __rsub__(self, o): return arith("sub", o, self)
    def __mul__(self, o): return arith("mul", self, o)
    def __rmul__(self, o): return arith("mul", o, self)
    def __truediv__(self, o): return arith("truediv", self, o)
    def __rtruediv__(self, o): return arith("truediv", o, self)
    def __floordiv__(self, o): return arith("div", self, o)
    def __rfloordiv__(self, o): return arith("div", o, self)
    def __mod__(self, o): return arith("mod", self, o)
    def __rmod__(self, o): return arith("mod", o, self)
    def __pow__(self, o, mod=None):
        return power(self, o) if mod is None else arith("mod", power(self, o), mod)      # pow(a, b, m) = a ** b % m
    def __rpow__(self, o): return power(o, self)
    def __abs__(self): return abs_(self)

    # -- no silent fallbacks: Python protocols that need a concrete value, and untranslated operators
    __int__ = _no_concrete("integer (int())", _HINT_INT)
    __index__ = _no_concrete("integer", _HINT_INT)
    __float__ = _no_concrete("float", _HINT_FLOAT)
    __complex__ = _no_concrete("complex number", "complex numbers are not supported in proofs")
    __round__ = _no_concrete("number (round())", "round() is not translated; use // or Mathlib's Int.floor / Nat.floor")
    __trunc__ = __floor__ = __ceil__ = _no_concrete("number (math.trunc/floor/ceil)", "use // or Mathlib's Int.floor / Int.ceil")
    __iter__ = _no_concrete("sequence (iteration / unpacking)",
                            "only an existential fact can be unpacked (`k, hk = h` at statement level of the proof)")
    __len__ = _no_concrete("length (len())", "len() is not translated; use the bound of a range or a Finset.card term")
    __xor__ = __rxor__ = _no_operator("^")
    __lshift__ = __rlshift__ = _no_operator("<<")
    __rshift__ = __rrshift__ = _no_operator(">>")
    __matmul__ = __rmatmul__ = _no_operator("@")
    __divmod__ = __rdivmod__ = _no_operator("divmod()")
    def __neg__(self): return negate(self)
    def __pos__(self): return self

    # -- relations ----------------------------------------------------------
    def __lt__(self, o): return relation("lt", self, o)
    def __le__(self, o): return relation("le", self, o)
    def __gt__(self, o): return relation("gt", self, o)
    def __ge__(self, o): return relation("ge", self, o)
    def __eq__(self, o): return relation("eq", self, o)
    def __ne__(self, o): return relation("ne", self, o)

    # -- logic (props) ------------------------------------------------------
    def __and__(self, o): return and_(self, o)
    def __rand__(self, o): return and_(o, self)
    def __or__(self, o): return or_(self, o)
    def __ror__(self, o): return or_(o, self)
    def __invert__(self): return not_(self)

    # -- method syntax: n.factorial(), p.min_fac(), p.is_prime() -------------
    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        sort = object.__getattribute__(self, "sort")
        if sort == "lit":
            sort = self.natural_sort()
        ns = {"nat": "Nat", "int": "Int", "rat": "Rat", "real": "Real", "complex": "Complex"}.get(sort)
        if ns is None:
            raise UnsupportedAttributeError(f"a {sort} term has no method '{name}'",
                                            hint="methods such as n.factorial() exist on Nat / Int / Rat / Real terms")
        k = kernel()
        cands = [f"{ns}.{camel(name)}", f"{ns}.{name}"]
        if name.startswith("is_"):
            rest = camel(name[3:])
            cands.append(f"{ns}.{rest[:1].upper()}{rest[1:]}")
        for c in cands:
            if k.has(c):
                return lambda *args, _c=c: call_const(_c, (self,) + args)
        raise UnsupportedAttributeError(f"{ns} has no operation '{name}' (looked for {', '.join(cands)})",
                                        hint=f"call a Lean declaration by its full name, e.g. LeanConst('{ns}.…')(x), or "
                                             f"import more of Mathlib with pyra.require")


class Term(TermLike):
    """A kernel term.  ``Term.h`` is its handle; ``Term.sort`` is nat/int/real/prop/other."""

    __slots__ = ("h", "sort", "witness")

    def __init__(self, h: int, sort: str | None = None, witness: "Term | None" = None):
        self.h = h
        self.sort = sort if sort is not None else classify(h)
        self.witness = witness

    def __call__(self, *args):
        """``f(x)`` for a function-valued term (``f: Fun[Real, Real]``): the kernel application ``f x``.
        Arguments are coerced to the function's domain; a Python ``lambda`` is accepted where the
        domain is itself a function type."""
        if not args:
            raise PyraError(f"{self} applied to no arguments")
        return Term(apply_args(self.h, args, what=str(self)))

class Fact(Term):
    """A proposition together with its proof inside a running proof: an `assume`d hypothesis or an
    established step.  ``h(a, b)`` instantiates a ∀-fact (``h : ∀ x y, P x y``) or applies an
    implication to other facts (``h(h2)`` for ``h : P → Q``, ``h2 : P``); the result is a new fact."""

    __slots__ = ("proof", "label")

    def __init__(self, h: int, proof: int, label: str = ""):
        super().__init__(h, "prop")
        self.proof = proof
        self.label = label

    def __call__(self, *args):
        from . import runtime
        proof = apply_args(self.proof, args, what=self.label or "fact")
        stmt = elab().infer(proof)
        if not elab().is_prop(stmt):
            raise PyraError(f"{self.label or 'fact'} applied to {len(args)} argument(s) is not a proposition")
        runtime.use_fact(stmt, proof, f"{self.label or 'hypothesis'}({', '.join(str(a) for a in args)})")
        return Fact(stmt, proof, self.label)


class Lit(TermLike):
    """A numeric literal whose sort is decided by context (defaults to Nat)."""

    __slots__ = ("value", "h", "sort", "witness")

    def __init__(self, value):
        if isinstance(value, float):
            value = _exact_float(value)
        if isinstance(value, Fraction) and value.denominator == 1:
            value = int(value)
        self.value = value
        sort = "real" if isinstance(value, Fraction) else ("int" if value < 0 else "nat")
        self.h = numeral(value, sort)
        self.sort = "lit"
        self.witness = None

    def __index__(self):
        if isinstance(self.value, int):
            return self.value
        raise TypeError("non-integer literal")

    def __int__(self):
        return int(self.value)

    def __float__(self):
        return float(self.value)

    def __repr__(self):
        return str(self.value)

    def natural_sort(self):
        return "real" if isinstance(self.value, Fraction) else ("int" if self.value < 0 else "nat")


def _exact_float(v: float):
    """A float literal (`2.5`, `0.1`) denotes its shortest decimal exactly.  A float with ~16+ significant digits
    is the rounding of something else (math.pi, 1/3 computed in Python, 0.1 + 0.2): refuse it rather than
    silently proving a statement about a nearby rational."""
    if v != v or v in (float("inf"), float("-inf")):
        raise UnsupportedValueError(f"{v} is not a number", hint="use an exact rational, e.g. Fraction(1, 3)")
    if v.is_integer():
        return int(v)
    text = repr(v)
    mant = text.lower().split("e")[0].lstrip("-").replace(".", "").lstrip("0")
    if len(mant) >= 16:
        raise UnsupportedValueError(f"the float {text} is inexact (it is the rounding of a real number, e.g. a value "
                                    "computed by Python)",
                                    hint="write exact values: Fraction(1, 3), 1 / 3 with literal operands inside the "
                                         "proof, a decimal literal such as 2.5, or a symbolic constant")
    return Fraction(text)


@lru_cache(maxsize=None)
def _lit_shapes(sort: str):
    return tpl(f"{sort}_zero"), tpl(f"{sort}_one"), tpl(f"{sort}_two")


@lru_cache(maxsize=4096)
def lean_numeral(n: int, sort: str) -> int:
    """The natural number `n` as a numeral of type `sort`, exactly as Lean elaborates it
    (`0`/`1` via `Zero`/`One`, `n ≥ 2` via `instOfNatAtLeastTwo` on ℝ, `instOfNat` on ℤ, ...)."""
    if sort == "nat":
        return tpl("nat_num", pb.mk_nat(n))
    zero, one, two = _lit_shapes(sort)
    if n == 0:
        return zero
    if n == 1:
        return one
    if sort in ("real", "complex"):
        # @OfNat.ofNat ℝ n (@instOfNatAtLeastTwo ℝ n Real.instNatCast
        #   (@Nat.instAtLeastTwoHAddOfNat (n - 1) (@Nat.instNeZeroSucc (n - 2))))   -- as Lean elaborates it
        z = pb.level_zero()
        R = pb.mk_const("Real" if sort == "real" else "Complex")
        two_inst = pb.mk_apps(pb.mk_const("Nat.instAtLeastTwoHAddOfNat"),
                              [tpl("nat_num", pb.mk_nat(n - 1)), pb.mk_app(pb.mk_const("Nat.instNeZeroSucc"), tpl("nat_num", pb.mk_nat(n - 2)))])
        cast = pb.mk_const("Real.instNatCast" if sort == "real" else "Complex.instNatCast")
        inst = pb.mk_apps(pb.mk_const("instOfNatAtLeastTwo", [z]), [R, pb.mk_nat(n), cast, two_inst])
        return pb.mk_apps(pb.mk_const("OfNat.ofNat", [z]), [R, pb.mk_nat(n), inst])
    # ℤ, ℚ: the instance is indexed by the literal itself (`instOfNat n`, `Rat.instOfNat n`)
    return pb.replace_term(two, pb.mk_nat(2), pb.mk_nat(n))


def numeral(v, sort: str) -> int:
    if sort == "nat":
        if not isinstance(v, int) or v < 0:
            raise PyraError(f"{v} is not a natural number")
        return tpl("nat_num", pb.mk_nat(v))
    if sort == "int":
        if not isinstance(v, int):
            raise PyraError(f"{v} is not an integer")
        base = lean_numeral(abs(v), "int")
        return tpl("int_neg", base) if v < 0 else base
    if sort in ("real", "rat", "complex"):
        q = Fraction(v)
        base = lean_numeral(abs(q.numerator), sort)
        if q.denominator != 1:
            base = tpl(f"{sort}_div", base, lean_numeral(q.denominator, sort))
        return tpl(f"{sort}_neg", base) if q < 0 else base
    raise PyraError(f"no numerals of sort {sort}")


def imaginary_unit() -> "Term":
    """``Complex.I``."""
    return Term(tpl("complex_I"), "complex")


def to_term(x) -> Term:
    if isinstance(x, TermLike):
        return x
    if isinstance(x, bool):
        return Term(tpl("true_" if x else "false_"), "prop")
    if isinstance(x, complex):
        re, im = Fraction(x.real).limit_denominator(10 ** 12), Fraction(x.imag).limit_denominator(10 ** 12)
        r = Term(numeral(re, "complex"), "complex")
        return r if im == 0 else arith("add", r, arith("mul", Term(numeral(im, "complex"), "complex"), imaginary_unit()))
    if isinstance(x, (int, float, Fraction)):
        return Lit(x)
    if isinstance(x, LeanConst):              # a Lean constant used as a value (Real.pi, Complex.I, ...)
        _ensure_loaded(x.lean_name)
        _explicit_mask.cache_clear()
        mask = _explicit_mask(x.lean_name)
        if not any(mask):                     # no explicit arguments: the constant itself (implicits solved)
            return Term(elab().apply(x.lean_name, []))
        raise ElaborationError(f"the Lean declaration {x.lean_name} takes arguments and cannot be used as a value",
                               hint=f"apply it: {x.__name__}(...)")
    if isinstance(x, PyraRange):              # range(n) as a value: Finset.range n
        from .finset import as_finset
        return as_finset(x)
    hint = {str: "strings have no meaning in a proposition; compare numbers or call a Lean predicate",
            type(None): "a helper function returned None: did it forget a `return`?",
            list: "lists are not translated; write the terms explicitly or use sum(f(i) for i in range(n))",
            tuple: "tuples are not translated; write the terms explicitly",
            complex: "complex numbers are not supported in proofs"}.get(type(x))
    if hint is None:
        hint = ("only Pyra terms, Python ints / exact fractions / decimal literals and booleans can appear in a proof; "
                "wrap Lean declarations with LeanConst or import them from pyra.mathlib")
    raise UnsupportedValueError(f"cannot use {type(x).__name__} {x!r} in a Pyra term", hint=hint)


_CAST_OPS = {"HAdd.hAdd": "add", "HMul.hMul": "mul", "HPow.hPow": "pow"}


def _push_cast(h: int, src: str, sort: str) -> int:
    """Cast a ℕ/ℤ term into a larger sort, pushing the cast through + * ** and numerals
    (so that ``x * (n + 1)`` means ``x * (↑n + 1)``)."""
    if pb.kind(h) == "app" and pb.kind(pb.head(h)) == "const":
        n = pb.const_name(pb.head(h))
        a = pb.args(h)
        v = _lit_of(h)
        if v is not None:
            return numeral(v, sort)
        if n in _CAST_OPS and len(a) == 6:
            if n == "HPow.hPow":
                return tpl(f"{sort}_pow", _push_cast(a[4], src, sort), a[5])
            return tpl(f"{sort}_{_CAST_OPS[n]}", _push_cast(a[4], src, sort), _push_cast(a[5], src, sort))
        # A closed numeral expression takes the expected type, as in Lean (`x / (2 ^ 2 - 3 ^ 2)` over ℝ
        # is real subtraction, not a cast of ℕ's truncated one).
        if not pb.has_fvars(h):
            if n == "HSub.hSub" and len(a) == 6:
                return tpl(f"{sort}_sub", _push_cast(a[4], src, sort), _push_cast(a[5], src, sort))
            if n == "Neg.neg" and len(a) == 3:
                return tpl(f"{sort}_neg", _push_cast(a[2], src, sort))
    return tpl(f"{sort}_of_{src}", h)


def coerce(t: Term, sort: str) -> Term:
    if t.sort == sort:
        return t
    if t.sort == "lit":
        return Term(numeral(t.value, sort), sort)
    if t.sort in _ORDER and sort in _ORDER and _ORDER[t.sort] < _ORDER[sort]:
        return Term(_push_cast(t.h, t.sort, sort), sort)
    raise ElaborationError(f"cannot convert a {t.sort} term ({t}) to {sort}",
                           hint="Pyra casts only upwards (ℕ → ℤ → ℚ → ℝ); state the claim in the larger type, or use "
                                "Mathlib's floor / toNat functions explicitly")


def _is_lit(t) -> bool:
    return isinstance(t, Lit) and t.sort == "lit"


def effective_sort(t: Term) -> str:
    return t.natural_sort() if _is_lit(t) else t.sort


def join(a: Term, b: Term) -> str:
    sa, sb = effective_sort(a), effective_sort(b)
    for s in (sa, sb):
        if s not in _ORDER:
            raise ElaborationError(f"arithmetic on a non-numeric term of sort '{s}'",
                                   hint="+ - * / // % ** apply to Nat / Int / Rat / Real terms; a proposition is not a number")
    return max(sa, sb, key=lambda x: _ORDER[x])


def arith(op: str, a, b) -> Term:
    A, B = to_term(a), to_term(b)
    if "other" in (A.sort, B.sort):          # groups, rings, polynomials, ℂ, ...: Lean's generic operators
        from .structures import generic_arith
        return generic_arith(op, A, B)
    s = join(A, B)
    if op == "truediv" and s in ("nat", "int"):
        s = "real"
    if op == "truediv":
        op = "div"
    if op == "mod" and s in ("real", "rat"):
        raise ElaborationError(f"% is not defined on {'reals' if s == 'real' else 'rationals'} ({A} % {B})",
                               hint="% is translated on Nat and Int only; for reals write x - k * Int.floor(x / k) explicitly")
    A, B = coerce(A, s), coerce(B, s)
    return Term(tpl(f"{s}_{op}", A.h, B.h), s)


def inv(a) -> Term:
    """``inv(x)`` (also ``x ** -1``): Lean's ``x⁻¹`` on ℝ / ℚ (on ℕ / ℤ terms, the real inverse)."""
    A = to_term(a)
    if A.sort == "other":                  # groups, fields other than ℚ/ℝ, ...: Inv.inv by instance search
        from .structures import inv as generic_inv
        return generic_inv(A)
    s = effective_sort(A)
    if s in ("nat", "int"):
        s = "real"
    if s not in ("rat", "real"):
        raise PyraError("inverse of a non-numeric term")
    A = coerce(A, s)
    # exactly Lean's `x⁻¹`: @Inv.inv ℝ Real.instInv x (resp. ℚ, Rat.instInv)
    T = "Real" if s == "real" else "Rat"
    return Term(pb.mk_apps(pb.mk_const("Inv.inv", [pb.level_zero()]), [pb.mk_const(T), pb.mk_const(f"{T}.instInv"), A.h]), s)


def power(a, b) -> Term:
    A, B = to_term(a), to_term(b)
    if A.sort == "other":
        from .structures import generic_power
        return generic_power(A, B)
    neg = None
    if isinstance(B, Lit) and isinstance(B.value, int) and B.value < 0:
        neg = B.value
    elif B.sort == "int" and not pb.has_fvars(B.h):
        try:
            v = evaluate(B.h, {})
            neg = v if isinstance(v, int) and v < 0 else None
        except Unevaluable:
            pass
    if neg is not None:
        if neg == -1:
            return inv(A)
        raise PyraError(f"x ** {neg}: write inv(x) ** {-neg} (Lean's x⁻¹ ^ {-neg}) or inv(x ** {-neg})")
    s = effective_sort(A)
    if B.sort == "real" and s in ("lit", "nat", "int", "rat", "real"):
        # a real exponent: Mathlib's rpow, exactly as Lean elaborates `(a : ℝ) ^ (x : ℝ)`
        if not kernel().has("Real.instPow"):
            raise PyraError("a real exponent needs rpow: pyra.require(modules=['Mathlib.Analysis.SpecialFunctions.Pow.Real'])")
        R = pb.mk_const("Real")
        z = pb.level_zero()
        inst = pb.mk_apps(pb.mk_const("instHPow", [z, z]), [R, R, pb.mk_const("Real.instPow")])
        return Term(pb.mk_apps(pb.mk_const("HPow.hPow", [z, z, z]), [R, R, R, inst, coerce(A, "real").h, B.h]), "real")
    if s not in SORTS:
        raise ElaborationError(f"** needs a numeric base, got {A} ({s})", hint="raise Nat / Int / Rat / Real terms to a power")
    eb = effective_sort(B)
    if eb != "nat":
        raise ElaborationError(f"the exponent of {A} ** {B} is not a natural number",
                               hint="exponents must be natural numbers (x ** 2, x ** n with n: Nat); for roots use "
                                    "Real.sqrt via pyra.require, for real powers Mathlib's Real.rpow")
    return Term(tpl(f"{s}_pow", coerce(A, s).h, coerce(B, "nat").h), s)


def negate(a) -> Term:
    A = to_term(a)
    if A.sort == "other":
        from .structures import negate as generic_negate
        return generic_negate(A)
    if _is_lit(A):
        return Lit(-A.value)          # `-7` stays a literal: its type comes from the context, as in Lean
    s = effective_sort(A)
    if s == "nat":
        s = "int"
    return Term(tpl(f"{s}_neg", coerce(A, s).h), s)


def _is_pyfun(x) -> bool:
    """A Python function or lambda (not a Lean constant, term, sort or class)."""
    return callable(x) and hasattr(x, "__code__") and not isinstance(x, (TermLike, Sort, FunType, type, LeanConst))


def relation(op: str, a, b) -> Term:
    # `f == lambda x: ...`: the lambda takes the type of the function-valued side
    if _is_pyfun(b) and isinstance(a, Term):
        b = Term(lambda_term(b, elab().infer(a.h)), "other")
    elif _is_pyfun(a) and isinstance(b, Term):
        a = Term(lambda_term(a, elab().infer(b.h)), "other")
    A, B = to_term(a), to_term(b)
    if A.sort == "prop" and B.sort == "prop" and op in ("eq", "ne"):
        r = Term(tpl("iff_", A.h, B.h), "prop")
        return r if op == "eq" else not_(r)
    if A.sort in ("other", "finset", "fun", "set") or B.sort in ("other", "finset", "fun", "set"):
        T = elab().infer(A.h)
        if pb.kind(_whnf_pi(T)) == "pi" or A.sort in ("finset", "fun", "set") or B.sort in ("finset", "fun", "set"):
            if op not in ("eq", "ne"):
                raise PyraError(f"terms of sort {A.sort} can only be compared with == and !=, not {op}")
            # @Eq.{u} T a b with u the (simplified) universe of T (functions, finsets, sets)
            lvl = pb.level_simplify(pb.sort_level(elab().whnf(elab().infer(T))))
            e = Term(pb.mk_apps(pb.mk_const("Eq", [lvl]), [T, A.h, B.h]), "prop")
        else:
            from .structures import generic_relation
            return generic_relation(op, A, B)
        return e if op == "eq" else not_(e)
    s = join(A, B)
    A, B = coerce(A, s), coerce(B, s)
    return Term(tpl(f"{s}_{op}", A.h, B.h), "prop")


def _prop(x) -> Term:
    t = to_term(x)
    if t.sort != "prop":
        raise ElaborationError(f"expected a proposition, got {t} ({t.sort})",
                               hint="and / or / not (and & | ~) combine propositions such as comparisons; bitwise "
                                    "operations on numbers are not translated")
    return t


def and_(*xs) -> Term:
    ts = [_prop(x) for x in xs]
    r = ts[-1]
    for t in reversed(ts[:-1]):
        r = Term(tpl("and_", t.h, r.h), "prop")
    return r


def or_(*xs) -> Term:
    ts = [_prop(x) for x in xs]
    r = ts[-1]
    for t in reversed(ts[:-1]):
        r = Term(tpl("or_", t.h, r.h), "prop")
    return r


def not_(x) -> Term:
    return Term(tpl("not_", _prop(x).h), "prop")


def implies(a, b) -> Term:
    return Term(tpl("imp_", _prop(a).h, _prop(b).h), "prop")


def iff(a, b) -> Term:
    return Term(tpl("iff_", _prop(a).h, _prop(b).h), "prop")


def divides(a, b) -> Term:
    """``a ∣ b`` on ℕ (or on ℤ when either side is an integer)."""
    A, B = to_term(a), to_term(b)
    s = "int" if "int" in (effective_sort(A), effective_sort(B)) else "nat"
    return Term(tpl(f"{s}_dvd", coerce(A, s).h, coerce(B, s).h), "prop")


def ite(c, a, b) -> Term:
    C, A, B = _prop(c), to_term(a), to_term(b)
    s = join(A, B)
    inst = decidable_instance(C.h)
    return Term(tpl("nat_ite", C.h, inst, coerce(A, s).h, coerce(B, s).h), s)


# --------------------------------------------------------------------------- function types
class FunType:
    """``Fun[A, B]`` is the Lean type ``A → B``; ``Fun[A, B, C]`` is ``A → B → C`` (curried).

    As a parameter annotation (``f: Fun[Real, Real]``) it introduces a function-valued variable;
    ``f(x)`` is the kernel application ``f x``."""

    def __init__(self, sorts):
        if len(sorts) < 2:
            raise PyraError("Fun[...] needs at least a domain and a codomain, e.g. Fun[Real, Real]")
        for s in sorts:
            if not isinstance(s, (Sort, FunType)):
                raise PyraError(f"Fun[...]: {s!r} is not a Pyra type (Nat, Int, Rat, Real or Fun[...])")
        self.sorts = tuple(sorts)
        self.key = "fun"

    @property
    def handle(self) -> int:
        t = self.sorts[-1].handle
        for d in reversed(self.sorts[:-1]):
            t = pb.mk_pi("x", d.handle, t)
        return t

    def make(self, name: str) -> Term:
        """A variable of this type (used by ``@prove`` for annotated parameters)."""
        return Term(pb.mk_fvar(name, self.handle), "other")

    def __call__(self, fn) -> Term:
        """``Fun[Real, Real](lambda x: x ** 2)``: a lambda as a function term of this type."""
        return Term(lambda_term(fn, self.handle), "other")

    def __eq__(self, other):
        return isinstance(other, FunType) and other.sorts == self.sorts

    def __hash__(self):
        return hash(("Fun", self.sorts))

    def __repr__(self):
        return "Fun[" + ", ".join(repr(s) for s in self.sorts) + "]"


class Fun:
    """``Fun[Real, Real]``, ``Fun[Nat, Nat]``, ``Fun[Real, Real, Real]`` (= ``ℝ → ℝ → ℝ``)."""

    def __class_getitem__(cls, item):
        return FunType(item if isinstance(item, tuple) else (item,))

    def __init__(self, *a, **k):
        raise TypeError("use Fun[Domain, ..., Codomain]")


def _sort_of_type(ty: int):
    """'nat' / 'int' / 'rat' / 'real' for a number type handle, else None."""
    return _type_handles().get(ty)


def _whnf_pi(ty: int) -> int:
    if pb.kind(ty) == "pi":
        return ty
    try:
        w = elab().whnf(ty)
    except Exception:
        return ty
    return w


def _arg_for(a, dom: int) -> int:
    """The handle of argument `a` for a binder of type `dom` (casting numbers, building lambdas)."""
    if isinstance(a, Fact):
        return a.proof
    if _is_pyfun(a):
        return lambda_term(a, dom)
    s = _sort_of_type(dom)
    t = to_term(a)
    if t.sort == "prop":
        # a proposition where a *proof* of it is expected (the binder's type is a proposition, not `Prop`):
        # use the established fact, or prove it as a step (v0.5.2; passing the proposition itself made an
        # ill-typed term that the kernel rejected only when checking the whole theorem)
        try:
            dom_is_proposition = elab().is_prop(dom)
        except Exception:  # noqa: BLE001
            dom_is_proposition = False
        if dom_is_proposition:
            from . import runtime
            s_ = runtime.current_session()
            if s_ is None:
                raise ElaborationError(f"the proposition {t} is passed where a proof of it is expected",
                                       hint="outside a proof, pass a fact (an assumption or an asserted statement)")
            return s_.establish(t).proof
    if s is not None and (t.sort in _ORDER):
        return coerce(t, s).h
    return _arg_handle(t)


def apply_args(fn: int, args, what: str = "function") -> int:
    """Apply the term `fn` (of a ∀ / function type) to `args`, coercing each to its binder type."""
    cur = fn
    for i, a in enumerate(args):
        ty = _whnf_pi(elab().infer(cur))
        if pb.kind(ty) != "pi":
            raise PyraError(f"{what} takes {i} argument(s), got {len(args)}")
        cur = pb.mk_app(cur, _arg_for(a, pb.binder_type(ty)))
    try:
        kernel().check(cur)               # ill-typed applications are reported here, at the call
    except Exception as e:  # noqa: BLE001
        raise ElaborationError(f"{what} cannot be applied to ({', '.join(str(a) for a in args)}): {e}",
                               hint="check the number, order and types of the arguments") from None
    return cur


def lambda_term(fn, ty: int) -> int:
    """A Python ``lambda`` as a kernel ``fun`` of the (function) type `ty`."""
    code = fn.__code__
    n = code.co_argcount
    names = list(code.co_varnames[:n])
    xs, cur = [], ty
    for i in range(n):
        cur = _whnf_pi(cur)
        if pb.kind(cur) != "pi":
            raise PyraError(f"the lambda takes {n} argument(s) but the expected type has {i}")
        dom = pb.binder_type(cur)
        x = pb.mk_fvar(names[i], dom)
        xs.append(x)
        cur = pb.instantiate(pb.binder_body(cur), [x])
    s = _sort_of_type(cur)
    vals = [Term(x, _sort_of_type(pb.fvar_type(x)) or "other") for x in xs]
    body = fn(*vals)
    if s is not None:
        bh = coerce(to_term(body), s).h
    elif _is_pyfun(body):
        bh = lambda_term(body, cur)
    else:
        bh = to_term(body).h
    return pb.mk_lam_fvars(xs, bh)


# --------------------------------------------------------------------------- binders
def _binder_sort(sort):
    if sort is None:
        return Nat
    if isinstance(sort, (Sort, FunType)):
        return sort
    if hasattr(sort, "handle"):              # Fun[...], Set[...], a structure's type variable, ...
        return sort
    raise PyraError(f"{sort!r} is not a Pyra sort")


def _binder_sorts(fn, sort):
    """One sort per parameter of `fn` (``sort`` may be a single sort or a tuple)."""
    n = max(1, fn.__code__.co_argcount)
    if isinstance(sort, (tuple, list)):
        if len(sort) != n:
            raise PyraError(f"{n} bound variable(s) but {len(sort)} sort(s)")
        return [_binder_sort(s) for s in sort]
    return [_binder_sort(sort)] * n


def _basic_sorts(sort) -> bool:
    ss = sort if isinstance(sort, (tuple, list)) else [sort]
    return all(s is None or isinstance(s, (Sort, FunType)) for s in ss)


def _quantified(fn, sort, kind):
    sorts = _binder_sorts(fn, sort)
    names = list(fn.__code__.co_varnames[:fn.__code__.co_argcount]) or ["x"]
    xs = [pb.mk_fvar(nm, S.handle) for nm, S in zip(names, sorts)]
    b = _prop(fn(*[Term(x, S.key if isinstance(S, Sort) else "other") for x, S in zip(xs, sorts)]))
    r = b.h
    for x, S in reversed(list(zip(xs, sorts))):
        lam = pb.mk_lam_fvars([x], r)
        if kind == "forall":
            r = pb.mk_pi_fvars([x], r)         # = Pyra.Tpl.<sort>_forall, keeping the binder's name
        elif isinstance(S, Sort):
            r = tpl(f"{S.key}_{kind}", lam)
        else:
            r = pb.mk_apps(pb.mk_const("Exists", [pb.level_succ(pb.level_zero())]), [S.handle, lam])
    return Term(r, "prop")


def exists(var, body=None, *, sort=None) -> Term:
    """``exists(p, P(p))`` (with a witness term ``p``) or ``exists(lambda x: P(x), sort=Real)``
    (several bound variables: ``exists(lambda x, y: ..., sort=(Int, Int))``)."""
    if body is None and _is_pyfun(var):
        if not _basic_sorts(sort):                       # Set[...], a structure's carrier, ...
            from .structures import exists_over
            return exists_over(_binder_sort(sort), var)
        return _quantified(var, sort, "exists")
    w = to_term(var)
    b = _prop(body)
    s = effective_sort(w)
    if s == "other":                          # a witness of any other type (an ideal, a set, ...)
        x = pb.mk_fvar(display_names().get(w.h, "x"), elab().infer(w.h))
        return Term(elab().apply("Exists", [pb.mk_lam_fvars([x], pb.replace_term(b.h, w.h, x))]), "prop", witness=w)
    if s not in SORTS:
        raise PyraError("exists() needs a numeric witness")
    w = coerce(w, s)
    name = display_names().get(w.h, "x")
    x = pb.mk_fvar(name, SORTS[s].handle)
    lam = pb.mk_lam_fvars([x], pb.replace_term(b.h, w.h, x))
    return Term(tpl(f"{s}_exists", lam), "prop", witness=w)


def forall(fn, *, sort=None) -> Term:
    """``forall(lambda x: P(x), sort=Real)``; several variables: ``forall(lambda x, y: ..., sort=Real)``
    (one sort for all, or a tuple of sorts)."""
    if not _basic_sorts(sort):
        from .structures import forall_over
        return forall_over(_binder_sort(sort), fn)
    return _quantified(fn, sort, "forall")


# --------------------------------------------------------------------------- sums and ranges
class PyraRange:
    """``range(n)`` inside a proof.  Iterable when its bound is a concrete number."""

    def __init__(self, *args):
        if len(args) not in (1, 2):
            raise ElaborationError(f"range with {len(args)} arguments is not translated", hint="use range(n) or range(a, b)")
        self.start = to_term(args[0]) if len(args) == 2 else None     # range(a, b) is Finset.Ico a b
        self.n = to_term(args[-1])

    def __iter__(self):
        lo = 0 if self.start is None else self.start
        if all(isinstance(v, int) or (isinstance(v, Lit) and isinstance(v.value, int)) for v in (lo, self.n)):
            return iter(range(int(lo), int(self.n)))
        raise SymbolicValueError(f"cannot iterate over range({self.n}): its bound is symbolic",
                                 hint="sum / prod / len over a symbolic range are translated as comprehensions, e.g. sum(f(i) for i in range(n))")

    def __len__(self):
        return len(range(0 if self.start is None else int(self.start), int(self.n)))

    def __repr__(self):
        return f"range({self.n})" if self.start is None else f"range({self.start}, {self.n})"


def _lam_nat(fn, name="i") -> int:
    x = pb.mk_fvar(name, pb.mk_const("Nat"))
    body = coerce(to_term(fn(Term(x, "nat"))), "nat")
    return pb.mk_lam_fvars([x], body.h)


def _over(kind, fn, n) -> Term:
    var = fn.__code__.co_varnames[0] if fn.__code__.co_varnames else "i"
    x = pb.mk_fvar(var, pb.mk_const("Nat"))
    body = to_term(fn(Term(x, "nat")))
    if effective_sort(body) in ("int", "rat", "real"):
        from .finset import aggregate          # ℤ / ℚ / ℝ bodies
        return aggregate(kind, fn, PyraRange(n), None, var)
    lam = pb.mk_lam_fvars([x], coerce(body, "nat").h)
    return Term(tpl(f"nat_{kind}_range", coerce(to_term(n), "nat").h, lam), "nat")


def sum_over(fn, n) -> Term:
    return _over("sum", fn, n)


def prod_over(fn, n) -> Term:
    return _over("prod", fn, n)


def sum_(x, start=0):
    if isinstance(x, PyraRange) and x.start is None:
        r = sum_over(lambda i: i, x.n)
        return r if (isinstance(start, (int, Lit)) and int(start) == 0) else r + start
    from .finset import is_finset_like, aggregate
    if is_finset_like(x):
        r = aggregate("sum", None, x)
        return r if (isinstance(start, (int, Lit)) and int(start) == 0) else r + start
    return sum(x, start)


def range_(*args):
    if all(isinstance(a, int) and not isinstance(a, TermLike) for a in args):
        return range(*args)
    return PyraRange(*args)


def abs_(x):
    """``abs(x)``: Mathlib's ``|x|`` on ℝ and ℤ (the identity on ℕ)."""
    if not isinstance(x, TermLike):
        return abs(x)
    t = to_term(x)
    s = effective_sort(t)
    if s == "nat":
        return coerce(t, "nat")
    return Term(tpl(f"{s}_abs", coerce(t, s).h), s)


def min_(a, b, *rest):
    if rest:
        r = min_(a, b)
        for c in rest:
            r = min_(r, c)
        return r
    if not isinstance(a, TermLike) and not isinstance(b, TermLike):
        return min(a, b)
    A, B = to_term(a), to_term(b)
    s = join(A, B)
    return Term(tpl(f"{s}_min", coerce(A, s).h, coerce(B, s).h), s)


def max_(a, b, *rest):
    if rest:
        r = max_(a, b)
        for c in rest:
            r = max_(r, c)
        return r
    if not isinstance(a, TermLike) and not isinstance(b, TermLike):
        return max(a, b)
    A, B = to_term(a), to_term(b)
    s = join(A, B)
    return Term(tpl(f"{s}_max", coerce(A, s).h, coerce(B, s).h), s)


def _real_fn(name: str, x) -> Term:
    t = to_term(x)
    s = effective_sort(t)
    if s not in _ORDER:
        raise ElaborationError(f"{name}() needs a number, got {t} (sort {t.sort})",
                               hint=f"{name}(x) is Mathlib's Real.{name}; pass a numeric term")
    return Term(tpl(f"real_{name}", coerce(t, "real").h), "real")


def sin(x) -> Term:
    """``Real.sin x`` (Mathlib)."""
    return _real_fn("sin", x)


def cos(x) -> Term:
    """``Real.cos x`` (Mathlib)."""
    return _real_fn("cos", x)


def exp(x) -> Term:
    """``Real.exp x`` (Mathlib)."""
    return _real_fn("exp", x)


def decidable_instance(prop: int) -> int:
    """A `Decidable prop` instance: Lean's own (instance search) when there is one, else classical."""
    try:
        inst = elab().synth(pb.mk_app(pb.mk_const("Decidable"), prop))
    except Exception:
        inst = None
    return inst if inst is not None else elab().apply("Classical.propDecidable", [prop])


# --------------------------------------------------------------------------- library constants
def _arg_handle(a) -> int:
    if isinstance(a, Sort) or (not isinstance(a, TermLike) and hasattr(a, "handle")):
        return a.handle                      # a type argument: ConvexOn(Real, ...)
    t = to_term(a)
    if isinstance(t, Lit) and t.sort == "lit":
        return numeral(t.value, t.natural_sort())
    return t.h


@lru_cache(maxsize=None)
def _explicit_domains(const: str) -> tuple:
    """Types of the explicit binders of `const` (None where they depend on earlier binders)."""
    try:
        t = kernel().const_type(const)
    except Exception:
        return ()
    out = []
    while pb.kind(t) == "pi":
        if pb.binder_info(t) == 0:
            d = pb.binder_type(t)
            out.append(d if pb.loose_bvar_range(d) == 0 and not pb.has_fvars(d) else None)
        t = pb.binder_body(t)
    return tuple(out)


def _is_type_former(t: int) -> bool:
    """Is `t` (a declaration's type) of the form ... → Sort u (a type or type constructor)?"""
    while pb.kind(t) == "pi":
        t = pb.binder_body(t)
    return pb.kind(t) == "sort"


def _ensure_loaded(name: str) -> None:
    """A Mathlib declaration that the bundled library lacks is imported (from .olean) on first use."""
    k = kernel()
    if not k.has(name):
        from .library import require, olean_index
        try:
            require(name)
            # a type comes with its instances: import the rest of its defining module as well
            if not elab().is_prop(k.const_type(name)) and _is_type_former(k.const_type(name)):
                mod = olean_index().module_of(name)
                if mod:
                    require(modules=[mod])
                # and the @[instance] declarations in its namespace (ZMod.instInv, ZMod.commRing, ...)
                from .lean_bridge import instances_from_olean
                ix = olean_index()
                if "Mathlib" not in ix.indexed_modules():
                    ix.add_module("Mathlib")
                insts = [n for n, _ in instances_from_olean(ix) if n.startswith(name + ".") and not k.has(n)]
                if insts:
                    require(*insts)
        except Exception as e:  # noqa: BLE001
            raise ElaborationError(f"the Lean declaration {name} is not available: {e}",
                                   hint="check the name (Mathlib v4.33) or load it with pyra.require(..., modules=[...])") from None


def call_const(name: str, args) -> Term:
    from . import runtime
    if not kernel().has(name):
        _ensure_loaded(name)
        _explicit_mask.cache_clear()
        if hasattr(_explicit_domains, "cache_clear"):
            _explicit_domains.cache_clear()
    doms = _explicit_domains(name)
    hs = []
    for i, a in enumerate(args):
        d = doms[i] if i < len(doms) else None
        h = None
        if d is not None and (_sort_of_type(d) is not None or _is_pyfun(a)):
            try:
                h = _arg_for(a, d)            # `Real.sqrt(4)`: the literal is a real number
            except PyraError:
                h = None
        hs.append(h if h is not None else _arg_handle(a))
    try:
        h = elab().apply(name, hs)
        elab().infer(h)                 # an ill-typed application must not become an opaque atom
    except PyraError:
        raise
    except Exception as e:
        shown = ", ".join(str(a) for a in args)
        try:
            sig = pretty(kernel().const_type(name))
        except Exception:
            sig = "?"
        raise ElaborationError(f"the Lean declaration {name} cannot be applied to ({shown}): {e}",
                               hint=f"check the number and types of the arguments; {name} : {sig}") from None
    info = kernel().find(name)
    if info and info["kind"] == "thm":
        # Using a lemma inside a proof brings its instance into scope.
        stmt = elab().infer(h)
        runtime.use_fact(stmt, h, name)
        return Term(stmt, "prop")
    from .finset import wrap_finset
    return wrap_finset(Term(h))


class LeanConst:
    """A Lean/Mathlib declaration exposed to Python (e.g. ``is_prime`` = ``Nat.Prime``)."""

    def __init__(self, lean_name: str, kind: str = "", doc: str = "", pyname: str = ""):
        self.lean_name = lean_name
        self.kind = kind
        self.__doc__ = doc or f"Lean declaration `{lean_name}`."
        self.__name__ = pyname or lean_to_py(lean_name)

    def __call__(self, *args):
        return call_const(self.lean_name, args)

    @property
    def statement(self) -> str:
        return pretty(kernel().const_type(self.lean_name))

    def __repr__(self):
        return f"<{self.kind or 'decl'} {self.lean_name}>"


# --------------------------------------------------------------------------- display names
_DISPLAY = {}


def display_names() -> dict:
    from . import runtime
    s = runtime.current_session()
    return s.names if s is not None else _DISPLAY


@lru_cache(maxsize=None)
def _explicit_mask(const: str) -> tuple:
    try:
        t = kernel().const_type(const)
    except Exception:
        return ()
    mask = []
    while pb.kind(t) == "pi":
        mask.append(pb.binder_info(t) == 0)
        t = pb.binder_body(t)
    return tuple(mask)


@lru_cache(maxsize=None)
def _is_predicate(const: str) -> bool:
    try:
        t = kernel().const_type(const)
    except Exception:
        return False
    while pb.kind(t) == "pi":
        t = pb.binder_body(t)
    return pb.kind(t) == "sort" and pb.sort_level(t) == pb.level_zero()


_INFIX = {"HAdd.hAdd": ("+", 6), "HSub.hSub": ("-", 6), "HMul.hMul": ("*", 7), "HDiv.hDiv": ("/", 7),
          "HMod.hMod": ("%", 7), "HPow.hPow": ("**", 9)}
_REL = {"Eq": ("==", 3), "Ne": ("!=", 4), "LT.lt": ("<", 4), "LE.le": ("<=", 4), "GT.gt": (">", 4), "GE.ge": (">=", 4)}


def _lit_of(h):
    k = pb.kind(h)
    if k == "nat":
        return pb.nat_value(h)
    if k == "app" and pb.kind(pb.head(h)) == "const" and pb.const_name(pb.head(h)) == "OfNat.ofNat":
        a = pb.args(h)
        if len(a) == 3 and pb.kind(a[1]) == "nat":
            return pb.nat_value(a[1])
    return None


def pretty(h: int, names: dict | None = None) -> str:
    names = display_names() if names is None else names
    return _pp(h, names, [], 0)


def _pp(h, names, ctx, prec) -> str:
    if h in names:
        return names[h]
    k = pb.kind(h)
    wrap = (lambda s, p: f"({s})" if p < prec else s)
    if k == "fvar":
        return pb.fvar_name(h) or "_"
    if k == "bvar":
        i = pb.bvar_index(h)
        return ctx[-1 - i] if i < len(ctx) else f"#{i}"
    if k == "nat":
        return str(pb.nat_value(h))
    if k == "sort":
        return "Prop" if pb.sort_level(h) == pb.level_zero() else "Type"
    if k == "const":
        n = pb.const_name(h)
        return {"True": "True", "False": "False", "Nat": "Nat", "Real": "Real", "Int": "Int"}.get(n, lean_to_py(n, predicate=_is_predicate(n)))
    if k == "lam":
        nm = pb.binder_name(h) or "x"
        return wrap(f"lambda {nm}: {_pp(pb.binder_body(h), names, ctx + [nm], 0)}", 0)
    if k == "pi":
        body = pb.binder_body(h)
        nm = pb.binder_name(h) or "x"
        if pb.loose_bvar_range(body) == 0:
            from_ = _pp(pb.binder_type(h), names, ctx, 1)
            return wrap(f"{from_} -> {_pp(body, names, ctx + [nm], 0)}", 0)
        return wrap(f"forall({nm}: {_pp(pb.binder_type(h), names, ctx, 0)}, {_pp(body, names, ctx + [nm], 0)})", 0)
    if k != "app":
        return pb.to_string(h)
    v = _lit_of(h)
    if v is not None:
        return str(v)
    head = pb.head(h)
    args = pb.args(h)
    if pb.kind(head) == "const":
        n = pb.const_name(head)
        if n in _INFIX and len(args) == 6:
            sym, p = _INFIX[n]
            if n == "HDiv.hDiv" and pb.kind(args[0]) == "const" and pb.const_name(args[0]) in ("Nat", "Int"):
                sym = "//"
            if n == "HPow.hPow":
                return wrap(f"{_pp(args[4], names, ctx, p + 1)} ** {_pp(args[5], names, ctx, p)}", p)
            return wrap(f"{_pp(args[4], names, ctx, p)} {sym} {_pp(args[5], names, ctx, p + 1)}", p)
        if n in _REL and len(args) in (3, 4):
            sym, p = _REL[n]
            return wrap(f"{_pp(args[-2], names, ctx, p + 1)} {sym} {_pp(args[-1], names, ctx, p + 1)}", p)
        if n == "Not" and len(args) == 1:
            inner = args[0]
            if pb.kind(inner) == "app" and pb.kind(pb.head(inner)) == "const" and pb.const_name(pb.head(inner)) == "Eq" and len(pb.args(inner)) == 3:
                a = pb.args(inner)
                return wrap(f"{_pp(a[1], names, ctx, 5)} != {_pp(a[2], names, ctx, 5)}", 4)
            if pb.kind(inner) == "app" and pb.kind(pb.head(inner)) == "const" and pb.const_name(pb.head(inner)) == "Membership.mem" and len(pb.args(inner)) == 5:
                a = pb.args(inner)
                return wrap(f"{_pp(a[4], names, ctx, 5)} not in {_pp(a[3], names, ctx, 5)}", 4)
            return wrap(f"not {_pp(inner, names, ctx, 5)}", 5)
        if n == "And" and len(args) == 2:
            return wrap(f"{_pp(args[0], names, ctx, 3)} and {_pp(args[1], names, ctx, 2)}", 2)
        if n == "Or" and len(args) == 2:
            return wrap(f"{_pp(args[0], names, ctx, 2)} or {_pp(args[1], names, ctx, 1)}", 1)
        if n == "Iff" and len(args) == 2:
            return wrap(f"{_pp(args[0], names, ctx, 1)} <-> {_pp(args[1], names, ctx, 1)}", 0)
        if n == "Exists" and len(args) == 2 and pb.kind(args[1]) == "lam":
            lam = args[1]
            nm = pb.binder_name(lam) or "x"
            return f"exists({nm}, {_pp(pb.binder_body(lam), names, ctx + [nm], 0)})"
        if n in ("Nat.cast", "NatCast.natCast", "Int.cast", "IntCast.intCast", "Rat.cast", "RatCast.ratCast") and args:
            return _pp(args[-1], names, ctx, prec)
        if n == "Neg.neg" and len(args) == 3:
            return wrap(f"-{_pp(args[2], names, ctx, 8)}", 8)
        if n.startswith("Pyra.Def."):
            parts = n.split(".")
            fname = parts[-2]
            return f"{fname}({', '.join(_pp(a, names, ctx, 0) for a in args)})"
        if n == "HasDerivAt" and len(args) >= 3:
            return f"has_deriv_at({_pp(args[-3], names, ctx, 0)}, {_pp(args[-2], names, ctx, 0)}, {_pp(args[-1], names, ctx, 0)})"
        if n == "deriv" and len(args) >= 2:
            return f"deriv({_pp(args[-2], names, ctx, 0)}, {_pp(args[-1], names, ctx, 0)})"
        if n == "abs" and len(args) == 4:
            return f"abs({_pp(args[3], names, ctx, 0)})"
        if n == "Dvd.dvd" and len(args) == 4:
            return f"divides({_pp(args[2], names, ctx, 0)}, {_pp(args[3], names, ctx, 0)})"
        if n == "Membership.mem" and len(args) == 5:
            return wrap(f"{_pp(args[4], names, ctx, 5)} in {_pp(args[3], names, ctx, 5)}", 4)
        if n == "Finset.card" and len(args) == 2:
            return f"len({_pp(args[1], names, ctx, 0)})"
        if n in ("Finset.Icc", "Finset.Ico", "Finset.Ioc", "Finset.Ioo") and len(args) == 5:
            return f"{n[7:]}({_pp(args[3], names, ctx, 0)}, {_pp(args[4], names, ctx, 0)})"
        if n == "Finset.filter" and len(args) == 4 and pb.kind(args[1]) == "lam":
            lam = args[1]
            nm = pb.binder_name(lam) or "x"
            return f"{{{nm} for {nm} in {_pp(args[3], names, ctx, 0)} if {_pp(pb.binder_body(lam), names, ctx + [nm], 0)}}}"
        if n in ("Finset.sum", "Finset.prod") and len(args) == 5:
            s, f = args[3], args[4]
            fn = "sum" if n == "Finset.sum" else "prod"
            if not (pb.kind(s) == "app" and pb.kind(pb.head(s)) == "const" and pb.const_name(pb.head(s)) == "Finset.range") and pb.kind(f) == "lam":
                nm = pb.binder_name(f) or "i"
                body = pb.binder_body(f)
                src = _pp(s, names, ctx, 0)
                if pb.kind(body) == "bvar" and pb.bvar_index(body) == 0:
                    return f"{fn}({src})"
                return f"{fn}({_pp(body, names, ctx + [nm], 0)} for {nm} in {src})"
            if pb.kind(s) == "app" and pb.kind(pb.head(s)) == "const" and pb.const_name(pb.head(s)) == "Finset.range":
                bound = _pp(pb.args(s)[-1], names, ctx, 0)
                if pb.kind(f) == "lam":
                    nm = pb.binder_name(f) or "i"
                    body = pb.binder_body(f)
                    if pb.kind(body) == "bvar" and pb.bvar_index(body) == 0:
                        return f"{fn}(range({bound}))"
                    return f"{fn}({_pp(body, names, ctx + [nm], 0)} for {nm} in range({bound}))"
                return f"{fn}(map({_pp(f, names, ctx, 0)}, range({bound})))"
        mask = _explicit_mask(n)
        shown = [a for i, a in enumerate(args) if i >= len(mask) or mask[i]]
        fname = lean_to_py(n, predicate=_is_predicate(n))
        return f"{fname}({', '.join(_pp(a, names, ctx, 0) for a in shown)})"
    return wrap(" ".join([_pp(head, names, ctx, 10)] + [_pp(a, names, ctx, 10) for a in args]), 9)


def describe(h: int):
    """(operator, argument handles) for custom solvers."""
    k = pb.kind(h)
    if k != "app":
        return (k, [])
    head = pb.head(h)
    args = pb.args(h)
    if pb.kind(head) != "const":
        return ("apply", args)
    n = pb.const_name(head)
    if n in _INFIX and len(args) == 6:
        return (_INFIX[n][0], args[4:])
    if n in _REL:
        return (_REL[n][0], args[-2:])
    if n in ("And", "Or", "Not", "Iff"):
        return ({"And": "and", "Or": "or", "Not": "not", "Iff": "<->"}[n], args)
    if n == "OfNat.ofNat":
        return ("lit", [])
    mask = _explicit_mask(n)
    return (lean_to_py(n, predicate=_is_predicate(n)), [a for i, a in enumerate(args) if i >= len(mask) or mask[i]])


# --------------------------------------------------------------------------- evaluation
class Unevaluable(Exception):
    pass


def _min_fac(n: int) -> int:
    if n == 1:
        return 1
    if n % 2 == 0:
        return 2
    k = 3
    while k * k <= n:
        if n % k == 0:
            return k
        k += 2
    return n


def _is_prime(n: int) -> bool:
    return n >= 2 and _min_fac(n) == n


def evaluate(h: int, env: dict, ctx=None):
    """Evaluate a closed-up-to-``env`` term to a Python int / Fraction / bool."""
    ctx = ctx or []
    k = pb.kind(h)
    if k == "fvar":
        if h in env:
            return env[h]
        raise Unevaluable(pb.fvar_name(h))
    if k == "bvar":
        i = pb.bvar_index(h)
        if i < len(ctx):
            return ctx[-1 - i]
        raise Unevaluable("bvar")
    if k == "nat":
        return pb.nat_value(h)
    if k == "const":
        n = pb.const_name(h)
        if n == "True":
            return True
        if n == "False":
            return False
        raise Unevaluable(n)
    if k == "pi":
        body = pb.binder_body(h)
        if pb.loose_bvar_range(body) == 0:
            return (not evaluate(pb.binder_type(h), env, ctx)) or evaluate(body, env, ctx + [None])
        raise Unevaluable("forall")
    if k != "app":
        raise Unevaluable(k)
    v = _lit_of(h)
    if v is not None:
        return v
    head, args = pb.head(h), pb.args(h)
    if pb.kind(head) != "const":
        raise Unevaluable("application")
    n = pb.const_name(head)
    ev = lambda x: evaluate(x, env, ctx)
    def num_type(t):
        return pb.const_name(t) if pb.kind(t) == "const" else ""
    if n in _INFIX and len(args) == 6:
        a, b = ev(args[4]), ev(args[5])
        T = num_type(args[0])
        if n == "HAdd.hAdd":
            return a + b
        if n == "HSub.hSub":
            return max(a - b, 0) if T == "Nat" else a - b
        if n == "HMul.hMul":
            return a * b
        if n == "HDiv.hDiv":
            if T == "Int":       # Lean's Int division is Euclidean (the remainder is nonnegative)
                if b == 0:
                    return 0
                q = a // abs(b)
                return q if b > 0 else -q
            if T == "Nat":
                return 0 if b == 0 else a // b
            return Fraction(0) if b == 0 else Fraction(a) / Fraction(b)
        if n == "HMod.hMod":
            if T == "Int":
                return a if b == 0 else a % abs(b)
            return a if b == 0 else a % b
        if n == "HPow.hPow":
            if b > 10000:
                raise Unevaluable("huge power")
            return a ** b
    if n in _REL:
        a, b = ev(args[-2]), ev(args[-1])
        return {"Eq": a == b, "Ne": a != b, "LT.lt": a < b, "LE.le": a <= b, "GT.gt": a > b, "GE.ge": a >= b}[n]
    if n == "And":
        return bool(ev(args[0])) and bool(ev(args[1]))
    if n == "Or":
        return bool(ev(args[0])) or bool(ev(args[1]))
    if n == "Not":
        return not ev(args[0])
    if n == "Iff":
        return bool(ev(args[0])) == bool(ev(args[1]))
    if n in ("Nat.cast", "NatCast.natCast", "Int.cast", "IntCast.intCast", "Rat.cast", "RatCast.ratCast"):
        return ev(args[-1])
    if n == "Neg.neg":
        return -ev(args[-1])
    if n == "abs" and len(args) == 4:
        return abs(ev(args[3]))
    if n == "Nat.succ":
        return ev(args[0]) + 1
    if n == "Nat.factorial":
        x = ev(args[0])
        if x > 3000:
            raise Unevaluable("factorial too large")
        return math.factorial(x)
    if n == "Nat.minFac":
        x = ev(args[0])
        return 2 if x == 0 else _min_fac(x)
    if n == "Nat.Prime":
        return _is_prime(ev(args[0]))
    if n == "Dvd.dvd" and len(args) == 4:
        a, b = ev(args[2]), ev(args[3])
        return b == 0 if a == 0 else b % a == 0
    if n == "Nat.gcd":
        return math.gcd(ev(args[0]), ev(args[1]))
    if n in ("Min.min", "Max.max") and len(args) >= 2:
        a, b = ev(args[-2]), ev(args[-1])
        return min(a, b) if n == "Min.min" else max(a, b)
    if n in ("Finset.sum", "Finset.prod") and len(args) == 5:
        s, f = args[3], args[4]
        if pb.kind(s) == "app" and pb.const_name(pb.head(s)) == "Finset.range" and pb.kind(f) == "lam":
            bound = ev(pb.args(s)[-1])
            if bound > 100000:
                raise Unevaluable("range too large")
            body = pb.binder_body(f)
            vals = [evaluate(body, env, ctx + [i]) for i in range(bound)]
            return sum(vals) if n == "Finset.sum" else math.prod(vals)
    if n == "ite" and len(args) == 5:
        return ev(args[3]) if ev(args[1]) else ev(args[4])
    raise Unevaluable(n)
