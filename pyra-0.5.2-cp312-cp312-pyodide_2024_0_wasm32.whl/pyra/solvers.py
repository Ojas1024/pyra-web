"""Features 5 and 7: Python solvers and neuro-symbolic hooks.

A solver is an ordinary Python function.  It receives a :class:`Goal`
(the current target plus the hypotheses in scope) and returns candidate
steps:

* a string with a Python expression, e.g. ``"p >= 2"`` — an intermediate
  ``assert`` that Pyra proves and then adds to the hypotheses;
* a :class:`~pyra.terms.Term` proposition (same meaning);
* ``pyra.use("Nat.minFac_prime")`` — a library lemma to try first.

No monads, no tactic language: inspect ``goal.hyps``, ``goal.target.op``,
``goal.target.args`` with plain Python, call any library you like
(``import torch`` inside a ``@pyra.solver`` works like anywhere else).
Whatever a solver suggests is still checked by the kernel.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .terms import Term, TermLike, pretty

_REGISTRY: list = []


@dataclass(frozen=True)
class Use:
    """A hint naming a library lemma (Lean name or Pyra name)."""
    lemma: str


def use(lemma: str) -> Use:
    return Use(lemma)


@dataclass
class SolverSpec:
    fn: object
    name: str
    priority: int = 0


def solver(fn=None, *, name: str | None = None, priority: int = 0):
    """Register a global solver (``@pyra.solver``).  The function is returned unchanged."""
    def deco(f):
        _REGISTRY.append(SolverSpec(f, name or getattr(f, "__name__", "solver"), priority))
        _REGISTRY.sort(key=lambda s: -s.priority)
        f.__pyra_solver__ = True
        return f
    return deco(fn) if fn is not None else deco


def registered():
    return list(_REGISTRY)


def unregister(fn) -> None:
    _REGISTRY[:] = [s for s in _REGISTRY if s.fn is not fn]


@dataclass
class Hypothesis:
    name: str
    prop: Term
    line: int | None = None

    @property
    def text(self) -> str:
        return self.prop.text

    def __repr__(self):
        return f"{self.name}: {self.text}"


@dataclass
class Goal:
    """What a solver sees."""
    target: Term
    hyps: list
    vars: dict
    line: int | None = None
    function: str = ""
    names: dict = field(default_factory=dict)

    @property
    def text(self) -> str:
        return pretty(self.target.h, self.names)

    def __repr__(self):
        hs = "\n".join(f"  {h.name}: {pretty(h.prop.h, self.names)}" for h in self.hyps)
        return f"Goal(line {self.line}):\n{hs}\n  ⊢ {self.text}"


def run(spec_fn, goal: Goal):
    """Call a solver and normalise its suggestions into a list."""
    out = spec_fn(goal)
    if out is None:
        return []
    if isinstance(out, (str, TermLike, Use)):
        return [out]
    return list(out)


# --------------------------------------------------------------------------- SymPy (sketch mode)
def sympy_check(goal_h: int) -> bool:
    """Sketch-mode check: does SymPy simplify lhs - rhs of an equation to 0?"""
    import sympy
    from . import pyra_bind as pb
    syms = {}

    def tr(h):
        k = pb.kind(h)
        if k == "fvar":
            return syms.setdefault(h, sympy.Symbol(pb.fvar_name(h)))
        if k == "nat":
            return sympy.Integer(pb.nat_value(h))
        if k == "app" and pb.kind(pb.head(h)) == "const":
            n = pb.const_name(pb.head(h))
            a = pb.args(h)
            if n == "OfNat.ofNat" and len(a) == 3:
                return tr(a[1])
            ops = {"HAdd.hAdd": lambda x, y: x + y, "HMul.hMul": lambda x, y: x * y,
                   "HDiv.hDiv": lambda x, y: x / y, "HPow.hPow": lambda x, y: x ** y}
            if n in ops and len(a) == 6:
                return ops[n](tr(a[4]), tr(a[5]))
            if n == "HSub.hSub" and len(a) == 6 and pb.kind(a[0]) == "const" and pb.const_name(a[0]) != "Nat":
                return tr(a[4]) - tr(a[5])
            if n == "Neg.neg" and len(a) == 3:
                return -tr(a[2])
            if n in ("Nat.cast", "NatCast.natCast", "Int.cast", "IntCast.intCast"):
                return tr(a[-1])
            if n == "Real.sqrt" and len(a) == 1:
                return sympy.sqrt(tr(a[0]))
            if n in ("Real.sin", "Real.cos", "Real.exp", "Real.log") and len(a) == 1:
                return getattr(sympy, n.split(".")[1])(tr(a[0]))
        raise ValueError("untranslatable")

    from . import pyra_bind as pb
    if pb.kind(goal_h) != "app" or pb.kind(pb.head(goal_h)) != "const" or pb.const_name(pb.head(goal_h)) != "Eq":
        return False
    a = pb.args(goal_h)
    try:
        return sympy.simplify(tr(a[1]) - tr(a[2])) == 0
    except Exception:
        return False
