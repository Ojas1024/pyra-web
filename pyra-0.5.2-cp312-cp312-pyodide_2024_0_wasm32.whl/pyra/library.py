"""Importing more of Lean/Mathlib into a running Pyra session.

The bundled library covers the number types and the lemmas Pyra's examples use.
``require`` brings in anything else straight from the ``.olean`` files of the
configured Mathlib (``python -m pyra where``): single declarations, or whole
modules.  Only what the requested declarations depend on is imported, and every
imported declaration is re-checked by the kernel (with the verified-import cache).

    import pyra
    pyra.require("Real.sqrt", modules=["Mathlib.Analysis.SpecialFunctions.Pow.Real"])
    from pyra.lean import Real
    Real.sqrt(2)
"""
from __future__ import annotations

import os
import threading
from pathlib import Path

from . import lean_bridge
from . import pyra_bind as pb
from .kernel import CACHE_DIR, elab, kernel

_lock = threading.RLock()
_ix = None
_extra_paths: list = []
_loaded_modules: set = set()


def add_search_path(path) -> None:
    """Also look for .olean files under `path` (e.g. a directory of compiled statements)."""
    global _ix
    with _lock:
        p = str(Path(path).resolve())
        if p not in _extra_paths:
            _extra_paths.append(p)
            _ix = None


def olean_index() -> pb.OleanIndex:
    global _ix
    with _lock:
        if _ix is None:
            _ix = lean_bridge.index(list(lean_bridge.require_search_path(mathlib=True)) + _extra_paths)
        return _ix


def module_roots(module: str) -> list:
    ix = olean_index()
    ix.add_module(module)
    return [n for n, _kind, unsafe in ix.module_decl_kinds(module) if not unsafe and not lean_bridge._internal(n)]


def require(*names: str, modules=(), search=(), threads: int = 0) -> dict:
    """Import declarations `names` and/or every public declaration of `modules` (with their dependencies).
    `search`: modules to look `names` up in without importing the rest of them, e.g.
    ``require("Real.sqrt_eq_iff_mul_self_eq_of_pos", search=["Mathlib.Analysis.Real.Sqrt"])``."""
    with _lock:
        ix = olean_index()
        for m in search:
            ix.add_module(m)
        roots = list(names)
        for m in modules:
            roots += module_roots(m)
            _loaded_modules.add(m)
        k = kernel()
        roots = [r for r in roots if not k.has(r)]
        if not roots:
            return {"declarations": 0}
        cache = "" if os.environ.get("PYRA_NO_CACHE") else str(CACHE_DIR)
        try:
            stats = ix.load(k, roots, cache, threads)
        except pb.KernelError as e:
            if "not declared in the indexed modules" not in str(e) or "Mathlib" in _loaded_modules:
                raise
            ix.add_module("Mathlib")            # a bare name: look for it anywhere in Mathlib
            _loaded_modules.add("Mathlib")
            stats = ix.load(k, roots, cache, threads)
        if stats.get("failed"):
            raise RuntimeError(f"pyra.require: {stats['failed']} declaration(s) failed to check: {stats['errors'][:3]}")
        # instances of every module now indexed, then a fresh premise index
        elab().set_instances(lean_bridge.instances_from_olean(ix))
        elab().reindex()
        return stats


def require_statement_module(directory, module: str, theorem: str) -> int:
    """Import theorem `theorem` from the compiled module `module` found under `directory`; returns its type."""
    add_search_path(directory)
    ix = olean_index()
    ix.add_module(module)
    require(theorem)
    return kernel().const_type(theorem)
