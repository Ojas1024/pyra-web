"""Feature 11 — interactive visual proof graphs.

``thm.graph()`` turns a verified theorem into a DAG: the theorem, its steps
(asserts, branches, induction hypotheses, certified facts), the steps each one
uses, the Mathlib / Lean lemmas in its kernel proof, and the axioms those rest
on.  It renders as a self-contained interactive page (SVG + inline JavaScript,
no network access) in Jupyter and VS Code notebooks (``_repr_html_``), can be
saved with ``to_html()``, and exports to JSON, Graphviz DOT and networkx.
Clicking a step shows its statement, how it was discharged, and the Mathlib
lemmas and axioms it depends on.
"""
from __future__ import annotations

import html
import json
from dataclasses import dataclass, field

from . import pyra_bind as pb
from .kernel import kernel
from .terms import pretty

_COLORS = {"Kernel-Verified": "#2e9d48", "SMT-Trusted": "#d2a400", "Unproved": "#d1342f"}
_INTERNAL = ("Pyra.Cert.", "Pyra.Oracle.", "Pyra.Spec.", "Pyra.Tpl.", "Pyra.Def.", "Pyra.User.")


@dataclass
class Node:
    id: str
    kind: str                       # theorem | step | lemma | axiom
    label: str
    detail: dict = field(default_factory=dict)


@dataclass
class ProofGraph:
    theorem: str
    nodes: list
    edges: list                      # (source id, target id, kind)

    # ------------------------------------------------------------ queries
    def node(self, nid):
        return next(n for n in self.nodes if n.id == nid)

    def successors(self, nid, kind=None):
        return [t for s, t, k in self.edges if s == nid and (kind is None or k == kind)]

    def step_nodes(self):
        return [n for n in self.nodes if n.kind == "step"]

    # ------------------------------------------------------------ exports
    def to_dict(self):
        return {"theorem": self.theorem,
                "nodes": [{"id": n.id, "kind": n.kind, "label": n.label, "detail": n.detail} for n in self.nodes],
                "edges": [{"source": s, "target": t, "kind": k} for s, t, k in self.edges]}

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    def to_dot(self) -> str:
        shape = {"theorem": "doubleoctagon", "step": "box", "lemma": "ellipse", "axiom": "diamond"}
        out = [f'digraph "{self.theorem}" {{', "  rankdir=TB;"]
        for n in self.nodes:
            color = _COLORS.get(n.detail.get("badge"), "#555555")
            label = n.label.replace('"', '\\"')
            out.append(f'  "{n.id}" [label="{label}", shape={shape[n.kind]}, color="{color}"];')
        for s, t, k in self.edges:
            out.append(f'  "{s}" -> "{t}" [label="{k}"];')
        out.append("}")
        return "\n".join(out)

    def to_networkx(self):
        import networkx as nx
        g = nx.DiGraph(theorem=self.theorem)
        for n in self.nodes:
            g.add_node(n.id, kind=n.kind, label=n.label, **{k: v for k, v in n.detail.items() if isinstance(v, (str, int, float, bool)) and k not in ("kind", "label")})
        for s, t, k in self.edges:
            g.add_edge(s, t, kind=k)
        return g

    def _layout(self):
        layers = {"theorem": 0, "step": 1, "lemma": 2, "axiom": 3}
        rows = {}
        for n in self.nodes:
            rows.setdefault(layers[n.kind], []).append(n)
        pos, width = {}, 0
        for r, ns in rows.items():
            for i, n in enumerate(ns):
                pos[n.id] = (90 + 190 * i, 60 + 150 * r)
            width = max(width, 190 * len(ns) + 60)
        return pos, max(width, 400), 60 + 150 * (max(rows) + 1)

    def to_html(self, path=None, standalone: bool = True) -> str:
        pos, w, h = self._layout()
        uid = "pyra" + format(abs(hash(self.theorem)) % 10 ** 8, "d")
        parts = [f'<div id="{uid}" style="font-family:system-ui,sans-serif;display:flex;gap:12px;flex-wrap:wrap">',
                 f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" style="border:1px solid #ccc;border-radius:6px;background:#fff">',
                 '<defs><marker id="arr" markerWidth="8" markerHeight="8" refX="8" refY="4" orient="auto">'
                 '<path d="M0,0 L8,4 L0,8 z" fill="#999"/></marker></defs>']
        for s, t, k in self.edges:
            (x1, y1), (x2, y2) = pos[s], pos[t]
            parts.append(f'<line x1="{x1}" y1="{y1 + 18}" x2="{x2}" y2="{y2 - 18}" stroke="#bbb" marker-end="url(#arr)"/>')
        for n in self.nodes:
            x, y = pos[n.id]
            color = _COLORS.get(n.detail.get("badge"), {"lemma": "#4466aa", "axiom": "#7a4b9c", "theorem": "#222"}.get(n.kind, "#555"))
            label = html.escape(n.label if len(n.label) <= 26 else n.label[:25] + "…")
            parts.append(f'<g class="pyra-node" data-id="{html.escape(n.id)}" style="cursor:pointer">'
                         f'<rect x="{x - 85}" y="{y - 18}" width="170" height="36" rx="8" fill="{color}" opacity="0.9"/>'
                         f'<text x="{x}" y="{y + 4}" text-anchor="middle" font-size="11" fill="#fff">{label}</text></g>')
        parts.append("</svg>")
        parts.append(f'<div class="pyra-panel" style="min-width:280px;max-width:420px;font-size:13px">'
                     f'<b>{html.escape(self.theorem)}</b><p>Click a node to see what it depends on.</p></div></div>')
        data = json.dumps(self.to_dict(), ensure_ascii=False).replace("</", "<\\/")
        parts.append("<script>(function(){var g=" + data + ";var root=document.getElementById('" + uid + "');"
                     "var panel=root.querySelector('.pyra-panel');function esc(s){return String(s).replace(/[&<>]/g,function(c){"
                     "return{'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}"
                     "function show(id){var n=g.nodes.find(function(x){return x.id===id;});var d=n.detail||{};"
                     "var h='<b>'+esc(n.label)+'</b><br><i>'+n.kind+'</i>';"
                     "if(d.statement)h+='<pre style=\"white-space:pre-wrap\">'+esc(d.statement)+'</pre>';"
                     "if(d.badge)h+='<div>'+esc(d.badge)+(d.stage?' — '+esc(d.stage):'')+'</div>';"
                     "if(d.lemmas&&d.lemmas.length)h+='<div><b>Mathlib/Lean lemmas</b><ul>'+d.lemmas.map(function(l){return '<li>'+esc(l)+'</li>';}).join('')+'</ul></div>';"
                     "if(d.axioms)h+='<div><b>Axioms</b><ul>'+(d.axioms.length?d.axioms.map(function(l){return '<li>'+esc(l)+'</li>';}).join(''):'<li>none</li>')+'</ul></div>';"
                     "if(d.uses&&d.uses.length)h+='<div><b>Uses steps</b>: '+d.uses.map(esc).join(', ')+'</div>';"
                     "panel.innerHTML=h;}"
                     "root.querySelectorAll('.pyra-node').forEach(function(el){el.addEventListener('click',function(){show(el.getAttribute('data-id'));});});"
                     "})();</script>")
        body = "\n".join(parts)
        page = body if not standalone else (
            "<!doctype html><html><head><meta charset='utf-8'><title>" + html.escape(self.theorem) + "</title></head><body>" + body + "</body></html>")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(page)
        return page

    def _repr_html_(self):
        return self.to_html(standalone=False)


# ---------------------------------------------------------------- construction
_axiom_cache = {}


def _axioms(name: str) -> list:
    if name not in _axiom_cache:
        try:
            ax, orc = kernel().axioms_of(name)
            _axiom_cache[name] = sorted(ax) + sorted(orc)
        except Exception:
            _axiom_cache[name] = []
    return _axiom_cache[name]


def _is_library_lemma(c: str) -> bool:
    if c.startswith(_INTERNAL):
        return False
    info = kernel().find(c)
    return info is not None and info["kind"] == "thm"


def build(thm) -> ProofGraph:
    k = kernel()
    names = thm._names
    tid = "theorem"
    nodes = [Node(tid, "theorem", thm.__name__, {"statement": thm.text, "verified": thm.verified,
                                                   "axioms": sorted(set(thm.theorem.axioms)) + sorted(set(thm.theorem.oracles))})]
    edges = []
    by_fvar = {}
    steps = [s for s in thm.steps if s.proof is not None or s.fvar is not None]
    for i, s in enumerate(steps):
        sid = f"step{i}:L{s.line}"
        s._gid = sid
        if s.fvar is not None:
            by_fvar[s.fvar] = sid
    lemma_nodes, axiom_nodes = {}, {}
    for s in steps:
        uses, lemmas, certs, axioms = [], [], [], set()
        if s.proof is not None:
            for fv in pb.free_vars(s.proof):
                if fv in by_fvar and by_fvar[fv] != s._gid:
                    uses.append(by_fvar[fv])
            for c in pb.constants(s.proof):
                if _is_library_lemma(c):
                    lemmas.append(c)
                elif c.startswith("Pyra.Cert."):
                    certs.append(c)
                if c.startswith("Pyra.Oracle."):
                    axioms.add(c)
            for c in lemmas + certs:
                axioms.update(_axioms(c))
        detail = {"statement": s.text or s.source, "source": s.source, "line": s.line, "badge": s.badge, "stage": s.stage,
                  "lemmas": sorted(lemmas), "certificates": sorted(certs), "axioms": sorted(axioms),
                  "uses": [u.split(":")[1] for u in uses]}
        label = f"L{s.line}: {s.text or s.source}"
        nodes.append(Node(s._gid, "step", label, detail))
        edges.append((tid, s._gid, "proof step"))
        for u in uses:
            edges.append((s._gid, u, "uses"))
        for l in lemmas:
            if l not in lemma_nodes:
                info = k.find(l)
                lemma_nodes[l] = Node(f"lemma:{l}", "lemma", l, {"statement": pretty(info["type"], names), "axioms": _axioms(l),
                                                                   "lemmas": [], "origin": "Mathlib/Lean lemma"})
                for a in _axioms(l):
                    if a not in axiom_nodes:
                        axiom_nodes[a] = Node(f"axiom:{a}", "axiom", a, {"statement": pretty(k.const_type(a)) if k.has(a) else a})
                    edges.append((f"lemma:{l}", f"axiom:{a}", "axiom"))
            edges.append((s._gid, f"lemma:{l}", "lemma"))
    nodes += list(lemma_nodes.values()) + list(axiom_nodes.values())
    return ProofGraph(thm.__name__, nodes, edges)
