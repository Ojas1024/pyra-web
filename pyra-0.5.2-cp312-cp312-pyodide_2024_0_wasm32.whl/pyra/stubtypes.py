"""Type aliases used by the generated ``.pyi`` stubs (and usable in user code)."""
from __future__ import annotations

from fractions import Fraction
from typing import Union

from .terms import Lit, Term

NatLike = Union[Term, Lit, int]
IntLike = Union[Term, Lit, int]
RealLike = Union[Term, Lit, int, float, Fraction]
Prop = Term
Proof = Term
