"""The process-wide Pyra kernel, loaded with the bundled Lean core + Mathlib export."""
from __future__ import annotations

import os
import threading
from pathlib import Path

from . import pyra_bind as pb

_HERE = Path(__file__).resolve().parent
BUNDLE = Path(os.environ.get("PYRA_BUNDLE", _HERE / "data" / "pyra_bundle.ndjson.gz"))
INSTANCES = Path(os.environ.get("PYRA_INSTANCES", _HERE / "data" / "instances.tsv"))
MANIFEST = Path(os.environ.get("PYRA_MANIFEST", _HERE / "data" / "manifest.jsonl"))
CACHE_DIR = Path(os.environ.get("PYRA_CACHE_DIR", Path.home() / ".cache" / "pyra" / "verified"))

_lock = threading.RLock()
_kernel = None
_elab = None
_load_stats = None


def kernel() -> pb.Kernel:
    """The shared kernel.  The first call imports (and, unless cached, re-checks) the bundle."""
    global _kernel, _elab, _load_stats
    with _lock:
        if _kernel is None:
            k = pb.Kernel()
            cache = "" if os.environ.get("PYRA_NO_CACHE") else str(CACHE_DIR)
            if cache:
                CACHE_DIR.mkdir(parents=True, exist_ok=True)
            if source() == "olean":
                from .lean_bridge import load_kernel_from_olean
                stats = load_kernel_from_olean(k, cache_dir=cache)
            else:
                stats = k.load_ndjson(str(BUNDLE), cache)
                stats["source"] = "bundle"
            if stats["failed"]:
                raise RuntimeError("Pyra: the bundled library failed to check: %s" % stats["errors"][:3])
            _load_stats = stats
            _kernel = k
            _elab = pb.Elaborator(k)
            insts = stats.pop("instances", None)
            if insts is None and INSTANCES.exists():
                insts = []
                for line in INSTANCES.read_text(encoding="utf-8").splitlines():
                    n, _, prio = line.partition("\t")
                    if n:
                        insts.append((n, int(prio or 1000)))
            if insts:
                _elab.set_instances(insts)
        return _kernel


def source() -> str:
    """Where the library comes from: 'bundle' (lean4export NDJSON, default) or 'olean' (PYRA_SOURCE=olean)."""
    return os.environ.get("PYRA_SOURCE", "bundle")


def elab() -> pb.Elaborator:
    kernel()
    return _elab


def load_stats() -> dict:
    kernel()
    return _load_stats
