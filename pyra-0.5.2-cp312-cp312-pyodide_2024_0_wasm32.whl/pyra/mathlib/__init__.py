"""Mathlib 4 for Python: ``from pyra.mathlib.data.nat.prime import is_prime, min_fac``.

Submodules are created on import from the bundle manifest: the Python module
``pyra.mathlib.data.nat.prime`` collects the declarations of the Lean modules
``Mathlib.Data.Nat.Prime`` and ``Mathlib.Data.Nat.Prime.*``, exposed under
snake_case names (see :mod:`pyra.naming`).  Every declaration was re-checked by
the Pyra kernel when the bundle was loaded.
"""
from __future__ import annotations

import importlib.abc
import importlib.machinery
import json
import sys
import types
from functools import lru_cache

from ..kernel import MANIFEST, kernel
from ..naming import lean_to_py, module_to_py


@lru_cache(maxsize=None)
def manifest():
    from ..kernel import load_stats, source
    if source() == "olean":
        # built from the .olean files themselves (declarations and docstrings)
        from ..lean_bridge import manifest_from_olean
        return manifest_from_olean(load_stats()["index"])
    entries = []
    with open(MANIFEST, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                entries.append(json.loads(line))
    return entries


@lru_cache(maxsize=None)
def _predicates():
    from ..terms import _is_predicate
    return _is_predicate


def py_modules():
    """All Python module paths that exist (including parent packages)."""
    mods = set()
    for e in manifest():
        p = module_to_py(e["module"])
        parts = p.split(".")
        for i in range(2, len(parts) + 1):
            mods.add(".".join(parts[:i]))
    return mods


def declarations_for(pymod: str):
    """(python name -> entry) for a Python module path."""
    out = {}
    exact = {}
    k = kernel()
    is_pred = _predicates()
    namespace_hint = pymod.split(".")[-2] if pymod.count(".") >= 3 else ""
    for e in manifest():
        p = module_to_py(e["module"])
        if p != pymod and not p.startswith(pymod + "."):
            continue
        name = e["name"]
        if not k.has(name):
            continue
        pred = e["kind"] == "def" and is_pred(name)
        py = lean_to_py(name, predicate=pred)
        ns = name.rsplit(".", 1)[0].lower() if "." in name else ""
        score = (p == pymod) * 2 + (ns.endswith(namespace_hint) if namespace_hint else 0)
        if py not in out or score > exact[py]:
            out[py] = e
            exact[py] = score
    return out


class _Finder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, fullname, path=None, target=None):
        if not fullname.startswith("pyra.mathlib.") and not fullname.startswith("pyra.lean."):
            return None
        if fullname not in py_modules():
            return None
        return importlib.machinery.ModuleSpec(fullname, self, is_package=True)

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        from ..terms import LeanConst
        module.__path__ = []
        module.__lean_modules__ = sorted({e["module"] for e in manifest()
                                          if module_to_py(e["module"]) == module.__name__ or module_to_py(e["module"]).startswith(module.__name__ + ".")})
        decls = declarations_for(module.__name__)
        for py, e in decls.items():
            setattr(module, py, LeanConst(e["name"], e["kind"], e.get("doc", ""), py))
        module.__all__ = sorted(decls)
        module.lean = lambda name: LeanConst(name, kernel().find(name)["kind"])


_finder = _Finder()
if not any(isinstance(f, _Finder) for f in sys.meta_path):
    sys.meta_path.insert(0, _finder)
