"""Pyra — formal verification in plain Python.

    from pyra import prove, Nat, Real, exists

    @prove
    def sum_formula(n: Nat):
        if n == 0:
            assert sum(range(1)) == 0
        else:
            sum_formula(n - 1)        # recursive call = induction hypothesis
            assert 2 * sum(range(n + 1)) == n * (n + 1)

Layers: ``pyra.ast`` (Python AST frontend) → ``pyra_bind`` (nanobind handles) →
``pyra_elab`` (waterfall) → ``pyra_lean_bridge`` (Mathlib importer) →
``pyra_core`` (the trusted kernel; the only code that can mint a Theorem).
"""
from . import pyra_bind
from .pyra_bind import KernelError, Theorem
from .terms import Sort
from .terms import Nat, Int, Rat, Real, Complex, Fun, Fact, Term, PyraError, ElaborationError, exists, forall, implies, iff, divides, sin, cos, exp, inv
from .runtime import ProofError, assume, obtain, config, KERNEL_VERIFIED, SMT_TRUSTED, UNPROVED
from .solvers import solver, use, Goal
from .debug import inspect
from .ast import prove, ProvedTheorem, HealReport
from .definitions import define, Definition
from .extract import extract
from .kernel import kernel, elab
from . import algebra
from . import algebra as sympy          # pyra.sympy.factor / expand / diff (Feature 4)
from .algebra import has_deriv_at, deriv
from .library import require
from .structures import structure, lean_type, const, typed, set_of, subtype   # Fun, inv: pyra.terms (numbers + generic)
from .finset import Finset, Icc, Ico, Ioc, Ioo, is_least, is_greatest
from .finset import Set as _NumberSet
from .structures import Set as _TypeSet


class _SetFamily:
    """``Set[Nat]`` (sets of numbers: membership, difference, is_least, ...) or ``Set[X]`` for any type."""
    def __getitem__(self, elem):
        return _NumberSet[elem] if isinstance(elem, Sort) else _TypeSet[elem]


Set = _SetFamily()

from . import mathlib  # installs the pyra.mathlib import hook

__all__ = ["prove", "assume", "obtain", "Nat", "Int", "Rat", "Real", "Complex", "I", "Fun", "Fact", "exists", "forall", "implies", "iff", "divides", "inspect", "solver", "use",
           "Goal", "Term", "Theorem", "ProvedTheorem", "ProofError", "PyraError", "ElaborationError", "sin", "cos", "exp", "KernelError", "config", "kernel", "elab",
           "KERNEL_VERIFIED", "SMT_TRUSTED", "UNPROVED", "algebra", "sympy", "has_deriv_at", "deriv", "define", "Definition", "HealReport", "extract", "require", "inv",
           "Set", "structure", "lean_type", "const", "typed", "set_of", "subtype", "Finset", "Icc", "Ico", "Ioc", "Ioo", "is_least", "is_greatest"]
def __getattr__(name):
    if name == "I":
        from .terms import imaginary_unit
        return imaginary_unit()
    raise AttributeError(name)


__version__ = "0.1.0"
