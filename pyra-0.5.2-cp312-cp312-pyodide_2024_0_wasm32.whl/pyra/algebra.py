"""Feature 4 — SymPy-to-kernel algebra.

SymPy does the creative work (factoring, expanding, differentiating) in
Python; Pyra then rebuilds a step-by-step certificate that the C++ kernel
checks.  Nothing SymPy says is trusted:

* ``expand(e)``  — ``e = expand(e)``      by polynomial normalisation (reflection)
* ``factor(e)``  — ``e = N = factor(e)``  via the common normal form N (two reflection steps)
* ``diff(f, x)`` — ``HasDerivAt f f' x``  built rule by rule (sum, product, power, ...) and
  closed by showing the rule-built derivative equals SymPy's answer.

Inside a ``@prove`` function each result is added as a Kernel-Verified fact;
outside, ``certificate(...)`` returns the checked certificate.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction

import sympy

from . import pyra_bind as pb
from . import runtime
from .kernel import elab, kernel
from .terms import PyraError, Real, Term, coerce, numeral, pretty, tpl, to_term


class CertificateError(PyraError):
    """SymPy produced a result the kernel could not confirm."""


@dataclass
class Certificate:
    op: str
    statement: int                      # proposition (kernel handle)
    proof: int                          # kernel-checked proof of `statement`
    steps: list = field(default_factory=list)   # (rule, detail)
    value: Term | None = None

    @property
    def text(self) -> str:
        return pretty(self.statement)

    def __repr__(self):
        return f"<Certificate {self.op}: {self.text} ({len(self.steps)} steps)>"


# --------------------------------------------------------------------------- Term <-> SymPy
_SORT_OF = {"Nat": "nat", "Int": "int", "Real": "real"}
# Mathlib's real functions and their SymPy counterparts (evaluate=False: SymPy must not rewrite
# e.g. sin(-t) to -sin(t), which the kernel's chain-rule certificate would not match).
_TRANSCENDENTAL = {"Real.sin": lambda e: sympy.sin(e, evaluate=False), "Real.cos": lambda e: sympy.cos(e, evaluate=False),
                   "Real.exp": lambda e: sympy.exp(e, evaluate=False)}
_FROM_SYMPY_FN = {sympy.sin: "sin", sympy.cos: "cos", sympy.exp: "exp"}


def to_sympy(h: int, symbols: dict, fn_args: dict | None = None):
    """Kernel term -> SymPy expression (symbols: fvar handle -> sympy.Symbol).  `fn_args` collects
    the arguments of sin/cos/exp (SymPy expression -> kernel term) so that they can be mapped back exactly."""
    k = pb.kind(h)
    if k == "fvar":
        if h not in symbols:
            t = elab().infer(h)
            sort = _SORT_OF.get(pb.const_name(t), "real") if pb.kind(t) == "const" else "real"
            symbols[h] = sympy.Symbol(pb.fvar_name(h), real=True, nonnegative=(sort == "nat") or None,
                                      integer=(sort in ("nat", "int")) or None)
        return symbols[h]
    if k == "nat":
        return sympy.Integer(pb.nat_value(h))
    if k == "app" and pb.kind(pb.head(h)) == "const":
        n, a = pb.const_name(pb.head(h)), pb.args(h)
        if n == "OfNat.ofNat" and len(a) == 3:
            return to_sympy(a[1], symbols, fn_args)
        if n in ("Nat.cast", "NatCast.natCast", "Int.cast", "IntCast.intCast"):
            return to_sympy(a[-1], symbols, fn_args)
        ops = {"HAdd.hAdd": lambda x, y: x + y, "HMul.hMul": lambda x, y: x * y, "HSub.hSub": lambda x, y: x - y,
               "HDiv.hDiv": lambda x, y: x / y, "HPow.hPow": lambda x, y: x ** y}
        if n in ops and len(a) == 6:
            if n == "HSub.hSub" and pb.kind(a[0]) == "const" and pb.const_name(a[0]) == "Nat":
                raise CertificateError("truncated ℕ subtraction has no SymPy counterpart")
            if n == "HDiv.hDiv" and pb.kind(a[0]) == "const" and pb.const_name(a[0]) in ("Nat", "Int"):
                raise CertificateError("integer division has no SymPy counterpart")
            return ops[n](to_sympy(a[4], symbols, fn_args), to_sympy(a[5], symbols, fn_args))
        if n == "Neg.neg" and len(a) == 3:
            return -to_sympy(a[2], symbols, fn_args)
        if n in _TRANSCENDENTAL and len(a) == 1:
            sa = to_sympy(a[0], symbols, fn_args)
            if fn_args is not None:
                fn_args.setdefault(sa, a[0])
            return _TRANSCENDENTAL[n](sa)
    raise CertificateError(f"cannot translate {pretty(h)} to SymPy")


def from_sympy(e, sort: str, symbols: dict, fn_args: dict | None = None) -> Term:
    """SymPy expression -> Pyra term of the given sort (inverse of to_sympy).  `fn_args` maps
    (expanded) SymPy arguments of sin/cos/exp back to the kernel terms they came from."""
    inv = {s: Term(h, sort if sort != "nat" else None) for h, s in symbols.items()}

    def go(x) -> Term:
        if x in inv:
            return coerce(inv[x], sort) if inv[x].sort != sort else inv[x]
        if isinstance(x, sympy.Integer):
            v = int(x)
            if v < 0:
                if sort == "nat":
                    raise CertificateError("negative constant in a ℕ expression")
                return Term(tpl(f"{sort}_neg", numeral(-v, sort)), sort)
            return Term(numeral(v, sort), sort)
        if isinstance(x, sympy.Rational):
            if sort != "real":
                raise CertificateError("fraction outside ℝ")
            return Term(numeral(Fraction(int(x.p), int(x.q)), "real"), "real")
        if isinstance(x, sympy.Add):
            pos, neg = [], []
            for t in x.as_ordered_terms():
                c, rest = t.as_coeff_Mul()
                (neg if c < 0 else pos).append(-t if c < 0 else t)
            if sort == "nat" and neg:
                raise CertificateError("subtraction in a ℕ expression")
            r = go(pos[0]) if pos else Term(numeral(0, sort), sort)
            for t in pos[1:]:
                r = r + go(t)
            for t in neg:
                r = r - go(t)
            return r
        if isinstance(x, sympy.Mul):
            c, rest = x.as_coeff_Mul()
            if c == -1 and sort != "nat":
                return -go(rest)
            factors = list(x.as_ordered_factors())
            r = go(factors[0])
            for f in factors[1:]:
                r = r * go(f)
            return r
        if x.func in _FROM_SYMPY_FN and len(x.args) == 1:
            if sort != "real":
                raise CertificateError(f"{x.func.__name__} outside ℝ")
            key = sympy.expand(x.args[0], power_exp=False)
            arg = Term(fn_args[key], "real") if fn_args and key in fn_args else coerce(go(x.args[0]), "real")
            return Term(tpl(f"real_{_FROM_SYMPY_FN[x.func]}", arg.h), "real")
        if isinstance(x, sympy.Pow):
            b, ex = x.as_base_exp()
            if isinstance(ex, sympy.Integer) and int(ex) >= 0:
                return go(b) ** int(ex)
            if isinstance(ex, sympy.Integer) and sort == "real":
                return Term(numeral(1, "real"), "real") / (go(b) ** (-int(ex)))
        raise CertificateError(f"cannot translate SymPy expression {x} back")

    return go(e)


# --------------------------------------------------------------------------- certificates
def _equation(sort: str, a: Term, b: Term) -> int:
    return tpl(f"{sort}_eq", coerce(a, sort).h, coerce(b, sort).h)


def _prove_identity(goal: int) -> int:
    """Kernel proof of a polynomial identity (definitional equality + reflection stages only)."""
    r = elab().prove(goal, [], {"stages": 0b11, "timeout": 20})
    if not r["proved"]:
        raise CertificateError(f"the kernel could not confirm {pretty(goal)}")
    return r["proof"]


def _sort(t: Term) -> str:
    s = t.sort if t.sort != "lit" else t.natural_sort()
    if s not in ("nat", "real"):
        raise CertificateError(f"algebra certificates support ℕ and ℝ terms, not {s}")
    return s


def certificate(op: str, expr, *args) -> Certificate:
    """Run SymPy's `op` ('expand', 'factor', 'diff') and return a kernel-checked certificate."""
    if op == "diff":
        return _diff_certificate(expr, *args)
    t = to_term(expr)
    sort = _sort(t)
    symbols = {}
    se = to_sympy(t.h, symbols)
    k = kernel()
    if op == "expand":
        res = from_sympy(sympy.expand(se), sort, symbols)
        goal = _equation(sort, t, res)
        pf = _prove_identity(goal)
        steps = [("expand", f"{t} = {res}  (polynomial normal form, reflection)")]
    elif op == "factor":
        nf = from_sympy(sympy.expand(se), sort, symbols)
        res = from_sympy(sympy.factor(se), sort, symbols)
        g1, g2 = _equation(sort, t, nf), _equation(sort, nf, res)
        p1, p2 = _prove_identity(g1), _prove_identity(g2)
        trans = "Pyra.Cert.eq_trans" if sort == "nat" else "Pyra.Cert.real_eq_trans"
        goal = _equation(sort, t, res)
        pf = pb.mk_apps(pb.mk_const(trans), [coerce(t, sort).h, nf.h, res.h, p1, p2])
        steps = [("expand", f"{t} = {nf}  (normal form)"), ("factor", f"{nf} = {res}  (normal form of both sides agrees)")]
    else:
        raise PyraError(f"unknown algebra operation {op!r}")
    if not k.is_def_eq(k.check(pf), goal):
        raise CertificateError("internal: certificate does not prove its statement")
    return Certificate(op, goal, pf, steps, res)


def _lambda(fn, name="t"):
    y = pb.mk_fvar(name, Real.handle)
    body = coerce(to_term(fn(Term(y, "real"))), "real")
    return pb.mk_lam_fvars([y], body.h), y, body


def _diff_certificate(fn, x) -> Certificate:
    X = coerce(to_term(x), "real")
    var = fn.__code__.co_varnames[0] if getattr(fn, "__code__", None) and fn.__code__.co_varnames else "t"
    lam, y, body = _lambda(fn, var)
    symbols = {y: sympy.Symbol(var, real=True)}
    fn_args = {}
    sb = to_sympy(body.h, symbols, fn_args)
    sx = to_sympy(X.h, symbols) if pb.kind(X.h) == "fvar" else None
    ys = symbols[y]
    d = sympy.diff(sb, ys)
    point = sx if sx is not None else sympy.Symbol("__pyra_point")
    d_at = d.subs(ys, point)
    if sx is None:
        symbols[X.h] = point
    # arguments of sin/cos/exp at the point, keyed by their expanded SymPy form, map back to the
    # very kernel terms the chain-rule certificate produces (SymPy rewrites e.g. 2*(x+1) to 2*x+2)
    atoms = {}
    for sarg, harg in fn_args.items():
        atoms.setdefault(sympy.expand(sarg.subs(ys, point), power_exp=False), pb.replace_fvars(harg, [y], [X.h]))
    deriv = from_sympy(sympy.expand(d_at, power_exp=False), "real", symbols, atoms)
    pf = elab().has_deriv_proof(lam, X.h, deriv.h)
    if pf is None:
        raise CertificateError(f"no kernel certificate for d/d{var} {pretty(body.h)} = {deriv}")
    goal = tpl("real_has_deriv_at", lam, deriv.h, X.h)
    k = kernel()
    if not k.is_def_eq(k.check(pf), goal):
        raise CertificateError("internal: derivative certificate does not prove its statement")
    rules = {"Pyra.Cert.d_add": "sum rule", "Pyra.Cert.d_sub": "difference rule", "Pyra.Cert.d_mul": "product rule",
             "Pyra.Cert.d_pow": "power rule", "Pyra.Cert.d_neg": "negation rule", "Pyra.Cert.d_div_num": "quotient by a constant",
             "Pyra.Cert.d_const": "constant rule", "Pyra.Cert.d_id": "identity rule", "Pyra.Cert.d_congr": "ring normalisation (reflection)",
             "Pyra.Cert.d_comp": "chain rule", "Pyra.Cert.d_sin_at": "derivative of sin", "Pyra.Cert.d_cos_at": "derivative of cos",
             "Pyra.Cert.d_exp_at": "derivative of exp"}
    used = [rules[c] for c in pb.constants(pf) if c in rules]
    steps = [("diff", f"SymPy: d/d{var} ({sb}) = {d}")] + [("rule", r) for r in used]
    return Certificate("diff", goal, pf, steps, deriv)


# --------------------------------------------------------------------------- user API
def _record(cert: Certificate) -> Term:
    s = runtime.current_session()
    if s is not None:
        s.certified_fact(cert)
    return cert.value


def expand(expr) -> Term:
    """SymPy's expansion, with a kernel certificate ``expr = result`` (a fact inside @prove)."""
    return _record(certificate("expand", expr))


def factor(expr) -> Term:
    """SymPy's factorisation, with a kernel certificate ``expr = result``."""
    return _record(certificate("factor", expr))


def diff(fn, x) -> Term:
    """SymPy's derivative of the real function `fn` at `x`, with a kernel certificate
    ``HasDerivAt fn result x`` (Mathlib's definition)."""
    return _record(certificate("diff", fn, x))


def has_deriv_at(fn, derivative, x) -> Term:
    """The proposition ``HasDerivAt fn derivative x`` (Mathlib)."""
    var = fn.__code__.co_varnames[0] if fn.__code__.co_varnames else "t"
    lam, _, _ = _lambda(fn, var)
    return Term(tpl("real_has_deriv_at", lam, coerce(to_term(derivative), "real").h, coerce(to_term(x), "real").h), "prop")


def deriv(fn, x) -> Term:
    """``deriv fn x`` (Mathlib's derivative, a real number)."""
    var = fn.__code__.co_varnames[0] if fn.__code__.co_varnames else "t"
    lam, _, _ = _lambda(fn, var)
    return Term(tpl("real_deriv", lam, coerce(to_term(x), "real").h), "real")
