"""Layer 4 helpers — reading Lean 4 / Mathlib compiled modules (``.olean``).

The heavy lifting is in C++ (``pyra_bind.OleanIndex``): files are memory
mapped, the compacted Lean object graph is decoded straight into Pyra's
hash-consed arena, and every declaration goes through the kernel before it is
usable (re-checked on first load, then cached by file content hash).
"""
from __future__ import annotations

import glob
import json
import os
import shutil
import subprocess
from pathlib import Path

from . import pyra_bind as pb
from .naming import lean_to_py, module_to_py

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
LEAN_VERSION = "4.33.0"


def bundled_modules() -> list:
    return json.loads((_HERE / "data" / "modules.json").read_text())["modules"]


class LeanSetupError(RuntimeError):
    pass


SETUP_HINT = ("Point Pyra at a Lean 4.33 toolchain and a built Mathlib v4.33.0 project with\n"
              "  PYRA_LEAN_TOOLCHAIN=<toolchain prefix>  (or have `lean` 4.33 on PATH / ELAN_HOME)\n"
              "  PYRA_MATHLIB=<Mathlib project dir>      (a `lake` project depending on mathlib)\n"
              "or PYRA_LEAN_PATH=<dir>:<dir>... directly, or the --lean-toolchain / --mathlib / --lean-path flags.\n"
              "tools/setup_lean.sh installs both into ./third_party; the Dockerfile does everything.")


def toolchain_prefix():
    """Prefix of the Lean 4.33 toolchain: $PYRA_LEAN_TOOLCHAIN, `lean --print-prefix`, $ELAN_HOME, ./third_party, ./.toolchain, ~/.elan."""
    env = os.environ.get("PYRA_LEAN_TOOLCHAIN")
    if env:
        return Path(env)
    lean = shutil.which("lean")
    if lean:
        try:
            out = subprocess.run([lean, "--print-prefix"], capture_output=True, text=True, timeout=60)
            ver = subprocess.run([lean, "--version"], capture_output=True, text=True, timeout=60).stdout
            if out.returncode == 0 and LEAN_VERSION in ver:
                return Path(out.stdout.strip())
        except (OSError, subprocess.SubprocessError):
            pass
    for home in filter(None, [os.environ.get("ELAN_HOME"), str(_ROOT / "third_party" / "elan"),
                              str(_ROOT / ".toolchain" / "elan"), str(Path.home() / ".elan")]):
        found = sorted(glob.glob(os.path.join(home, "toolchains", f"*{LEAN_VERSION}*")))
        if found:
            return Path(found[0])
    return None


def _toolchain_lib() -> list:
    p = toolchain_prefix()
    return [str(p / "lib" / "lean")] if p and (p / "lib" / "lean").is_dir() else []


def mathlib_project():
    """The Mathlib project: $PYRA_MATHLIB, else ./third_party/mathlib (created by tools/setup_lean.sh)."""
    env = os.environ.get("PYRA_MATHLIB")
    if env:
        return Path(env).expanduser()
    p = _ROOT / "third_party" / "mathlib"
    return p if p.is_dir() else None


def default_search_path() -> list:
    """Directories holding .olean files: $PYRA_LEAN_PATH, or the toolchain + the Mathlib project + Pyra's prelude."""
    env = os.environ.get("PYRA_LEAN_PATH")
    if env:
        return [p for p in env.split(os.pathsep) if p]
    path = _toolchain_lib()
    mathlib = mathlib_project()
    if mathlib is not None:
        path += sorted(glob.glob(str(mathlib / ".lake" / "packages" / "*" / ".lake" / "build" / "lib" / "lean")))
        if (mathlib / ".lake" / "build" / "lib" / "lean").is_dir():
            path.append(str(mathlib / ".lake" / "build" / "lib" / "lean"))
    path.append(str(_ROOT / "lean" / "build"))
    return [p for p in path if os.path.isdir(p)]


def require_search_path(mathlib: bool = True) -> list:
    sp = default_search_path()
    if not any(Path(p, "Init.olean").exists() for p in sp):
        raise LeanSetupError("Lean core .olean files not found.\n" + SETUP_HINT)
    if mathlib and not any(Path(p, "Mathlib").is_dir() for p in sp):
        raise LeanSetupError("Mathlib .olean files not found.\n" + SETUP_HINT)
    return sp


def index(search_path=None, modules=None) -> pb.OleanIndex:
    ix = pb.OleanIndex(list(search_path or require_search_path(mathlib=False)))
    for m in modules or []:
        ix.add_module(m)
    return ix


def _internal(name: str) -> bool:
    comps = name.split(".")
    if any(c.startswith("_") for c in comps) or "._" in name:
        return True
    for c in comps:
        if c.startswith(("match_", "proof_")) or c == "eq_def" or (c.startswith("eq_") and c[3:].isdigit()):
            return True
    return False


def manifest_from_olean(ix: pb.OleanIndex, modules=None) -> list:
    """Public declarations (module, name, kind, doc) of `modules`, read from the .olean files."""
    out = []
    for m in modules or bundled_modules():
        docs = dict(ix.docstrings(m))
        for name, kind, unsafe in ix.module_decl_kinds(m):
            if unsafe or _internal(name):
                continue
            out.append({"module": m, "name": name, "kind": kind, "doc": docs.get(name, "")})
    return out


def write_manifest(path, ix=None, modules=None) -> int:
    ix = ix or index()
    entries = manifest_from_olean(ix, modules)
    with open(path, "w", encoding="utf-8") as f:
        for e in entries:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")
    return len(entries)


def instances_from_olean(ix: pb.OleanIndex, modules=None) -> list:
    """Lean's @[instance] declarations [(name, priority)] of `modules` (default: every indexed module),
    in import order (later modules last, as Lean tries the most recent instance first)."""
    out = []
    for m in modules or ix.indexed_modules():
        try:
            out.extend(ix.instances(m))
        except Exception:
            continue
    return out


def write_instances(path, ix=None, root="Pyra.Prelude") -> int:
    ix = ix or index(modules=[root])
    insts = instances_from_olean(ix)
    with open(path, "w", encoding="utf-8") as f:
        for n, prio in insts:
            f.write(f"{n}\t{prio}\n")
    return len(insts)


def load_kernel_from_olean(kernel: pb.Kernel, modules=None, search_path=None, cache_dir: str = "") -> dict:
    """Populate `kernel` straight from .olean files (no lean4export involved)."""
    ix = index(search_path)
    stats = ix.load_modules(kernel, list(modules or bundled_modules()), cache_dir)
    stats["source"] = "olean"
    stats["index"] = ix
    stats["instances"] = instances_from_olean(ix)
    return stats
