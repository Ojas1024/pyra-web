"""Feature 6: live proof-state debugging.

Inside a ``@prove`` body (which runs as ordinary Python), ``pyra.inspect()``
returns the current C++ goal state: hypotheses, the branch goal, variables and
the Mathlib lemmas that match.  It works from ``print``, ``pdb``/``breakpoint()``
and IDE debug consoles alike.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import runtime
from .kernel import elab
from .terms import PyraError, Term, pretty, to_term


@dataclass
class ProofState:
    function: str
    frame: str
    goal: str | None
    hyps: list
    vars: dict
    lemmas: list = field(default_factory=list)
    _goal_h: int | None = None

    def __repr__(self):
        out = [f"── pyra proof state: {self.function} [{self.frame}] ──"]
        for n, v in self.vars.items():
            out.append(f"  {n} : {v}")
        for name, text in self.hyps:
            out.append(f"  {name} : {text}")
        out.append(f"  ⊢ {self.goal if self.goal is not None else '(the goal is the final assert)'}")
        if self.lemmas:
            out.append("  matching Mathlib lemmas:")
            for l in self.lemmas:
                out.append(f"    {l['name']}  [{l['how']}]")
        return "\n".join(out)

    __str__ = __repr__


def inspect(target=None, *, lemmas: int = 8) -> ProofState:
    """The current proof state.  With `target` (a proposition), show the lemmas matching it."""
    s = runtime.current_session()
    if s is None:
        raise PyraError("pyra.inspect() can only be called while a @prove function runs")
    fr = s.frame
    hyps = fr.visible_hyps()
    goal_h = fr.goal
    if target is not None:
        t = to_term(target)
        if t.sort != "prop":
            raise PyraError("pyra.inspect(target) expects a proposition")
        goal_h = fr.apply(t.h)
    sugg = []
    if goal_h is not None and lemmas:
        sugg = elab().suggest(goal_h, [(h.fvar, h.prop, h.name) for h in hyps], lemmas)
    kind = {"root": "main", "zero": "base case", "succ": "inductive step", "case": "case"}.get(fr.kind, fr.kind)
    vars_ = {n: str(t.sort).replace("nat", "Nat").replace("real", "Real").replace("int", "Int") for n, t in s.params}
    for l in fr.all_locals():
        if l not in [t.h for _, t in s.params]:
            vars_[s.names.get(l, "?")] = "Nat"
    return ProofState(s.fn_name, kind, pretty(goal_h, s.names) if goal_h is not None else None,
                      [(h.name, pretty(h.prop, s.names)) for h in hyps], vars_, sugg, goal_h)
