"""Name conversion between Lean 4 / Mathlib and Python.

Lean declarations use camelCase, UpperCamelCase and Unicode.  Pyra exposes them
under PEP 8 names:

* ``Nat.minFac``          -> ``min_fac``
* ``Nat.Prime`` (a predicate, i.e. ``... -> Prop``)  -> ``is_prime``
* ``Nat.factorial_pos``   -> ``factorial_pos``
* ``Nat.le_minFac'``      -> ``le_min_fac_prime``
* ``Nat.sum_range_succ``  -> ``sum_range_succ``
* ``α``, ``ℕ``, ``₁``     -> ``alpha``, ``nat``, ``1``

Module paths: ``Mathlib.Data.Nat.Prime.Basic`` -> ``pyra.mathlib.data.nat.prime.basic``.
"""
from __future__ import annotations

import keyword
import re
import unicodedata

UNICODE = {
    "ℕ": "nat", "ℤ": "int", "ℚ": "rat", "ℝ": "real", "ℂ": "complex",
    "α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta", "ε": "epsilon", "ζ": "zeta", "η": "eta",
    "θ": "theta", "ι": "iota", "κ": "kappa", "λ": "lambda", "μ": "mu", "ν": "nu", "ξ": "xi", "π": "pi",
    "ρ": "rho", "σ": "sigma", "τ": "tau", "φ": "phi", "χ": "chi", "ψ": "psi", "ω": "omega",
    "Γ": "Gamma", "Δ": "Delta", "Λ": "Lambda", "Π": "Pi", "Σ": "Sigma", "Ω": "Omega",
    "∑": "sum", "∏": "prod", "∫": "integral", "∞": "infty", "√": "sqrt",
    "≤": "le", "≥": "ge", "≠": "ne", "<": "lt", ">": "gt", "∣": "dvd", "∈": "mem", "∉": "not_mem",
    "⊆": "subset", "∪": "union", "∩": "inter", "∘": "comp", "→": "to", "↔": "iff", "¬": "not",
    "∀": "forall", "∃": "exists", "⁻¹": "inv", "•": "smul", "×": "prod", "⊤": "top", "⊥": "bot",
    "'": "_prime", "!": "_bang", "?": "_q",
}
SUBSCRIPTS = str.maketrans("₀₁₂₃₄₅₆₇₈₉ₐₑₒₓₕₖₗₘₙₚₛₜ", "0123456789aeoxhklmnpst")
SUPERSCRIPTS = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")


def transliterate(s: str) -> str:
    out = []
    i = 0
    while i < len(s):
        two = s[i:i + 2]
        if two in UNICODE:
            out.append("_" + UNICODE[two] + "_")
            i += 2
            continue
        ch = s[i]
        if ch in UNICODE:
            rep = UNICODE[ch]
            out.append(rep if rep.startswith("_") else ("_" + rep + "_" if not ch.isalpha() else rep))
        elif ord(ch) < 128:
            out.append(ch)
        else:
            t = ch.translate(SUBSCRIPTS).translate(SUPERSCRIPTS)
            if t != ch:
                out.append(t)
            else:
                decomposed = unicodedata.normalize("NFKD", ch).encode("ascii", "ignore").decode()
                out.append(decomposed or "_u%04x_" % ord(ch))
        i += 1
    return "".join(out)


def snake(component: str) -> str:
    """camelCase / UpperCamelCase / Unicode -> snake_case."""
    s = transliterate(component)
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", s)          # minFac -> min_Fac
    s = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", "_", s)         # HTTPServer -> HTTP_Server
    s = s.lower()
    s = re.sub(r"[^0-9a-z_]", "_", s)
    s = re.sub(r"_+", "_", s).strip("_") or "_"
    if s[0].isdigit():
        s = "_" + s
    if keyword.iskeyword(s):
        s += "_"
    return s


def lean_to_py(name: str, *, predicate: bool = False) -> str:
    """Python name for the last component of a Lean declaration name."""
    last = name.rsplit(".", 1)[-1]
    py = snake(last)
    if predicate and last[:1].isupper() and not py.startswith(("is_", "has_", "can_")):
        py = "is_" + py
    return py


def module_to_py(module: str) -> str:
    """``Mathlib.Data.Nat.Prime.Basic`` -> ``pyra.mathlib.data.nat.prime.basic``."""
    parts = module.split(".")
    if parts and parts[0] == "Mathlib":
        parts = parts[1:]
        prefix = "pyra.mathlib"
    else:
        prefix = "pyra.lean." + snake(parts[0]) if parts else "pyra.lean"
        parts = parts[1:]
    return ".".join([prefix] + [snake(p) for p in parts])


def camel(py: str) -> str:
    """``min_fac`` -> ``minFac`` (used for method lookup on terms)."""
    head, *rest = py.split("_")
    return head + "".join(p[:1].upper() + p[1:] for p in rest)
