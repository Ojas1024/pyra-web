"""Feature 2: the instant background counterexample engine.

When an `assert` has not been proved within ``config.stall_ms`` (50 ms by
default) Pyra fires a background SMT query for a model of
``hypotheses ∧ ¬goal``.  A model is reported only after it has been confirmed
by evaluating the original statement on the concrete values, e.g.::

    Counterexample found: n = 0, x = -2.5
"""
from __future__ import annotations

import threading
import time
from decimal import Decimal, localcontext
from fractions import Fraction

from . import pyra_bind as pb
from .kernel import elab
from .terms import Unevaluable, evaluate

_NUMERIC = {"Nat": "nat", "Int": "int", "Real": "real"}

# z3's Python API (and cvc5.pythonic) share one global context that is not
# thread-safe; the background engine and the proof pipeline both use it.
_SMT_LOCK = threading.RLock()


class Translator:
    """Kernel term -> SMT term (z3 or cvc5.pythonic, which share an API)."""

    def __init__(self, backend):
        self.z = backend
        self.atoms = {}        # handle -> smt const
        self.vars = {}         # fvar handle -> smt const
        self.side = []
        self.opaque = False    # True when non-variable atoms were introduced
        self.count = 0

    def _sort_of(self, h):
        try:
            t = elab().infer(h)
        except Exception:
            return None
        return _NUMERIC.get(pb.const_name(t)) if pb.kind(t) == "const" else None

    def atom(self, h, sort):
        if h in self.atoms:
            return self.atoms[h]
        z = self.z
        is_var = pb.kind(h) == "fvar"
        name = pb.fvar_name(h) if is_var else f"_atom{self.count}"
        self.count += 1
        v = z.Real(f"{name}!{self.count}") if sort == "real" else z.Int(f"{name}!{self.count}")
        if sort == "nat":
            self.side.append(v >= 0)
        self.atoms[h] = v
        if is_var:
            self.vars[h] = v
        else:
            self.opaque = True
        return v

    def lit(self, h):
        if pb.kind(h) == "nat":
            return pb.nat_value(h)
        if pb.kind(h) == "app":
            hd = pb.head(h)
            if pb.kind(hd) == "const" and pb.const_name(hd) == "OfNat.ofNat":
                a = pb.args(h)
                if len(a) == 3 and pb.kind(a[1]) == "nat":
                    return pb.nat_value(a[1])
        return None

    def num(self, v, sort):
        return self.z.RealVal(v) if sort == "real" else self.z.IntVal(v)

    def term(self, h, sort):
        z = self.z
        v = self.lit(h)
        if v is not None:
            return self.num(v, sort)
        if pb.kind(h) == "app" and pb.kind(pb.head(h)) == "const":
            n = pb.const_name(pb.head(h))
            a = pb.args(h)
            if n in ("HAdd.hAdd", "HSub.hSub", "HMul.hMul", "HDiv.hDiv", "HMod.hMod") and len(a) == 6:
                x, y = self.term(a[4], sort), self.term(a[5], sort)
                if n == "HAdd.hAdd":
                    return x + y
                if n == "HMul.hMul":
                    return x * y
                if n == "HSub.hSub":
                    return z.If(x >= y, x - y, self.num(0, sort)) if sort == "nat" else x - y
                if n == "HDiv.hDiv":
                    return x / y if sort == "real" else z.If(y == 0, self.num(0, sort), x / y)
                return z.If(y == 0, x, x % y)
            if n == "HPow.hPow" and len(a) == 6:
                k = self.lit(a[5])
                if k is not None and k <= 12:
                    base = self.term(a[4], sort)
                    r = self.num(1, sort)
                    for _ in range(k):
                        r = r * base
                    return r
            if n == "Neg.neg" and len(a) == 3:
                return -self.term(a[2], sort)
            if n == "abs" and len(a) == 4:
                v = self.term(a[3], sort)
                return z.If(v >= 0, v, -v)
            if n == "Nat.succ" and len(a) == 1:
                return self.term(a[0], sort) + 1
            if n in ("Nat.cast", "NatCast.natCast") and a:
                x = self.term(a[-1], "nat")
                return z.ToReal(x) if sort == "real" else x
            if n in ("Int.cast", "IntCast.intCast") and a:
                x = self.term(a[-1], "int")
                return z.ToReal(x) if sort == "real" else x
        return self.atom(h, sort)

    def prop(self, h):
        z = self.z
        k = pb.kind(h)
        if k == "const":
            n = pb.const_name(h)
            if n == "True":
                return z.BoolVal(True)
            if n == "False":
                return z.BoolVal(False)
        if k == "pi" and pb.loose_bvar_range(pb.binder_body(h)) == 0:
            return z.Implies(self.prop(pb.binder_type(h)), self.prop(pb.binder_body(h)))
        if k == "app" and pb.kind(pb.head(h)) == "const":
            n = pb.const_name(pb.head(h))
            a = pb.args(h)
            if n == "And" and len(a) == 2:
                return z.And(self.prop(a[0]), self.prop(a[1]))
            if n == "Or" and len(a) == 2:
                return z.Or(self.prop(a[0]), self.prop(a[1]))
            if n == "Not" and len(a) == 1:
                return z.Not(self.prop(a[0]))
            if n == "Iff" and len(a) == 2:
                return self.prop(a[0]) == self.prop(a[1])
            if n in ("Eq", "Ne") and len(a) == 3 and pb.kind(a[0]) == "const" and pb.const_name(a[0]) in _NUMERIC:
                s = _NUMERIC[pb.const_name(a[0])]
                x, y = self.term(a[1], s), self.term(a[2], s)
                return x == y if n == "Eq" else x != y
            if n in ("LT.lt", "LE.le", "GT.gt", "GE.ge") and len(a) == 4 and pb.kind(a[0]) == "const" and pb.const_name(a[0]) in _NUMERIC:
                s = _NUMERIC[pb.const_name(a[0])]
                x, y = self.term(a[2], s), self.term(a[3], s)
                return {"LT.lt": x < y, "LE.le": x <= y, "GT.gt": x > y, "GE.ge": x >= y}[n]
        if h in self.atoms:
            return self.atoms[h]
        b = z.Bool(f"_p{self.count}")
        self.count += 1
        self.atoms[h] = b
        self.opaque = True
        return b


def format_value(v) -> str:
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, Fraction):
        if v.denominator == 1:
            return str(v.numerator)
        d = v.denominator
        for p in (2, 5):
            while d % p == 0:
                d //= p
        if d == 1:
            with localcontext() as ctx:
                ctx.prec = 60
                s = format(Decimal(v.numerator) / Decimal(v.denominator), "f")
            return s
        return f"{v.numerator}/{v.denominator}"
    return str(v)


def _value(model, var, z):
    val = model.eval(var, model_completion=True)
    try:
        if z.is_int_value(val):
            return val.as_long()
        if z.is_rational_value(val):
            return Fraction(val.numerator_as_long(), val.denominator_as_long())
        if z.is_true(val):
            return True
        if z.is_false(val):
            return False
    except Exception:
        pass
    try:
        return Fraction(str(val))
    except Exception:
        return str(val)


class Counterexample:
    def __init__(self, found, confirmed, assignment, opaque):
        self.found = found
        self.confirmed = confirmed
        self.assignment = assignment     # [(name, value)]
        self.opaque = opaque

    @property
    def message(self) -> str:
        if not self.found:
            return ""
        body = ", ".join(f"{n} = {format_value(v)}" for n, v in self.assignment) or "(any values)"
        return ("Counterexample found: " if self.confirmed else "Possible counterexample (not confirmed): ") + body

    def __repr__(self):
        return self.message or "<no counterexample>"


def _solver(z, backend, timeout_ms):
    s = z.Solver()
    if backend == "cvc5":
        s.set("tlimit-per", int(timeout_ms))
    else:
        s.set("timeout", int(timeout_ms))
    return s


def search(goal: int, hyps, variables, timeout_ms: int = 2000, backend: str = "z3") -> Counterexample:
    """Look for values of `variables` (fvar handles, in display order) refuting `goal` under `hyps`."""
    with _SMT_LOCK:
        return _search(goal, hyps, variables, timeout_ms, backend)


def _search(goal, hyps, variables, timeout_ms, backend) -> Counterexample:
    if backend == "cvc5":
        import cvc5.pythonic as z
    else:
        import z3 as z
    tr = Translator(z)
    s = _solver(z, backend, timeout_ms)
    for h in hyps:
        s.add(tr.prop(h))
    s.add(z.Not(tr.prop(goal)))
    for c in tr.side:
        s.add(c)
    for v in variables:          # make sure every parameter appears in the model
        if v not in tr.vars:
            t = elab().infer(v)
            if pb.kind(t) == "const" and pb.const_name(t) in _NUMERIC:
                tr.atom(v, _NUMERIC[pb.const_name(t)])
    for c in tr.side:
        s.add(c)
    if s.check() != z.sat:
        return Counterexample(False, False, [], tr.opaque)
    m = s.model()
    env, assignment = {}, []
    for v in variables:
        if v in tr.vars:
            val = _value(m, tr.vars[v], z)
            env[v] = val
            assignment.append((pb.fvar_name(v), val))
    confirmed = False
    try:
        ok_h = all(bool(evaluate(h, env)) for h in hyps)
        confirmed = ok_h and not bool(evaluate(goal, env))
    except Unevaluable:
        confirmed = not tr.opaque
    except Exception:
        confirmed = False
    return Counterexample(True, confirmed, assignment, tr.opaque)


def smt_valid(goal: int, hyps, timeout_ms: int = 3000, backend: str = "z3") -> bool:
    """Does an SMT solver prove hyps -> goal (with library functions uninterpreted)?"""
    with _SMT_LOCK:
        return _smt_valid(goal, hyps, timeout_ms, backend)


def _smt_valid(goal, hyps, timeout_ms, backend) -> bool:
    if backend == "cvc5":
        import cvc5.pythonic as z
    else:
        import z3 as z
    tr = Translator(z)
    s = _solver(z, backend, timeout_ms)
    for h in hyps:
        s.add(tr.prop(h))
    s.add(z.Not(tr.prop(goal)))
    for c in tr.side:
        s.add(c)
    try:
        return s.check() == z.unsat
    except Exception:
        return False


class Engine:
    """Runs one counterexample search in a background thread."""

    def __init__(self, goal, hyps, variables, timeout_ms=3000):
        self.goal, self.hyps, self.variables, self.timeout_ms = goal, hyps, variables, timeout_ms
        self.result = None
        self.fired_at = None
        self.done = threading.Event()
        self.thread = None

    def start(self):
        self.fired_at = time.perf_counter()

        def run():
            try:
                self.result = search(self.goal, self.hyps, self.variables, self.timeout_ms)
            except Exception as e:     # never let the engine break a proof
                self.result = Counterexample(False, False, [], True)
                self.result.error = repr(e)
            finally:
                self.done.set()

        self.thread = threading.Thread(target=run, name="pyra-counterexample", daemon=True)
        self.thread.start()
        return self
