"""``python -m pyra`` — command line tools.

    python -m pyra stubs [--out DIR]           generate .pyi stubs for pyra.mathlib
    python -m pyra manifest --out FILE         list bundled declarations (read from .olean)
    python -m pyra instances --out FILE        list @[instance] declarations (read from .olean)
    python -m pyra check-olean MODULE...       import modules from .olean and re-check them
    python -m pyra where                       show the Lean toolchain / Mathlib in use
    python -m pyra doc FILE [--format md|tex]  compile verified code into a paper (Feature 12)
    python -m pyra graph FILE THEOREM -o X.html  interactive proof graph (Feature 11)
    python -m pyra extract FILE NAME --target cpp|rust|numba  verified code extraction (Feature 10)

Global options --lean-toolchain, --mathlib and --lean-path override PYRA_LEAN_TOOLCHAIN,
PYRA_MATHLIB and PYRA_LEAN_PATH.
"""
from __future__ import annotations

import argparse
import sys


def main(argv=None):
    ap = argparse.ArgumentParser(prog="pyra")
    ap.add_argument("--lean-toolchain", help="Lean 4.33 toolchain prefix (sets PYRA_LEAN_TOOLCHAIN)")
    ap.add_argument("--mathlib", help="Mathlib project directory (sets PYRA_MATHLIB)")
    ap.add_argument("--lean-path", help="explicit .olean search path, ':'-separated (sets PYRA_LEAN_PATH)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("stubs", help="generate .pyi stubs for pyra.mathlib")
    s.add_argument("--out", default=None)
    m = sub.add_parser("manifest", help="write the bundled-declaration manifest from .olean files")
    m.add_argument("--out", required=True)
    i = sub.add_parser("instances", help="write Lean's @[instance] declarations (read from .olean) for the bundle")
    i.add_argument("--out", required=True)
    sub.add_parser("where", help="show which Lean toolchain / Mathlib / search path Pyra uses")
    d = sub.add_parser("doc", help="compile verified Python code into a Markdown or LaTeX paper")
    d.add_argument("file")
    d.add_argument("--format", choices=["md", "tex"], default="md")
    d.add_argument("-o", "--output")
    d.add_argument("--title")
    g = sub.add_parser("graph", help="export the proof graph of a theorem as interactive HTML")
    g.add_argument("file")
    g.add_argument("theorem")
    g.add_argument("-o", "--output", required=True)
    x = sub.add_parser("extract", help="extract verified code to C++20, Rust or Numba")
    x.add_argument("file")
    x.add_argument("name")
    x.add_argument("--target", choices=["cpp", "rust", "numba"], default="cpp")
    x.add_argument("--main", action="store_true")
    x.add_argument("-o", "--output")
    c = sub.add_parser("check-olean", help="import modules from .olean and re-check them with the kernel")
    c.add_argument("modules", nargs="+")
    c.add_argument("--cache", default="")
    args = ap.parse_args(argv)
    import os
    for flag, var in (("lean_toolchain", "PYRA_LEAN_TOOLCHAIN"), ("mathlib", "PYRA_MATHLIB"), ("lean_path", "PYRA_LEAN_PATH")):
        if getattr(args, flag):
            os.environ[var] = getattr(args, flag)
    if args.cmd == "stubs":
        from .stubs import generate
        files = generate(args.out)
        print(f"wrote {len(files)} stub files")
    elif args.cmd == "instances":
        from .lean_bridge import write_instances
        print(f"wrote {write_instances(args.out)} instances to {args.out}")
    elif args.cmd == "manifest":
        from .lean_bridge import write_manifest
        print(f"wrote {write_manifest(args.out)} declarations to {args.out}")
    elif args.cmd == "doc":
        from .doc import document
        text = document(args.file, args.format, args.title)
        if args.output:
            open(args.output, "w", encoding="utf-8").write(text)
            print(f"wrote {args.output}")
        else:
            print(text)
    elif args.cmd in ("graph", "extract"):
        import importlib.util, sys as _s
        from pathlib import Path
        path = Path(args.file).resolve()
        _s.path.insert(0, str(path.parent))
        spec = importlib.util.spec_from_file_location(path.stem, path)
        mod = importlib.util.module_from_spec(spec)
        _s.modules[path.stem] = mod
        spec.loader.exec_module(mod)
        obj = getattr(mod, args.theorem if args.cmd == "graph" else args.name)
        if args.cmd == "graph":
            obj.graph().to_html(args.output)
            print(f"wrote {args.output}")
        else:
            from .extract import extract
            code = extract(obj, args.target, main=args.main).code
            if args.output:
                open(args.output, "w").write(code)
                print(f"wrote {args.output}")
            else:
                print(code)
    elif args.cmd == "where":
        from . import lean_bridge as lb
        print("toolchain :", lb.toolchain_prefix())
        print("mathlib   :", lb.mathlib_project())
        print("lean path :", *lb.default_search_path(), sep="\n  ")
    elif args.cmd == "check-olean":
        from . import pyra_bind as pb
        from .lean_bridge import load_kernel_from_olean
        k = pb.Kernel()
        st = load_kernel_from_olean(k, args.modules, cache_dir=args.cache)
        print(f"{st['declarations']} declarations: {st['checked']} checked, {st['trusted']} from cache, "
              f"{st['failed']} failed, {st['unsupported']} unsupported ({st['seconds']:.2f}s)")
        for e in st["errors"]:
            print("  error:", e)
        return 1 if st["failed"] else 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
