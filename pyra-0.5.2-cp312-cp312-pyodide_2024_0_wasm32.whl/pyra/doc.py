"""Feature 12 — natural-language auto-documentation (``python -m pyra doc``).

Compiles a Python file with verified ``@prove`` functions into a Markdown or
LaTeX paper whose structure mirrors the formal proofs: one theorem per proof,
its statement typeset from the kernel term, and a proof that walks the same
steps (definitions, induction, case analysis, each asserted fact with the
reason the kernel accepted it, and the trust level of every step).
"""
from __future__ import annotations

import ast as pyast
import importlib.util
import inspect
import re
import sys
from pathlib import Path

from . import pyra_bind as pb
from .ast import ProvedTheorem
from .naming import lean_to_py
from .runtime import KERNEL_VERIFIED, SMT_TRUSTED, UNPROVED

# ------------------------------------------------------------------ term -> LaTeX
_FUN = {"Nat.Prime": None, "Nat.minFac": r"\operatorname{minFac}", "Nat.gcd": r"\gcd", "Nat.factorial": None}


def _lit(h):
    if pb.kind(h) == "nat":
        return pb.nat_value(h)
    if pb.kind(h) == "app" and pb.kind(pb.head(h)) == "const" and pb.const_name(pb.head(h)) == "OfNat.ofNat":
        a = pb.args(h)
        if len(a) == 3 and pb.kind(a[1]) == "nat":
            return pb.nat_value(a[1])
    return None


def latex(h: int, names=None, ctx=None, prec=0) -> str:
    names = names or {}
    ctx = ctx or []
    wrap = lambda s, p: f"\\left({s}\\right)" if p < prec else s
    if h in names:
        return _ident(names[h])
    k = pb.kind(h)
    if k == "fvar":
        return _ident(pb.fvar_name(h))
    if k == "bvar":
        i = pb.bvar_index(h)
        return _ident(ctx[-1 - i]) if i < len(ctx) else "?"
    if k == "nat":
        return str(pb.nat_value(h))
    if k == "sort":
        return r"\mathrm{Prop}"
    if k == "const":
        n = pb.const_name(h)
        return {"True": r"\top", "False": r"\bot", "Nat": r"\mathbb{N}", "Real": r"\mathbb{R}", "Int": r"\mathbb{Z}"}.get(
            n, r"\operatorname{" + lean_to_py(n).replace("_", r"\_") + "}")
    if k == "lam":
        nm = pb.binder_name(h) or "x"
        return wrap(rf"{_ident(nm)} \mapsto {latex(pb.binder_body(h), names, ctx + [nm], 0)}", 0)
    if k == "pi":
        nm = pb.binder_name(h) or "x"
        body = pb.binder_body(h)
        if pb.loose_bvar_range(body) == 0:
            return wrap(rf"{latex(pb.binder_type(h), names, ctx, 2)} \Rightarrow {latex(body, names, ctx + [nm], 1)}", 1)
        return wrap(rf"\forall {_ident(nm)} \in {latex(pb.binder_type(h), names, ctx, 9)},\ {latex(body, names, ctx + [nm], 0)}", 0)
    v = _lit(h)
    if v is not None:
        return str(v)
    if k != "app" or pb.kind(pb.head(h)) != "const":
        return r"\cdots"
    n, a = pb.const_name(pb.head(h)), pb.args(h)
    L = lambda x, p=0: latex(x, names, ctx, p)
    if n in ("HAdd.hAdd", "HSub.hSub") and len(a) == 6:
        op = "+" if n == "HAdd.hAdd" else ("\\mathbin{\\dot-}" if pb.kind(a[0]) == "const" and pb.const_name(a[0]) == "Nat" else "-")
        return wrap(f"{L(a[4], 6)} {op} {L(a[5], 7)}", 6)
    if n == "HMul.hMul" and len(a) == 6:
        return wrap(rf"{L(a[4], 7)} \cdot {L(a[5], 8)}", 7)
    if n == "HDiv.hDiv" and len(a) == 6:
        if pb.kind(a[0]) == "const" and pb.const_name(a[0]) == "Real":
            return rf"\frac{{{L(a[4])}}}{{{L(a[5])}}}"
        return wrap(rf"\left\lfloor {L(a[4])} / {L(a[5])} \right\rfloor", 7)
    if n == "HMod.hMod" and len(a) == 6:
        return wrap(rf"{L(a[4], 7)} \bmod {L(a[5], 8)}", 7)
    if n == "HPow.hPow" and len(a) == 6:
        return f"{{{L(a[4], 9)}}}^{{{L(a[5])}}}"
    rel = {"Eq": "=", "Ne": r"\neq", "LT.lt": "<", "LE.le": r"\le", "GT.gt": ">", "GE.ge": r"\ge"}
    if n in rel and len(a) in (3, 4):
        return wrap(f"{L(a[-2], 4)} {rel[n]} {L(a[-1], 4)}", 3)
    if n == "And" and len(a) == 2:
        return wrap(rf"{L(a[0], 3)} \land {L(a[1], 2)}", 2)
    if n == "Or" and len(a) == 2:
        return wrap(rf"{L(a[0], 2)} \lor {L(a[1], 1)}", 1)
    if n == "Not" and len(a) == 1:
        return wrap(rf"\neg {L(a[0], 9)}", 8)
    if n == "Iff" and len(a) == 2:
        return wrap(rf"{L(a[0], 1)} \iff {L(a[1], 1)}", 0)
    if n == "Exists" and len(a) == 2 and pb.kind(a[1]) == "lam":
        nm = pb.binder_name(a[1]) or "x"
        return wrap(rf"\exists {_ident(nm)} \in {latex(pb.binder_type(a[1]), names, ctx, 9)},\ {latex(pb.binder_body(a[1]), names, ctx + [nm], 0)}", 0)
    if n == "Nat.Prime" and len(a) == 1:
        return rf"{L(a[0], 9)}\ \text{{is prime}}"
    if n == "Nat.factorial" and len(a) == 1:
        return f"{L(a[0], 9)}!"
    if n in ("Nat.cast", "NatCast.natCast", "Int.cast") and a:
        return L(a[-1], prec)
    if n == "Neg.neg" and len(a) == 3:
        return wrap(f"-{L(a[2], 8)}", 8)
    if n == "abs" and len(a) == 4:
        return rf"\left|{L(a[3])}\right|"
    if n == "Dvd.dvd" and len(a) == 4:
        return wrap(rf"{L(a[2], 5)} \mid {L(a[3], 5)}", 4)
    if n in ("Finset.sum", "Finset.prod") and len(a) == 5:
        s, f = a[3], a[4]
        big = r"\sum" if n == "Finset.sum" else r"\prod"
        if pb.kind(s) == "app" and pb.const_name(pb.head(s)) == "Finset.range" and pb.kind(f) == "lam":
            nm = pb.binder_name(f) or "i"
            return wrap(rf"{big}_{{{_ident(nm)} < {L(pb.args(s)[-1])}}} {latex(pb.binder_body(f), names, ctx + [nm], 7)}", 6)
    if n == "HasDerivAt" and len(a) >= 3:
        return rf"\left({L(a[-3])}\right)'({L(a[-1])}) = {L(a[-2])}"
    if n == "deriv" and len(a) >= 2:
        return rf"\left({L(a[-2])}\right)'({L(a[-1])})"
    if n.startswith("Pyra.Def."):
        return rf"\operatorname{{{_ident(n.split('.')[-2])}}}\left({', '.join(L(x) for x in a)}\right)"
    fn = n.rsplit(".", 1)[-1]
    shown = [x for x in a]
    from .terms import _explicit_mask
    mask = _explicit_mask(n)
    shown = [x for i, x in enumerate(a) if i >= len(mask) or mask[i]]
    return rf"\operatorname{{{_ident(fn)}}}\left({', '.join(L(x) for x in shown)}\right)"


def _ident(s: str) -> str:
    s = s.replace("_", r"\_")
    return s if len(s) == 1 else r"\mathit{" + s + "}"


# ------------------------------------------------------------------ prose
def _reason(step) -> str:
    lem = ", ".join(f"`{l}`" for l in step.lemmas) if step.lemmas else ""
    st = step.stage or ""
    if step.badge == UNPROVED:
        return "this step is **not proved** (it was admitted as an assumption)"
    if step.badge == SMT_TRUSTED:
        return f"this step is trusted from an external solver ({st}), without a kernel proof"
    if st.startswith("induction hypothesis"):
        return "by the induction hypothesis"
    if st == "definitional equality":
        return "by direct computation (the two sides are definitionally equal)"
    if st == "term rewriting":
        return ("by rewriting with " + lem + " and normalising both sides as polynomials") if lem else "by normalising both sides as polynomials"
    if st == "SMT proof reconstruction":
        return "by arithmetic: a Farkas certificate found by an SMT solver and re-checked by the kernel"
    if st == "Mathlib premise search":
        return f"by the Mathlib lemmas {lem}" if lem else "by lemmas from Mathlib"
    if st.startswith("SymPy"):
        return f"by a computer-algebra computation ({st}) whose certificate the kernel re-checked"
    if st.startswith("python solver"):
        return f"with a step suggested by the solver `{st.split()[-1]}`" + (f" using {lem}" if lem else "")
    if st == "library lemma":
        return f"by {lem}"
    return st or "by the kernel"


def _assignments(fn):
    try:
        src_lines, start = inspect.getsourcelines(fn)
    except (OSError, TypeError):
        return {}
    import textwrap
    tree = pyast.parse(textwrap.dedent("".join(src_lines)))
    out = {}
    for n in pyast.walk(tree):
        if isinstance(n, pyast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], pyast.Name):
            out[n.lineno + start - 1] = (n.targets[0].id, pyast.unparse(n.value))
    return out


class _Writer:
    def __init__(self, fmt):
        self.fmt = fmt
        self.lines = []

    def math(self, s, display=False):
        if self.fmt == "md":
            return f"$${s}$$" if display else f"${s}$"
        return f"\\[{s}\\]" if display else f"\\({s}\\)"

    def para(self, s):
        self.lines.append(s)
        self.lines.append("")

    def text(self, s):
        if self.fmt == "tex":
            s = re.sub(r"`([^`]*)`", lambda m: r"\texttt{" + m.group(1).replace("_", r"\_") + "}", s)
            s = re.sub(r"\*\*([^*]*)\*\*", r"\\textbf{\1}", s)
        return s


def _theorem(w: _Writer, i: int, thm: ProvedTheorem):
    names = thm._names
    stmt = latex(thm.statement, names)
    title = thm.__name__.replace("_", " ")
    if w.fmt == "md":
        w.para(f"### Theorem {i} ({title})")
        w.para(w.math(stmt, display=True))
        w.para("*Proof.*")
    else:
        w.para(f"\\begin{{theorem}}[{title.replace('_', ' ')}]\\label{{thm:{thm.__name__}}}\n{w.math(stmt, display=True)}\n\\end{{theorem}}")
        w.lines.append("\\begin{proof}")
    lets = _assignments(thm.__wrapped__)
    said = set()
    steps = list(thm.steps)
    has_induction = any(s.stage in ("induction (Nat.rec)", "strong induction") for s in steps)
    has_cases = any(s.stage == "case split" for s in steps)
    if has_induction:
        kind = "strong induction" if any(s.stage == "strong induction" for s in steps) else "induction"
        var = thm.params[0] if thm.params else "n"
        w.para(w.text(f"We proceed by {kind} on {w.math(_ident(var))}."))
    elif has_cases:
        w.para(w.text("We distinguish cases."))
    items = []
    for s in steps:
        for line in sorted(lets):
            if line < s.line and line not in said:
                name, src = lets[line]
                said.add(line)
                items.append(w.text(f"Let {w.math(_ident(name))} be `{src}`."))
        if s.kind == "branch" and s.stage in ("induction (Nat.rec)", "strong induction", "case split"):
            continue
        if s.kind == "branch" and s.source.startswith("(goal of the base case"):
            items.append(w.text(f"This settles the base case, {_reason(s)}."))
            continue
        if s.kind == "branch":
            items.append(w.text(f"This establishes the claim in this case, {_reason(s)}."))
            continue
        if s.kind == "ih":
            items.append(w.text(f"Inductive step. By the induction hypothesis, {w.math(latex_text(s, names))}."))
            continue
        lead = {"assert": "We have", "return": "Therefore", "lemma": "We use"}.get(s.kind, "We have")
        claim = latex_text(s, names)
        items.append(w.text(f"{lead} {w.math(claim)}, {_reason(s)}."))
    if w.fmt == "md":
        for j, it in enumerate(items, 1):
            w.lines.append(f"{j}. {it}")
        w.lines.append("")
    else:
        w.lines.append("\\begin{enumerate}")
        for it in items:
            w.lines.append(f"  \\item {it}")
        w.lines.append("\\end{enumerate}")
    trust = _trust_sentence(thm)
    if w.fmt == "md":
        w.para(f"{w.text(trust)} ∎")
    else:
        w.lines.append(w.text(trust))
        w.lines.append("\\end{proof}")
        w.lines.append("")


def latex_text(step, names):
    if step.goal is not None:
        return latex(step.goal, names)
    return step.text.replace("_", r"\_")


def _trust_sentence(thm) -> str:
    bad = [s for s in thm.steps if s.badge in (SMT_TRUSTED, UNPROVED)]
    if not bad:
        return ("Every step above was checked by the Pyra kernel; the proof relies only on the axioms "
                + (", ".join(f"`{a}`" for a in sorted(set(thm.theorem.axioms))) or "of the core logic") + ".")
    return "Steps on lines " + ", ".join(str(s.line) for s in bad) + " are not kernel-verified (" + \
           ", ".join(f"line {s.line}: {s.badge}" for s in bad) + ")."


def collect(module) -> list:
    thms = [v for v in vars(module).values() if isinstance(v, ProvedTheorem)]
    return sorted(thms, key=lambda t: inspect.getsourcelines(t.__wrapped__)[1])


def render(theorems, fmt: str = "md", title: str = "Verified results") -> str:
    if fmt not in ("md", "tex"):
        raise ValueError("format must be 'md' or 'tex'")
    w = _Writer(fmt)
    if fmt == "md":
        w.para(f"# {title}")
        w.para(f"*Generated by `pyra doc` from {len(theorems)} kernel-checked proof(s).*")
    else:
        w.lines += ["\\documentclass{article}", "\\usepackage{amsmath,amssymb,amsthm}", "\\newtheorem{theorem}{Theorem}",
                    f"\\title{{{title}}}", "\\date{}", "\\begin{document}", "\\maketitle", ""]
        w.para(f"\\noindent\\emph{{Generated by \\texttt{{pyra doc}} from {len(theorems)} kernel-checked proof(s).}}")
    for i, t in enumerate(theorems, 1):
        _theorem(w, i, t)
    if fmt == "tex":
        w.lines.append("\\end{document}")
    return "\n".join(w.lines) + "\n"


def document(path, fmt: str = "md", title: str | None = None) -> str:
    """Import the Python file at `path` (running its proofs) and render its verified theorems."""
    path = Path(path).resolve()
    sys.path.insert(0, str(path.parent))
    try:
        spec = importlib.util.spec_from_file_location(path.stem, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[path.stem] = mod
        spec.loader.exec_module(mod)
    finally:
        sys.path.remove(str(path.parent))
    return render(collect(mod), fmt, title or path.stem.replace("_", " ").title())
